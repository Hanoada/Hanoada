"""This is the 'ParcelTruck' class file. The task allows for (3) ParcelTrucks, each of which can have a
maximum of 16 Package objects associated with it and a 'speed' of 18 miles per hour. This class file is used to
create instantiations of the ParcelTruck class. (--- Space-Time Complexity -> O(1) - CONSTANT---)
"""

"""The '__str__' function defines how the ParcelTruck object should be displayed in the console if and when it is 
printed during the execution of the program. I chose to use 'f strings' since I used Python 10.X to create this 
program. (--- Space-Time Complexity -> O(1) - CONSTANT ---)
"""


class ParcelTruck:
    def __init__(self, capacity, speed, packages, miles, location, departure, current_time=None):
        self.capacity = capacity
        self.speed = speed
        self.packages = packages
        self.miles = miles
        self.location = location
        self.departure = departure
        self.current_time = current_time

    # Establishes how ParcelTruck objects should display when printed to the console using "f strings" (Python 3+)
    def __str__(self):
        return f"Capacity: {self.capacity},\n" \
               f"Speed: {self.speed},\n" \
               f"Packages: {self.packages},\n" \
               f"Miles Traveled: {self.miles},\n" \
               f"Current Location: {self.location},\n" \
               f"Departure Time: {self.departure}\n" \
               f"Current Time: {self.current_time}\n"
