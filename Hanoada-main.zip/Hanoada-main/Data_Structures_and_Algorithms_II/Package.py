"""This is the 'Package' class file. The task defines (40) 'Package' objects which are to be assigned in some manner to
up-to (3) 'ParcelTruck' objects. Each parameter in this class (except 'departure_time' and 'delivery_time') is received
from a CSV file included with this submission ('WGUPS-Package-File.csv').
(--- Space-Time Complexity -> O(1) - CONSTANT ---)
"""

"""The '__str__' function defines how the Package object should be displayed in the console if and when it is 
printed during the execution of the program. I chose to use 'f strings' since I used Python 10.X to create this 
program. (--- Space-Time Complexity -> O(1) - CONSTANT---)
"""


class Package:
    def __init__(self, package_id_number, delivery_address, delivery_city, delivery_zip_code, package_weight,
                 deadline, special_note, delivery_status, departure_time=None, delivery_time=None):
        self.package_id_number = package_id_number
        self.delivery_address = delivery_address
        self.delivery_city = delivery_city
        self.delivery_zip_code = delivery_zip_code
        self.package_weight = package_weight
        self.deadline = deadline
        self.special_note = special_note
        self.delivery_status = delivery_status
        self.departure_time = departure_time
        self.delivery_time = delivery_time

    # Establishes how Package objects should display when printed to the console using "f strings" (Python 3+)
    def __str__(self):
        return f"Package ID: {self.package_id_number}\n" \
               f"Delivery Address: {self.delivery_address}\n" \
               f"Delivery City: {self.delivery_city}\n" \
               f"Delivery Zip Code: {self.delivery_zip_code}\n" \
               f"Package Weight: {self.package_weight}\n" \
               f"Delivery Deadline: {self.deadline}\n" \
               f"Special Note: {self.special_note}\n" \
               f"Delivery Status: {self.delivery_status}\n" \

    """The 'check_time_status' function accepts a user-entered time as input and checks the 'delivery_status' of the 
    Package object against its 'delivery_time' and 'departure_time'. This information is used to determine and update 
    the 'delivery_status' of any given Pacakge object. (--- Space-Time Complexity -> O(1) - CONSTANT ---)"""

    def check_time_status(self, time_checked):
        if self.delivery_time <= time_checked:
            self.delivery_status = 'delivered'
        elif self.delivery_time >= time_checked >= self.departure_time:
            self.delivery_status = 'en route'
        else:
            self.delivery_status = 'at the hub'

    """the 'set_departure_time' function accepts a Package object's associated ParcelTruck object's 'departure' 
    parameter sets the given Package object's 'departure_time' to match. 
    (--- Space-Time Complexity -> O(1) - CONSTANT ---)"""

    def set_departure_time(self, truck_departure_time):
        self.departure_time = truck_departure_time
