# STUDENT NAME: ADAM HANOVER
# STUDENT ID: 001385636
# SPACE-TIME COMPLEXITY OF ENTIRE PROGRAM: O(N^2) - QUADRATIC

import datetime
import time

import ParcelTruck
from ChainingHash import ChainingHash
from Package import *
import csv

"""To see my self-adjusting data structure, check the 'ChainingHash.py' file included with this submission. 
Below, 'package_hash" is instantiated as a 'ChainingHash' self-adjusting data structure.
"""
package_hash = ChainingHash()

"""This is where I defined a function to read the data from a file containing package information and loaded it 
into the 'package_hash' 'ChainingHash' self-adjusting data structure (or hash table). It begins by opening the file, 
reading it in CSV format, and inserting each 'package' into the package_hash_table. See the included 
'WGUPS-Package-File.csv' file to inspect the data. Only non-meaningful edits were made to the data.

(--- Space-Time Complexity -> O(N) - LINEAR---)
"""


def load_package_data(file_name, package_hash_table):
    with open(file_name, encoding='utf-8-sig') as package_csv:
        package_info = csv.reader(package_csv)
        for parcel in package_info:
            package_id_number = parcel[0]
            delivery_address = parcel[1]
            delivery_city = parcel[2]
            delivery_zip_code = parcel[4]
            package_weight = parcel[6]
            deadline = parcel[5]
            special_note = parcel[7]
            delivery_status = 'at the hub'
            # Creates a "Package" object with the information gathered from the "WGUPS-Pacakge-File.csv" file.
            new_package = Package(int(package_id_number), delivery_address, delivery_city, delivery_zip_code,
                                  package_weight, deadline, special_note, delivery_status)
            # After the new "Package" object is created, it is inserted into the package_hash_table using the
            # package_id_number as the "key" and the rest of the pacakge information as the "value".
            package_hash_table.insert(int(package_id_number), new_package)


"""'load_pacakge_data' is the call to the function described above, to read data from a CSV file and store it in 
the self-adjusting hash table. (--- Space-Time Complexity -> O(N) - LINEAR ---)
"""
load_package_data('WGUPS-Package-File.csv', package_hash)

"""The below built-in Python function (with open) allows for the parsing of CSV-type data. The function below deals 
with the list of "Packages" included in the files with this submission (WGUPS-Package-File.csv).
(--- Space-Time Complexity -> O(N) - LINEAR ---)
"""
with open('WGUPS-Package-File.csv', encoding='utf-8-sig') as package_csv_file:
    csv_reader = csv.reader(package_csv_file)
    package_list = list(csv_reader)

"""The below built-in Python function (with open) allows for the parsing of CSV-type data. The function below deals with 
the list of distances included in the files with this submission (WGUPS-Distance-Table.csv).
(--- Space-Time Complexity -> O(N) - LINEAR ---)
"""
with open('WGUPS-Distance-Table.csv', encoding='utf-8-sig') as distance_csv_file:
    csv_reader = csv.reader(distance_csv_file)
    distance_list = list(csv_reader)

"""The below built-in Python function (with open) allows for the parsing of CSV-type data. The function below deals 
with the list of addresses included in the files with this submission (WGUPS-Address-Table.csv).
(--- Space-Time Complexity -> O(N) - LINEAR ---)
"""
with open('WGUPS-Address-Table.csv', encoding='utf-8-sig') as addresses_csv_file:
    csv_reader = csv.reader(addresses_csv_file)
    address_list = list(csv_reader)

"""
Below are three 'ParcelTruck' instances, defined in the 'ParcelTruck.py' file included with this submission. I 
decided to manually assign the package numbers for this task, as many other students chose. I assigned the pacakge 
numbers based on delivery times, Package delays, and truck / package requirements and limitations identified in the 
task.
"""
truck_1 = ParcelTruck.ParcelTruck(16, 18, [13, 14, 15, 16, 19, 20, 21, 1, 29, 30, 34, 40, 7, 27, 37, 38], 0.0,
                                  address_list[0], datetime.timedelta(hours=8, minutes=0),
                                  datetime.timedelta(hours=8, minutes=0))

truck_2 = ParcelTruck.ParcelTruck(16, 18, [3, 6, 18, 25, 26, 28, 31, 32, 36, 35], 0.0,
                                  address_list[0], datetime.timedelta(hours=9, minutes=5),
                                  datetime.timedelta(hours=9, minutes=5))

truck_3 = ParcelTruck.ParcelTruck(16, 18, [2, 4, 5, 8, 9, 10, 11, 12, 17, 22, 23, 24, 33, 39], 0.0,
                                  address_list[0], datetime.timedelta(hours=9, minutes=52),
                                  datetime.timedelta(hours=9, minutes=52))

"""The 'set_departure' function defined below is for all packages in a given ParcelTruck. It uses the list contained 
in the ParcelTruck object to search the Package hash table and assign the Package object's 'departure_time' parameter 
to the time contained in its ParcelTruck's 'departure_time' parameter. 
(--- Space-Time Complexity -> O(N) - LINEAR ---)
"""


def set_departure(truck):
    for parcel in truck.packages:
        package_hash.search(parcel).set_departure_time(truck.departure)


"""Below, I have called the 'set_departure' function (described immediately above) for each ParcelTruck object. 
This will be stored with each Package object.
"""
set_departure(truck_1)
set_departure(truck_2)
set_departure(truck_3)

"""'get_address' is a function to search the 'address_list' (created using the included CSV file above) which searches 
the lines in the 'address_list' list for matching address information for a determined Package object.
(--- Space-Time Complexity -> O(N) - LINEAR ---)
"""


def get_address(parcel_address):
    for line in address_list:
        if parcel_address == line[1]:
            return int(line[0])


"""set_truck_address accepts a ParcelTruck object as an argument and searches the 'address_list' (created using the 
included CSV file above). It returns the matching address with its corresponding key.
(--- Space-Time Complexity -> O(N) - LINEAR ---)
"""


def set_truck_address(truck_address):
    for addresses in address_list:
        if truck_address == addresses[2]:
            return addresses


"""get_distance_index accepts a ParcelTruck or Package object as an argument and searches the 'address_list' (created 
using the included CSV file above). It returns an integer that represents the matching address's key value in the 
'address_list'. This can be used with the 'find_distance' list to easily determine the distance between two objects.
(--- Space-Time Complexity -> O(N) - LINEAR ---)
"""


def get_distance_index(truck_or_parcel_address):
    for final_address in address_list:
        if truck_or_parcel_address == final_address[2]:
            return int(final_address[0])


"""'find_distance' accepts two arguments which represent keys in the 'distance_list' list. These integers can be used 
to determine the number of miles between two objects by searching the 'distance_list' at both indices provided. The 
'distance_list' is created above using the included CSV file. (--- Space-Time Complexity -> O(N) - LINEAR ---)
"""


def find_distance(loc_1, loc_2):
    miles = distance_list[loc_1][loc_2]
    return float(miles)


"""reroute_package is only used for Package 9 in this task. Since Package 9 shows the wrong address, this function 
was created to address the change. The scenario dictates Package 9 has its 'delivery_address' updated at 
exactly 10:20AM, at which point this function updates its information. 
(--- Space-Time Complexity -> O(1) - CONSTANT ---)
"""


def reroute_package(parcel_id):
    wrong_address_parcel = package_hash.search(parcel_id)
    wrong_address_parcel.delivery_address = '410 S State St'
    wrong_address_parcel.delivery_city = 'Salt Lake City'
    wrong_address_parcel.delivery_zip_code = '84111'
    wrong_address_parcel.special_note = 'Wrong address listed - Updated En Route to Correct Address at 10:20 AM'


"""This is my "named self-adjusting algorithm", which uses the "Nearest Neighbor" algorithm.  This algorithm starts 
with a "ParcelTruck" object, which I have created as a custom class for this task (see "ParcelTruck.py" file included 
for details). The ParcelTruck object has multiple data points associated with it, including a pseudo list of packages. 
The reason it is a "pseudo" list is because the package objects are stored in the hash table ("ChainingHash.py") and 
the ParcelTruck object actually only stores a list of numbers which relate to "package_id_numbers" for packages in the 
hash table. This algorithm assigns the package ID numbers to a new list in order to manipulate the numbers without 
disassociating the "Packages" with the ParcelTruck. At this point, the algorithm assigns a number to a new variable, 
"closest_miles" which represents a placeholder for the distance from the ParcelTruck to the next Package in question. It 
also assigns "None" to the "closest_pack" variable; another placeholder which will be used throughout the algorithm to 
keep track of which Package object is currently closest to the ParcelTruck object. The "delivered" list is instantiated 
as an empty list and will have package ID numbers appended to it as the algorithm executes.

The main sections of the algorithm cycle through the package ID numbers of the Package objects associated with the 
ParcelTruck object and looks them up in the Package hash table. This gets all information about the Package object, 
including delivery address, which is used to calculate the distance between the ParcelTruck and the current Package 
object. As the algorithm checks each package ID number, it cycles through all other package ID number in the 
truck_parcels list and If the current Package object is the closest to the ParcelTruck when compared with any other 
Package object represented in the list, it is assigned to the "closest_pack" variable. If not, the current Package 
object is appended to the "not_delivered" list. If the current Package object is closest (least number of miles), the 
algorithm appends the package ID number to the "delivered" list, removes the package ID number from the "truck_parcels" 
list, calculates the number of minutes it will take for the ParcelTruck to arrive at the Package object's address, 
adds this time to the ParcelTruck's "current_time" parameter, calculates the number of miles the ParcelTruck will 
travel to deliver the Package, adds that number to the ParcelTruck's "miles" parameter, assigns the "delivered" status 
to the Package, updates the Package's "delivery_time" parameter using the ParcelTruck's new "current_time" parameter, 
and finally uses an "if" statement to compare the length of the "delivered" list to the length of the ParcelTruck's 
list of packages. If the lists are the same length, the algorithm determines that all packages are considered 
"delivered" and continues to the next part of the algorithm if so. 

The final "for" loop in the algorithm only applies to ParcelTruck "truck_1". If the ParcelTruck is "truck_1", the 
algorithm "returns" the ParcelTruck back to the "hub" so the driver of "truck_1" can be available to drive ParcelTruck 
"truck_3". This includes updating the "miles", "current_time", and "location" parameters of "truck_1"
(--- Space-Time Complexity -> O(N^2) - QUADRATIC ---)
"""


def nearest_neighbor(truck):
    truck_parcels = list(truck.packages)
    delivered = []
    # While there are still items in the truck_parcels list...
    while len(truck_parcels) > 0:
        closest_miles = 1000
        closest_pack = None
        not_delivered = []
        # Find the distance between the truck and each package represented in the truck_parcels list and set the
        # closest_pack as the package with the smallest distance from the truck itself.
        for parcels in truck_parcels:
            if find_distance(get_distance_index(truck.location[2]),
                             get_distance_index(package_hash.search(parcels).delivery_address)) < closest_miles:
                closest_pack = package_hash.search(parcels)
                closest_miles = find_distance(get_distance_index(truck.location[2]),
                                              get_distance_index(package_hash.search(
                                                  parcels).delivery_address))
                not_delivered.append(parcels)
            # If the current package being checked isn't closer than the last package, append it to the not_delivered
            # list and move to the next package. The not_delivered list will be re-called later to ensure all packages
            # get delivered.
            elif find_distance(get_distance_index(truck.location[2]),
                               get_distance_index(package_hash.search(parcels).delivery_address)) >= closest_miles:
                not_delivered.append(parcels)
        # Once all packages have been checked against a package, and it is determined to be the closest package to the
        # truck, append it to the delivered list, remove it from the truck_parcels list, adjust truck time, delivery
        # time, delivery status, and use the package_id_number to re-insert the updated information to the package_hash
        delivered.append(closest_pack)
        truck_parcels.remove(closest_pack.package_id_number)
        trip_minutes = round((find_distance(int(truck.location[0]), get_distance_index(
            closest_pack.delivery_address)) / truck.speed), 2) * 60
        truck.current_time = truck.current_time + datetime.timedelta(minutes=trip_minutes)
        truck.miles = round(truck.miles + find_distance(get_distance_index(truck.location[2]), get_distance_index(
            closest_pack.delivery_address)), 2)
        truck.location = set_truck_address(closest_pack.delivery_address)
        closest_pack.delivery_status = 'delivered'
        closest_pack.delivery_time = truck.current_time
        package_hash.insert(closest_pack.package_id_number, closest_pack)
        # If the list of delivered packages is shorter than the list of packages in the truck, the algorithm iterates
        # again until all packages have been delivered.
        if len(delivered) < len(truck.packages):
            continue
    # I decided not to "return" truck_2 and truck_3 to the hub since it was not required. This part of the algorithm
    # only executes for truck_1 and calculates its return trip and time to the hub so that the miles and time are
    # accounted for in the final mileage / time calculations.
    if truck == truck_1:
        hub_address = address_list[0]
        return_miles = round(find_distance(int(truck_1.location[0]), int(hub_address[0])), 2)
        return_minutes = round(return_miles / truck_1.speed, 2) * 60
        truck_1.miles = truck_1.miles + round(return_miles, 2)
        truck_1.current_time = truck_1.current_time + datetime.timedelta(minutes=return_minutes)
        truck_1.location = hub_address


# Calling the Nearest Neighbor algorithm for each truck.
nearest_neighbor(truck_1)
nearest_neighbor(truck_2)
nearest_neighbor(truck_3)

# Summing the mileage for all trucks. The variable total_miles will be used when the user enters "mileage" for the
# first console option.
total_miles = truck_1.miles + truck_2.miles + truck_3.miles

"""The 'time_format' function checks to ensure a user-entered time to check is in the proper format. It uses the 
built-in Python 'time.strptime' function to check the user-entered time and returns True or False depending on whether 
the value entered was in the proper format. Throws a ValueError exception if the user-entered time is not in proper 
format.

Code in this function was modified from code found on Stack Overflow.

***************************************************************************************
*    Title: How to decide if an string is in hh:mm format in python?"
*    Asking User: "alwbtc"
*    Answering User: "jro"
*    Date: February, 12, 2012
*    Code version: Unspecified
*    Availability: 
*    https://stackoverflow.com/questions/9190340/how-to-decide-if-an-string-is-in-hhmm-format-in-python/9190383#9190383
*
***************************************************************************************
(--- Space-Time Complexity -> O(1) - LINEAR ---)
"""


def time_format(input_string):
    try:
        time.strptime(input_string, '%H:%M:%S')
    # Throws an exception if the input string isn't properly formatted as instructed in the program introduction.
    except ValueError:
        return False
    return True


"""Below is the 'look-up function' for a single package (check_solo). The user is prompted to enter a Package ID 
Number. This number is verified to be greater than 1 and less than 40. If the package is pacakge number 9 and the 
check_time parameter is 10:20:00 or later, the function sets package #9's delivery_address to the corrected address 
and updates its special_note indicating the change. For any other valid package number, the function searches the 
package hash table for the package number, assigns it to a variable, adjusts the package's delivery status 
(at the hub, en route, delivered) using the check_time parameter and displays the package's updated information.
(--- Space-Time Complexity -> O(1) - CONSTANT ---)
"""


def check_solo(check_time):
    solo_package = int(input('Please enter a Package ID Number to check.\n>'))
    # Checks to make sure the package_id_number is valid for the task.
    if (solo_package < 1) or (solo_package > 40):
        print('Please enter a number between 1 and 40...\n')
        check_solo(check_time)
    # Package 9 has special instructions about its delivery address. It should be updated at 10:20, so this part checks
    # the user's entered time to make sure the package reflects the proper details for that time.
    elif solo_package == 9:
        if check_time >= datetime.timedelta(hours=10, minutes=20):
            reroute_package(9)
            package_hash.search(9).check_time_status(check_time)
            if package_hash.search(9).delivery_status == 'delivered':
                print(package_hash.search(9), end='')
                print(f'Delivery Time: {package_hash.search(9).delivery_time}\n')
            else:
                print(package_hash.search(9))
        else:
            package_hash.search(9).check_time_status(check_time)
            print(package_hash.search(9))
    # If everything above checks out, it is very simple to print a package to the console using the package_hash search
    # (or look-up) function.
    else:
        package_to_display = package_hash.search(solo_package)
        package_to_display.check_time_status(check_time)
        if package_to_display.delivery_status == 'delivered':
            print(package_to_display, end='')
            print(f'Delivery Time: {package_to_display.delivery_time}\n')
        else:
            print(package_to_display)


"""The 'check_all' function is the 'look-up function' executed when the user wants to see data on all Packages. It 
starts by simply printing a statement to show that all Package objects are bing checked at the user-indicated time. 
Then, it creates an empty list called 'all_packages' and a variable 'i' which will be used as an index in the 'while 
loop' just below. The 'while loop' searches the Package hash, where all package data is stored, and appends each 
Package's information to the 'all_packages' list. Next, the function checks whether the current Package object is 
Package 9. Package 9 has special instructions about its 'delivery_address' being wrong, as detailed above. Depending 
on the user-entered time, the function calls the 'reroute_package' function to update Package 9's information. Lastly, 
the function calls the 'check_time_status' function to update each package's 'delivery_status' parameter depending on 
the user-entered time and prints each package to the console. Successful completion of this function exits the program 
with all requested data printed to the console. (--- Space-Time Complexity -> O(N) - LINEAR ---)
 """


def check_all(check_all_time):
    print(f'Checking ALL Packages at {check_all_time}...\n')
    all_packages = []
    i = 1
    # While loop to iterate through package_hash table, printing each package as its package_id_number is called in the
    # search (look-up) function.
    while i < 41:
        all_packages.append(package_hash.search(i))
        i += 1
    for packages in all_packages:  # COMPLEXITY: O(N)
        packages.check_time_status(check_all_time)
        # Package 9 has specific instructions about the delivery address being updated at 10:20 and this uses the user
        # time input to update the pacakge as necessary for the submitted time.
        if packages.package_id_number == 9 and check_all_time >= datetime.timedelta(hours=10, minutes=20):
            reroute_package(9)
            package_hash.search(9).check_time_status(check_all_time)
            if package_hash.search(9).delivery_status == 'delivered':
                print(package_hash.search(9), end='')
                print(f'Delivery Time: {package_hash.search(9).delivery_time}\n')
            else:
                print(package_hash.search(9))
        elif packages.delivery_status == 'delivered':
            print(packages, end='')
            print(f'Delivery Time: {packages.delivery_time}\n')
        else:
            print(packages)


"""Here, I have programed the console-based programmer interface that will  be used to interact with the task 
submission. The user is welcomed with task and student information, after which the  user is prompted to type either 
'packages' or 'mileage', depending on the user's intent. Typing 'packages' results in  another input request for the 
time to check Package object status against. After this, the user will be asked to type  'solo' or 'all' to decide 
whether they would like to see information for a single package (by providing its unique  'package_id_number' or for 
all packages. The input is checked using a 'if choice_1 not in' statement to ensure the user  has entered proper input.
If the user typed 'packages' and inputs a time, the time data is checked using the  'time_format' function to ensure 
the user did not enter improperly formatted time data. At this point, the user has the  option to type 'solo' or 'all' 
as explained above.

If the user types 'mileage', there is no need to enter a time. The 'mileage' option prints the 'mileage' parameter 
value of each ParcelTruck object to the console after all deliveries have been made, as well as the total of all 
ParcelTruck objects combined.
(--- Space-Time Complexity -> O(N) - LINEAR ---)
 """

if __name__ == '__main__':
    # Displays a welcome message with student information in the console.
    print("**********\nWelcome! I hope you're having a great day.\nThis program was created by Adam Hanover for the \n"
          "WGU C950 - Data Structures & Algorithms course. (Student ID: 001385636) \nThank you for taking the time "
          "to evaluate my program!\n**********\n")
    # First time asking for user input. Depending on input, the user can request functions related to all packages,
    # specific packages, or route mileage.
    choice_1 = input('Type "packages" to check packages or "mileage" to check total mileage of the route.\n> ')
    # Ensures the user inputs "packages" or "mileage" and gives an error message then quits the program if neither
    # value is entered.
    if choice_1 not in ['packages', 'mileage']:
        print('Please restart the program and type either "packages" or "mileage" to proceed.')
        exit(0)
    # If the user typed "packages", they are prompted to enter a time to check a pacakge or all packages against.
    elif choice_1 == 'packages':
        time_input = input('What time would you like to check the status of the package(s)? \nPlease enter a time in '
                           '24-HR format ("Military Time") (HH:MM:SS)\n')
        # Uses the time_format() function to ensure the user's time was input in proper format. If it is, the program
        # asks the user to input "solo" or "all" to see one or all packages' data at the input time.
        # Displaying all packages has a Space-Time complexity of O(N) - LINEAR
        if time_format(time_input):
            [h, m, s] = time_input.split(":")
            time_to_check = datetime.timedelta(hours=int(h), minutes=int(m), seconds=int(s))
            type_input = input('Type "solo" to check a single package or "all" to see all packages.\n> ')
            if type_input == 'solo':
                check_solo(time_to_check)
            elif type_input == 'all':
                check_all(time_to_check)
        # If the time_format() function returns False, the program displays a message that the time format was incorrect
        # at which point the program exits.
        else:
            print('Please format your time in the following format: HH:MM:SS')
            exit(0)
    # If the user types "mileage" after the first program input prompt, the program prints the mileage of all trucks
    # individually and the total mileage as a whole, represented by the "total_miles" variable.
    elif choice_1 == 'mileage':
        print(f'Truck #1 Mileage: {round(truck_1.miles, 1)}')
        print(f'Truck #2 Mileage: {truck_2.miles}')
        print(f'Truck #3 Mileage: {truck_3.miles}')
        print(f'TOTAL MILEAGE: {total_miles}')
