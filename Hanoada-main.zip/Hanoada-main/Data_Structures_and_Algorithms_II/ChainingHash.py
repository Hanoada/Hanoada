"""This file defines the 'ChainingHash' class, which is a class that defines a hash function and table. Since this task
only requires manipulating 40 'Package' objects, I decided to make the size of the hash table (41). This should allow
for maximum efficiency since each Package object has a unique 'package_id_number' and therefore no collisions will
occur. This strategy also allows for minimal table size, since the program is not forced to create a table larger than
absolutely necessary to store the task's required data.

I have also created this hash map in using direct hashing. Sinch I know there are only 40 packages and each package has
a unique 'package_id_number' (the numbers 1 to 40), the hashing algorithm's bucket assignments are straightforward and
no complex hashing algorithm is required. That said, a mechanism is in place to allow for chaining collision control.

The 'insert()' function allows inserting new entries into the hash table using a unique key. In the case of this task,
the key used is the Package object's 'package_id_number' value. If the Package object already exists in the hash table,
the 'insert()' function updates the values of the Package object to match the values submitted in the function.

The 'search()' function allows searching for individual Package objects using their respective 'package_id_number'
values. These are also the key values used to map objects to the hash table, so retrieval is straightforward.

The 'remove()' function allows for objects to be removed from the hash table using their key value. In this case, a
'Package' object can be removed from the hash table using its 'package_id_number' value.

Portions of the code below are taken from the WGU ZyBook for the C950: Data Structures & Algorithms II course:
 Data Structures & Algorithms II > Hashing > 7.8 Python: Hash tables

***************************************************************************************
*    Title: C950: Data Structures & Algorithms II
*    Author: Lysecky, R., & Vahid, F.
*    Date: June, 2018
*    Code version: Unspecified
*    Availability: https://learn.zybooks.com/zybook/WGUC950AY20182019/chapter/7/section/8
*
***************************************************************************************
(--- Overall Space-Time Complexity -> O(N) - LINEAR ---)
"""


class ChainingHash:
    def __init__(self, size=41):
        # initialize the hash table with empty bucket list entries.
        # (--- Space-Time Complexity -> O(N) - LINEAR ---)
        self.table = []
        for i in range(size):
            self.table.append([])

    # Inserts a new item into the hash table.
    # (--- Space-Time Complexity -> O(1) - CONSTANT ---)
    def insert(self, key, value):
        # get the bucket list where this item will go.
        bucket = key
        bucket_list = self.table[bucket]

        for kv in bucket_list:
            if kv[0] == key:
                kv[1] = value
                return True

        # insert the item to the end of the bucket list.
        package_data = [key, value]
        bucket_list.append(package_data)
        return True

    # Searches for an item with matching key in the hash table.
    # Returns the item if found, or None if not found.
    # (--- Space-Time Complexity -> O(N) - LINEAR ---)
    def search(self, key):
        # get the bucket list where this key would be.
        if int(key) > 40 or int(key) < 1:
            return '***PACKAGE NOT FOUND***'
        bucket_list = self.table[key]
        key_found = False
        for index, record in enumerate(bucket_list):
            record_key, value = record

            if record_key == key:
                key_found = True
            if key_found:
                return value
            else:
                return "***PACKAGE NOT FOUND***"

    # Removes an item with matching key from the hash table.
    # (--- Space-Time Complexity -> O(N) - LINEAR ---)
    def remove(self, key):
        # get the bucket list where this item will be removed from.
        bucket = key
        bucket_list = self.table[bucket]

        # remove the item from the bucket list if it is present.
        if key in bucket_list:
            bucket_list.remove(key)
