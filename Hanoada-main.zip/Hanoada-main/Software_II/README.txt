APPLICATION TITLE: C195 GUI-Based Scheduling Application

APPLICATION PURPOSE: This application provides the ability for a user to add, delete, and update "Customers" and "Appointments", given authenticated login credentials. It is a scheduling application that ensures valid information is entered when creating "Cusomer" objects and "Appointment" objects. The application will not allow overlapping "Appointments" to be scheduled for any given "Customer".

AUTHOR: Adam Hanover

CONTACT INFORMATION...
EMAIL: ahanove@wgu.edu
PHONE: (435) 760-6536

APPLICATION VERSION NUMBER: 1.0.0.1

DATE: 9/9/2022

IDE (INTEGRATED DEVELOPMENT ENVIRONMENT) USED: IntelliJ IDEA 2021.1.3 (Community Edition) Build #IC-211.7628.21, built on June 30, 2021

JDK VERSION: jdk-17.0.1

JAVAFX VERSION: javafx-sdk-17.0.1

DIRECTIONS: 

1- Launch Application
2- Provide Valid Login Credentials
	- For the purposes of testing this application, use the following information to log in:
	- USERNAME: "test"
	- PASSWORD: "test"
3- Acknowledge the Alert regarding upcoming appointments by clicking the "OK" button.
4- To see a list of "Customers", click the "I'd like to see my Customers" button.
	4a- A list of ALL "Customers" automatically populates a TableView on-screen. You can choose to filter the list by "Country" using the "Select a Country" ComboBox in the top, right-hand corner of the screen. This can filter the "Customers" by their "Country" of residence (U.S, UK, Canada, All).
	4b- You can add a "Customer" by clicking the "Add a Customer" button on the bottom left-hand corner of the screen.
		4ba- This will take you to a new screen where you can fill-in the details of the new "Customer" you'd like to add to the database. The Customer ID is auto-generated, but all other fields are fillable/selectable.
		4bb- Clicking the "Save" button adds the "Customer" to the database.
		4bc- Clicking the "Cancel" button takes you back to the "Customers" screen.
	4c- You can update a "Customer" by selecting a "Customer" from the TableView and clicking the "Update Customer" button at the bottom of the screen. 
		4ca- This will take you to a new screen where the existing "Customer" data is automatically populated.
		4cb- You can choose to change (or not change) any of the "Customer" data, except the "Customer ID", which is automatically generated and uneditable.
		4cc- Clicking the "Save" button updates the selected Customer's information in the database.
		4cd- Clicking the "Cancel" button takes you back to the "Customers" screen.
	4d- You can delete a "Customer" by clicking the "Delete Customer" button at the bottom of the screen.
		4da- An Alert will show on-screen confirming your decision to delete the selected "Customer" and informing you that ALL "Appointments" associated with the selected "Customer" will also be deleted if you confirm your decision to delete the "Customer".
		4db- You must confirm or deny the deletion by clicking "CONFIRM" or "DENY" in the Alert that shows on-screen.
		4dc- Clicking "CONFIRM" deletes the "Customer" and ALL "Appointments" associated with the "Customer" in the database.
		4dd- Clicking "DENY" returns you to the "Customers" screen.
	4e- Clicking the "Back" button takes you to the "So glad to see you..." screen.
5- To see a list of "Appointments", click the "I'd like to see my Appointments" button.
	5a- A list of ALL "Appointments" automatically populates a TableView on-screen. You can choose to filter the list by "All Appointments", "Weekly (Next 7 Days)", or "Monthly (Next 30 Days)" using the Radio Buttons in the top right-hand corner of the screen.
	5b- You can add an "Appointment" by clicking the "Add Appointment" button on the bottom left-hand corner of the screen.
		5ba- This will take you to a new screen where you can fill-in the details of the new "Appointment" you'd like to add to the database. The Appointment ID is auto-generated, but all other fields are fillable/selectable.
		5bb- Clicking the "Save" button adds the "Appointment" to the database.
		5bc- Clicking the "Cancel" button takes you back to the "Appointments" screen.
	5c- You can update an "Appointment" by selecting an "Appointment" from the TableView and clicking the "Update Appointment" button at the bottom of the screen. 
		5ca- This will take you to a new screen where the existing "Appointment" data is automatically populated.
		5cb- You can choose to change (or not change) any of the "Appointment" data, except the "Appointment ID", which is automatically generated and uneditable.
		5cc- Clicking the "Save" button updates the selected Appointment information in the database.
		5cd- Clicking the "Cancel" button takes you back to the "Appointments" screen.
	5d- You can delete an "Appointment" by clicking the "Delete Appointment" button at the bottom of the screen.
		5da- An Alert will show on-screen confirming your decision to delete the selected "Appointment".
		5db- You must confirm or deny the deletion by clicking "CONFIRM" or "DENY" in the Alert that shows on-screen.
		5dc- Clicking "CONFIRM" deletes the "Appointment" from the database.
		5dd- Clicking "DENY" returns you to the "Appointment" screen.
	5e- Clicking the "Back" button takes you to the "So glad to see you..." screen.
6- To see all three "Reports" required for the application, click the "Let's run some Reports" button.
	6a- Three "Reports" will be automatically generated and populated into (3) separate TableViews on the "Reports" page.
	6b- The first "Report" is the "Appointment Count by Month and Type" "Report" required in the C195 Performance Assessment Requirements, and it displays the number of "Appointments" of each "Appointment Type" for each month of the year that are currently in the database.
	6c- The second "Report" is the "Contact Schedules" "Report" that shows ALL "Appointments" associated with the "Contact" whose name is in the ComboBox next to the "Report" title "Contact Schdules". 
		6ca- By default, "Anika Costa" is selected and the "Report" displays ALL "Appointments" associated with "Anika Costa". You can use the ComboBox to select another "Contact" to display the appointments associated with the selected "Contact". The TableView will automatically re-populate with correct data.
	6d- The third "Report" is a list of "Customers" and their account ages. It can be filtered by any TableColumn to see the oldest and newest "Customers".
	6e- Clicking the "Back" button takes you to the "So glad to see you..." screen.

DESCRIPTION OF ADDITIONAL REPORT:

I chose to include an additional "Report" that shows a list of all "Customers" and their respective "Account Age (In Days)". This report gets the "Customer_ID, Customer_Name, and Create_Date (named "Account Start Date" on the "Reports" page) for all "Customers" in the database. It uses each Customer's "Create_Date" to determine the age of the account in days using the difference between the "Create_Date" Timestamp and LocalDateTime.now() object. The addional "Report" uses a SQL statement to get the data and converts the java.sql.Timestamp object to a LocalDateTime object to perform the calculation. The calculation is stored as "long days = ChronoUnit.DAYS.between(LocalTimeStamp.toLocalDateTime(), LocalDateTime.now());"

As someone who has sold products online for several years, I know it can be valuable for a business to know their customers' account age. You can use a customer's account age to display your longest-standing customers and offer promotions based on this data. A business could also use the account age of a "Customer" to offer "anniversary" promotions when the customer's account age is equal to 365 days if desired.

MYSQL CONNECTOR DRIVER VERSION NUMBER (INCLUDING UPDATE NUMBER): mysql-connector-java-8.0.25