package Model;

import java.time.LocalDateTime;

/**
 * Used to create the <code>First_Level_Division</code> <code>Model</code> class. Used to reference
 * <code>First_Level_Division</code> (also known as <code>State / Province</code>) objects in the program.
 * Serves as a <code>Model</code> to get <code>Customer</code> information to and from the connected database.
 * */
public class First_Level_Division {
    public int Division_ID;
    public String Division;
    public LocalDateTime Create_Date;
    public String Created_By;
    public LocalDateTime Last_Update;
    public String Last_Updated_By;
    public int Country_ID;

    /**
     * Constructor is used to reference <code>First_Level_Division</code> objects in the program.
     * <code>First_Level_Division</code> objects are uneditable in the program.
     * <p></p>
     * @param Division_ID the <code>Division_ID</code> associated with the referenced <code>Customer</code>. <b>Cannot be edited</b> by
     *                       the <code>User</code> and is retrieved from the connected database.
     * @param Division the <code>Division</code>, <code>First_Level_Division</code>, or <code>State / Province</code> associated with the referenced <code>Customer</code>.
     * @param Create_Date the <code>Create_Date</code> associated with the referenced <code>Customer</code>, in <code>LocalDateTime</code> format.
     * @param Created_By the <code>User</code> attributed to the creation of the associated <code>Customer</code>.
     * @param Last_Update the <code>Last_Update</code> date associated with the referenced <code>Customer</code>, in <code>LocalDateTime</code> format.
     * @param Last_Updated_By the <code>User</code> attributed to the last update made to the associated <code>Customer</code>.
     * @param Country_ID the <code>Country_ID</code> associated with the referenced <code>Customer</code>,
     *                    representing the <code>Country</code> selected from the "Select a Country" ComboBox found in the
     *                    <code>AddCustomer</code> and <code>UpdateCustomer</code> scenes.
     * */
    public First_Level_Division(int Division_ID, String Division, LocalDateTime Create_Date, String Created_By, LocalDateTime Last_Update, String Last_Updated_By, int Country_ID) {
        this.Division_ID = Division_ID;
        this.Division = Division;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;
        this.Country_ID = Country_ID;
    }

    /**
     * Gets the <code>Division_ID</code>, <code>First_Level_Division</code> ID, or <code>State / Province</code> ID for a selected <code>Customer</code>.
     * @return the <code>Division_ID</code> for a selected <code>Customer</code>.
     * */
    public int getfldId() {
        return Division_ID;
    }

    /**
     * Gets the <code>Division</code> Name, <code>First_Level_Division</code> Name, or <code>State / Province</code> Name for a selected <code>Customer</code>.
     * @return the <code>Division</code> Name for a selected <code>Customer</code>.
     * */
    public String getFldName() {
        return Division;
    }

    /**
     * Provides the ability to get <code>User</code>-friendly text versions of <code>First_Level_Division</code> Names for
     * display throughout the program.
     * */
    @Override
    public String toString(){
        return (Division);
    }
}


