package Model;

import java.sql.Timestamp;

/**
 * Used to create the <code>User</code> <code>Model</code> class. Used to reference <code>User</code> objects in the program.
 * Serves as a <code>Model</code> to get <code>User</code> information to and from the connected database.
 * */
public class User {
    public int User_ID;
    public String User_Name;
    public String Password;
    public Timestamp Create_Date;
    public String Created_By;
    public Timestamp Last_Update;
    public String Last_Updated_By;

    /**
     * Constructor is used to reference <code>User</code> objects in the program. Each <code>User</code>
     * has a <b>unique</b> <code>User_ID</code> that is retrieved from the connected database and <b>cannot be edited</b> by the <code>User</code>.
     * <p></p>
     * @param User_ID the <code>User_ID</code> associated with the referenced <code>User</code>. <b>Cannot be edited</b> by
     *                       the <code>User</code> and is retrieved from the connected database.
     * @param User_Name the <code>User_Name</code> associated with the referenced <code>User</code>.
     * @param Password the <code>Password</code> associated with the referenced <code>User</code>.
     * @param Create_Date the <code>Create_Date</code> associated with the referenced <code>User</code>, in <code>LocalDateTime</code> format.
     * @param Created_By the <code>User</code> attributed to the creation of the associated <code>User</code>.
     * @param Last_Update the <code>Last_Update</code> date associated with the referenced <code>User</code>, in <code>LocalDateTime</code> format.
     * @param Last_Updated_By the <code>User</code> attributed to the last update made to the associated <code>User</code>.
     * */
    public User(int User_ID, String User_Name, String Password, Timestamp Create_Date, String Created_By, Timestamp Last_Update, String Last_Updated_By){
        this.User_ID = User_ID;
        this.User_Name = User_Name;
        this.Password = Password;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;

    }
    //GETTERS

    /**
     * Gets the <code>User_ID</code> for a selected <code>User</code>.
     * @return the <code>User_ID</code> for a selected <code>User</code>.
     * */
    public int getUser_ID() {
        return User_ID;
    }

    /**
     * Gets the <code>User_Name</code> for a selected <code>User</code>.
     * @return the <code>User_Name</code> for a selected <code>User</code>.
     * */
    public String getUser_Name() {
        return User_Name;
    }

    /**
     * Gets the <code>Password</code> for a selected <code>User</code>.
     * @return the <code>Password</code> for a selected <code>User</code>.
     * */
    public String getPassword() {
        return Password;
    }

    /**
     * Gets the <code>Create_Date</code> for a selected <code>User</code>.
     * @return the <code>Create_Date</code> for a selected <code>User</code>.
     * */
    public Timestamp getCreate_Date() {
        return Create_Date;
    }

    /**
     * Gets the <code>User</code> associated with the creation of a selected <code>User</code>.
     * @return the <code>User</code> associated with the creation of a selected <code>User</code>.
     * */
    public String getCreated_By() {
        return Created_By;
    }

    /**
     * Gets the <code>Last_Update</code> date for a selected <code>User</code>.
     * @return the <code>Last_Update</code> date for a selected <code>User</code>, in the form of a <code>Timestamp</code>.
     * */
    public Timestamp getLast_Update() {
        return Last_Update;
    }

    /**
     * Gets the <code>Username</code> associated with the last update of a selected <code>User</code>.
     * @return the <code>Username</code> associated with the last update of a selected <code>User</code>.
     * */
    public String getLast_Updated_By() {
        return Last_Updated_By;
    }

    /**
     * Provides the ability to get <code>User</code>-friendly text versions of each <code>User</code> parameter for
     * use throughout the program.
     * */
    @Override
    public String toString(){
        return (User_ID + User_Name + Password + Create_Date + Created_By + Last_Update + Last_Updated_By);
    }
}
