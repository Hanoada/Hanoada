package Model;

/**
 * Used to create the <code>Countries</code> <code>Model</code> class. Serves as a <code>Model</code> to reference
 * <code>Countries</code> information from the connected database.
 * */
public class Countries {
    private final int id;
    private final String name;

    /**
     * Constructor is used to reference <code>Countries</code> objects in the program, specifically for use in
     * the "Select a Country" ComboBoxes in the <code>AddCustomer</code> and <code>UpdateCustomer</code> scenes.
     * <p>/-----------------------------------------------------------/</p>
     * @param id the <code>Country_ID</code> associated with the referenced <code>Country</code> retrieved from the local database.
     * @param name the <code>Country</code> associated with the referenced <code>Country</code> retrieved from the local database.
     * */
    public Countries(int id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Gets the <code>Country_ID</code> for a selected <code>Countries</code> object.
     * @return the <code>Country_ID</code> for a selected <code>Countries</code> object.
     * */
    public int getId() {
        return id;
    }

    /**
     * Gets the <code>Country</code> name for a selected <code>Countries</code> object.
     * @return the <code>Country</code> name for a selected <code>Countries</code> object.
     * */
    public String getName() {
        return name;
    }

    /**
     * Provides the ability to get a <code>User</code>-friendly text version of the <code>Country</code> Name parameter for
     * display throughout the program.
     * */
    @Override
    public String toString(){
        return (name);
    }
}
