package Model;

/**
 * Used to create the <code>Contact</code> <code>Model</code> class. Serves as a <code>Model</code> to reference
 * <code>Contact</code> information from the connected database.
 * */
public class Contact {
    private final int contactId;
    private final String contactName;
    private final String contactEmail;

    /**
     * Constructor is used to reference <code>Contact</code> objects in the program, specifically for use in the
     * "Select a Contact" ComboBoxes in the <code>AddAppointment</code> and <code>UpdateAppointment</code> scenes.
     * <p>/-----------------------------------------------------------/</p>
     * @param contactId the <code>Contact_ID</code> associated with the referenced <code>Contact</code> retrieved from
     *                  the local database.
     * @param contactName the <code>Contact_Name</code> associated with the referenced <code>Contact</code> retrieved from
     *                    the local database.
     * @param contactEmail the <code>Email</code> associated with the referenced <code>Contact</code> retrieved from
     *                     the local database.
     * */
    public Contact(int contactId, String contactName, String contactEmail){
        this.contactId = contactId;
        this.contactName = contactName;
        this.contactEmail = contactEmail;
    }

    /**
     * Gets the <code>Contact_ID</code> for a selected <code>Contact</code>.
     * @return the <code>Contact_ID</code> for a selected <code>Contact</code>.
     * */
    public int getContactId() {return contactId;}

    /**
     * Gets the <code>Contact_Name</code> for a selected <code>Contact</code>.
     * @return the <code>Contact_Name</code> for a selected <code>Contact</code>.
     * */
    public String getContactName() {return contactName;}

    /**
     * Gets the <code>Email</code> for a selected <code>Contact</code>.
     * @return the <code>Email</code> for a selected <code>Contact</code>.
     * */
    public String getContactEmail() {return contactEmail;}

    /**
     * Provides the ability to get a <code>User</code>-friendly text version of the <code>Contact_Name</code> parameter for
     * display throughout the program.
     * */
    @Override
    public String toString(){return (contactName);}
}
