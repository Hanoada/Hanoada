package Model;

import DBAccess.DBFirst_Level_Divisions;

import java.time.LocalDateTime;

/**
 * Used to create the <code>Customer</code> <code>Model</code> class. Used to create <code>Customer</code>
 * objects in the program. Serves as a <code>Model</code> to get <code>Customer</code> information to and from the connected database.
 * */
public class Customer {
    public int accountAge;
    public int Customer_ID;
    public String Customer_Name;
    public String Address;
    public String Postal_Code;
    public String Phone;
    public LocalDateTime Create_Date;
    public String Created_By;
    public LocalDateTime Last_Update;
    public String Last_Updated_By;
    public int Division_ID;
    public String customerDivision;
    public String customerCountry;


    /**
     * Constructor is used to create <code>Customer</code> objects in the program. Each <code>Customer</code>
     * has a <b>unique</b> <code>Customer_ID</code> that is <b>automatically-generated</b> and <b>cannot be edited</b> by the <code>User</code>.
     * <p>/-----------------------------------------------------------/</p>
     * @param Customer_Id the <code>Customer_ID</code> associated with the referenced <code>Customer</code>. <b>Cannot be edited</b> by
     *                       the <code>User</code> and is <b>automatically-generated</b>.
     * @param Customer_Name the <code>Customer_Name</code> associated with the referenced <code>Customer</code>.
     * @param Address the <code>Address</code> associated with the referenced <code>Customer</code>.
     * @param Postal_Code the <code>Postal_Code</code> associated with the referenced <code>Customer</code>.
     * @param Phone the <code>Phone</code> number associated with the referenced <code>Customer</code>.
     * @param Create_Date the <code>Create_Date</code> associated with the referenced <code>Customer</code>, in <code>LocalDateTime</code> format.
     * @param Created_By the <code>User</code> attributed to the creation of the associated <code>Customer</code>.
     * @param Last_Update the <code>Last_Update</code> date associated with the referenced <code>Customer</code>, in <code>LocalDateTime</code> format.
     * @param Last_Updated_By the <code>User</code> attributed to the last update made to the associated <code>Customer</code>.
     * @param Division_ID the <code>Division_ID</code> associated with the referenced <code>Customer</code>,
     *                    representing the <code>First_Level_Division</code> (or <code>State / Province</code>) selected
     *                    from the "Select a State or Province" ComboBox found in the <code>AddCustomer</code> and
     *                    <code>UpdateCustomer</code> scenes.
     * */
    public Customer(int Customer_Id, String Customer_Name, String Address, String Postal_Code, String Phone, LocalDateTime Create_Date,
                    String Created_By, LocalDateTime Last_Update, String Last_Updated_By, int Division_ID) {
        this.Customer_ID = Customer_Id;
        this.Customer_Name = Customer_Name;
        this.Address = Address;
        this.Postal_Code = Postal_Code;
        this.Phone = Phone;
        this. Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;
        this.Division_ID = Division_ID;
    }

    /**
     * Constructor is used to create <code>Customer</code> objects in the program. Each <code>Customer</code>
     * has a <b>unique</b> <code>Customer_ID</code> that is <b>automatically-generated</b> and <b>cannot be edited</b> by the <code>User</code>.
     * This constructor is specifically used to display <code>User</code>-friendly text values in the <code>Customers</code> scene TableView.
     * <p>/-----------------------------------------------------------/</p>
     * @param customerID the <code>Customer_ID</code> associated with the referenced <code>Customer</code>. <b>Cannot be edited</b> by
     *                       the <code>User</code> and is <b>automatically-generated</b>.
     * @param customerName the <code>Customer_Name</code> associated with the referenced <code>Customer</code>.
     * @param customerAddress the <code>Address</code> associated with the referenced <code>Customer</code>.
     * @param customerPostalCode the <code>Postal_Code</code> associated with the referenced <code>Customer</code>.
     * @param customerPhone the <code>Phone</code> number associated with the referenced <code>Customer</code>.
     * @param create_date the <code>Create_Date</code> associated with the referenced <code>Customer</code>, in <code>LocalDateTime</code> format.
     * @param customerCreatedBy the <code>User</code> attributed to the creation of the associated <code>Customer</code>.
     * @param last_update the <code>Last_Update</code> date associated with the referenced <code>Customer</code>, in <code>LocalDateTime</code> format.
     * @param customerLastUpdatedBy the <code>User</code> attributed to the last update made to the associated <code>Customer</code>.
     * @param customerDivisionID the <code>Division_ID</code> associated with the referenced <code>Customer</code>,
     *                    representing the <code>First_Level_Division</code> (or <code>State / Province</code>) selected
     *                    from the "Select a State or Province" ComboBox found in the <code>AddCustomer</code> and
     *                    <code>UpdateCustomer</code> scenes.
     * @param customerDivision the <code>State / Province</code> associated with the referenced <code>Customer</code>,
     *                         representing the <code>First_Level_Division</code> (or <code>State / Province</code>) selected
     *                         from the "Select a State or Province" ComboBox found in the <code>AddCustomer</code> and
     *                         <code>UpdateCustomer</code> scenes. Displayed as <code>User</code>-friendly text in the
     *                         <code>Customers</code> TableView.
     * @param customerCountry the <code>Country</code> Name associated with the referenced <code>Customer</code>,
     *                        representing the <code>Country</code> selected from the "Select a Country" ComboBox found
     *                        in the <code>AddCustomer</code> and <code>UpdateCustomer</code> scenes. Displayed as
     *                        <code>User</code>-friendly text in the <code>Customers</code> TableView.
     * */
    public Customer(int customerID, String customerName, String customerAddress, String customerPostalCode, String customerPhone,
                    LocalDateTime create_date, String customerCreatedBy, LocalDateTime last_update, String customerLastUpdatedBy,
                    int customerDivisionID, String customerDivision, String customerCountry) {
        this.Customer_ID = customerID;
        this.Customer_Name = customerName;
        this.Address = customerAddress;
        this.Postal_Code = customerPostalCode;
        this.Phone = customerPhone;
        this. Create_Date = create_date;
        this.Created_By = customerCreatedBy;
        this.Last_Update = last_update;
        this.Last_Updated_By = customerLastUpdatedBy;
        this.Division_ID = customerDivisionID;
        this.customerDivision = customerDivision;
        this.customerCountry = customerCountry;
    }

    /**
     * Constructor is used to create <code>Customer</code> objects in the program. Each <code>Customer</code>
     * has a <b>unique</b> <code>Customer_ID</code> that is <b>automatically-generated</b> and <b>cannot be edited</b> by the <code>User</code>.
     * This constructor is specifically used to display <code>User</code>-friendly text values in the <code>Reports</code>
     * Custom <code>Report</code> TableView.
     * <p>/-----------------------------------------------------------/</p>
     * @param Customer_Id the <code>Customer_ID</code> associated with the referenced <code>Customer</code>. <b>Cannot be edited</b> by
     *                       the <code>User</code> and is <b>automatically-generated</b>.
     * @param Customer_Name the <code>Customer_Name</code> associated with the referenced <code>Customer</code>.
     * @param Create_Date the <code>Create_Date</code> associated with the creation of the <code>Customer</code>.
     * @param accountAge the account age associated with the referenced <code>Customer</code>. Used to determine seniority of
     *                   <code>Customer</code> accounts.
     * */
    public Customer(int Customer_Id, String Customer_Name, LocalDateTime Create_Date, int accountAge) {
        this.Customer_ID = Customer_Id;
        this.Customer_Name = Customer_Name;
        this.Create_Date = Create_Date;
        this.accountAge = accountAge;
    }

    //SETTERS
    /**
     * Sets the <code>State / Province</code> (also known as the <code>First_Level_Divison</code> for a <code>Customer</code> object.
     * @param customerDivision This is the <code>First_Level_Division</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setCustomerDivision(String customerDivision) {
        this.customerDivision = customerDivision;
    }

    /**
     * Sets the <code>Country</code> for a <code>Customer</code> object.
     * @param customerCountry This is the <code>Country</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setCustomerCountry(String customerCountry) {
        this.customerCountry = customerCountry;
    }

    /**
     * Sets the <code>Customer_ID</code> for a <code>Customer</code> object.
     * @param customer_ID This is the <code>Customer_ID</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setCustomer_ID(int customer_ID) {
        Customer_ID = customer_ID;
    }

    /**
     * Sets the <code>Customer_Name</code> for a <code>Customer</code> object.
     * @param customer_Name This is the <code>Customer_Name</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setCustomer_Name(String customer_Name) {
        Customer_Name = customer_Name;
    }

    /**
     * Sets the <code>Address</code> for a <code>Customer</code> object.
     * @param address This is the <code>Address</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setAddress(String address) {
        Address = address;
    }

    /**
     * Sets the <code>Postal_Code</code> for a <code>Customer</code> object.
     * @param postal_Code This is the <code>Postal_Code</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setPostal_Code(String postal_Code) {
        Postal_Code = postal_Code;
    }

    /**
     * Sets the <code>Phone</code> Number for a <code>Customer</code> object.
     * @param phone This is the <code>Phone</code> Number that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setPhone(String phone) {
        Phone = phone;
    }

    /**
     * Sets the <code>Create_Date</code> for a <code>Customer</code> object.
     * @param create_Date This is the <code>Create_Date</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setCreate_Date(LocalDateTime create_Date) {
        Create_Date = create_Date;
    }

    /**
     * Sets the <code>User</code> associated with the creation of the <code>Customer</code> object.
     * @param created_By This is the <code>User</code> that is associated with the creation of the <code>Customer</code>.
     * */
    public void setCreated_By(String created_By) {
        Created_By = created_By;
    }

    /**
     * Sets the <code>Last_Update</code> date for a <code>Customer</code> object.
     * @param last_Update This is the date of the <code>Last_Update</code> performed on the referenced <code>Customer</code>.
     * */
    public void setLast_Update(LocalDateTime last_Update) {
        Last_Update = last_Update;
    }

    /**
     * Sets the <code>User</code> who last updated the referenced <code>Customer</code> object.
     * @param last_Updated_By This is the <code>User</code> who last updated the referenced <code>Customer</code>.
     * */
    public void setLast_Updated_By(String last_Updated_By) {
        Last_Updated_By = last_Updated_By;
    }

    /**
     * Sets the <code>Division_ID</code> for a <code>Customer</code> object. This is an ID related to a <code>First_Level_Division</code>.
     * @param division_ID This is the <code>Division_ID</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setDivision_ID(int division_ID) {
        Division_ID = division_ID;
    }

    /**
     * Sets the <code>accountAge</code> for a <code>Customer</code> object.
     * @param accountAge This is the <code>accountAge</code> that will be assigned to the referenced <code>Customer</code>.
     * */
    public void setAccountAge(int accountAge) {
        this.accountAge = accountAge;
    }


    //GETTERS
    /**
     * Gets the <code>First_Level_Division</code> for a selected <code>Customer</code>.
     * @return the <code>First_Level_Division</code> (or <code>State / Province</code>) for a selected <code>Customer</code>.
     * */
    public String getCustomerDivision() {
        return customerDivision;
    }

    /**
     * Gets the <code>Country</code> for a selected <code>Customer</code>.
     * @return the <code>Country</code> for a selected <code>Customer</code>.
     * */
    public String getCustomerCountry() {
        return customerCountry;
    }

    /**
     * Gets the <code>Customer_ID</code> for a selected <code>Customer</code>.
     * @return the <code>Customer_ID</code> for a selected <code>Customer</code>.
     * */
    public int getCustomer_ID() {
        return Customer_ID;
    }

    /**
     * Gets the <code>Customer_Name</code> for a selected <code>Customer</code>.
     * @return the <code>Customer_Name</code> for a selected <code>Customer</code>.
     * */
    public String getCustomer_Name() {
        return Customer_Name;
    }

    /**
     * Gets the <code>Address</code> for a selected <code>Customer</code>.
     * @return the <code>Address</code> for a selected <code>Customer</code>.
     * */
    public String getAddress() {
        return Address;
    }

    /**
     * Gets the <code>Postal_Code</code> for a selected <code>Customer</code>.
     * @return the <code>Postal_Code</code> for a selected <code>Customer</code>.
     * */
    public String getPostal_Code() {
        return Postal_Code;
    }

    /**
     * Gets the <code>Phone</code> Number for a selected <code>Customer</code>.
     * @return the <code>Phone</code> Number for a selected <code>Customer</code>.
     * */
    public String getPhone() {
        return Phone;
    }

    /**
     * Gets the <code>Create_Date</code> for a selected <code>Customer</code>.
     * @return the <code>Create_Date</code> for a selected <code>Customer</code>.
     * */
    public LocalDateTime getCreate_Date() {
        return Create_Date;
    }

    /**
     * Gets the <code>Created_By</code> <code>User</code> for a selected <code>Customer</code>.
     * @return the <code>Created_By</code> <code>User</code> for a selected <code>Customer</code>.
     * */
    public String getCreated_By() {
        return Created_By;
    }

    /**
     * Gets the <code>Last_Update</code> Date for a selected <code>Customer</code>.
     * @return the <code>Last_Update</code> Date for a selected <code>Customer</code>.
     * */
    public LocalDateTime getLast_Update() {
        return Last_Update;
    }

    /**
     * Gets the <code>Last_Updated_By</code> <code>User</code> for a selected <code>Customer</code>.
     * @return the <code>Last_Updated_By</code> <code>User</code> for a selected <code>Customer</code>.
     * */
    public String getLast_Updated_By() {
        return Last_Updated_By;
    }

    /**
     * Gets the <code>Division_ID</code> for a selected <code>Customer</code>.
     * @return the <code>Division_ID</code> for a selected <code>Customer</code>.
     * */
    public int getDivision_ID() {
        return Division_ID;
    }

    /**
     * Gets the <code>accountAge</code> for a selected <code>Customer</code>.
     * @return the <code>accountAge</code> for a selected <code>Customer</code>.
     * */
    public int getAccountAge() {
        return accountAge;
    }


    /**
     * Gets the <code>Country</code> for a selected <code>Customer</code>. Returns the <code>First_Level_Division</code>
     * (or <code>State / Province</code>) for a selected <code>Customer</code>.
     * @param customer The <code>Customer</code> to search for in the <code>DBFirst_Level_Divisions.getAllFirstLevelDivisions()</code>
     *                 method. Used when specifically seeking the <code>Customer</code>'s <code>State / Province</code> of residence.
     * @return First_Level_Division The <code>First_Level_Division</code> (also known as "<code>State / Province</code>"
     * of the <code>Customer</code> passed to the method.
     * */
    public First_Level_Division getState (Customer customer) {
        for (int i = 0; i < DBFirst_Level_Divisions.getAllFirstLeveLDivisions().size(); ++i){
            if (DBFirst_Level_Divisions.getAllFirstLeveLDivisions().get(i).Division_ID == (customer.getDivision_ID())) {
                return DBFirst_Level_Divisions.getAllFirstLeveLDivisions().get(i);
            }
        }
        return null;
    }

    /**
     * Provides the ability to get <code>User</code>-friendly text versions of each <code>Customer</code> parameter for
     * display throughout the program.
     * */
    @Override
    public String toString(){
        return (Customer_ID + Customer_Name + Address + Postal_Code + Phone + Create_Date + Created_By + Last_Update + Last_Updated_By + customerDivision + customerCountry);
    }
}
