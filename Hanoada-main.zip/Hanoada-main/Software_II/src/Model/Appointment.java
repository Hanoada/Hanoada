package Model;

import java.time.LocalDateTime;

/**
 * Used to create the <code>Appointment</code> <code>Model</code> class. Used to create <code>Appointment</code>
 * objects in the program. Serves as a <code>Model</code> to get <code>Appointment</code> information to and from the connected database.
 * */
public class Appointment{
    public int appointmentTypeCount;
    public String appointmentMonthString;
    public int Appointment_ID;
    public String Title;
    public String Description;
    public String Location;
    public String Type;
    public LocalDateTime Start;
    public LocalDateTime End;
    public LocalDateTime Create_Date;
    public String Created_By;
    public LocalDateTime Last_Update;
    public String Last_Updated_By;
    public int Customer_ID;
    public int User_ID;
    public int Contact_ID;
    public String Contact_Name;

    /**
     * Constructor is used to create <code>Appointment</code> objects in the program. Each <code>Appointment</code>
     * has a <b>unique</b> <code>Appointment_ID</code> that is <b>automatically-generated</b> and <b>cannot be edited</b> by the <code>User</code>.
     * @param Appointment_ID the <code>Appointment_ID</code> associated with the referenced <code>Appointment</code>. <b>Cannot be edited</b> by
     *                       the <code>User</code> and is <b>automatically-generated</b>.
     * @param Title the <code>Title</code> associated with the referenced <code>Appointment</code>.
     * @param Description the <code>Description</code> associated with the referenced <code>Appointment</code>.
     * @param Location the <code>Location</code> associated with the referenced <code>Appointment</code>.
     * @param Type the <code>Type</code> associated with the referenced <code>Appointment</code>.
     * @param Start the <code>Start Date / Time</code> associated with the referenced <code>Appointment</code>, in <code>LocalDateTime</code> format.
     * @param End the <code>End Date / Time </code> associated with the referenced <code>Appointment</code>, in <code>LocalDateTime</code> format.
     * @param Create_Date the <code>Create_Date</code> associated with the referenced <code>Appointment</code>, in <code>LocalDateTime</code> format.
     * @param Created_By the <code>User</code> attributed to the creation of the associated <code>Appointment</code>.
     * @param Last_Update the <code>Last_Update</code> date associated with the referenced <code>Appointment</code>, in <code>LocalDateTime</code> format.
     * @param Last_Updated_By the <code>User</code> attributed to the last update made to the associated <code>Appointment</code>.
     * @param Customer_ID the <code>Customer_ID</code> associated with the referenced <code>Appointment</code>,
     *                    representing the <code>Customer</code> selected from the "Select a Customer" ComboBox found in the
     *                    <code>AddAppointment</code> and <code>UpdateAppointment</code> scenes.
     * @param User_ID the <code>User_ID</code> associated with the referenced <code>Appointment</code>, representing the
     *                <code>User_ID</code> selected from the "Pick a User ID" ComboBox found in the <code>AddAppointment</code>
     *                and <code>UpdateAppointment</code> scenes.
     * @param Contact_ID the <code>Contact_ID</code> associated with the referenced <code>Appointment</code>, representing the
     *                   <code>Contact_ID</code> selected from the "Pick a Contact ID" ComboBox found in the <code>AddAppointment</code>
     *                   and <code>UpdateAppointment</code> scenes.
     * @param Contact_Name the <code>Contact_Name</code> associated with the referenced <code>Appointment</code>, representing the
     *                     <code>Contact Name</code> selected from the "Select a Contact" ComboBox found in the <code>AddAppointment</code>
     *                     and <code>UpdateAppointment</code> scenes.
     * */
    public Appointment(int Appointment_ID, String Title, String Description, String Location, String Type, LocalDateTime Start, LocalDateTime End,
                       LocalDateTime Create_Date, String Created_By, LocalDateTime Last_Update, String Last_Updated_By,
                       int Customer_ID, int User_ID, int Contact_ID, String Contact_Name) {
        this.Appointment_ID = Appointment_ID;
        this.Title = Title;
        this.Description = Description;
        this.Location = Location;
        this.Type = Type;
        this.Start = Start;
        this.End = End;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;
        this.Customer_ID = Customer_ID;
        this.User_ID = User_ID;
        this.Contact_ID = Contact_ID;
        this.Contact_Name = Contact_Name;
    }

    /**
     * Constructor is used to populate the <code>Appointment</code> TableView in the <code>Reports</code> scene.
     * This constructor is not used anywhere else in the program.
     * @param appointmentMonthString Displays a <code>User</code>-friendly text version of the month associated with <code>Appointment</code>s
     *                               in the "Number of Appointments by Type and Month" <code>Report</code> on the <code>Reports</code> scene.
     * @param appointmentType Displays a <code>User</code>-friendly text version of the <code>Type</code> associated with <code>Appointment</code>s
     *                        in the "Number of Appointments by Type and Month" <code>Report</code> on the <code>Reports</code> scene.
     * @param appointmentTypeCount Displays a total count of all <code>Appointment</code> <code>Type</code>s associated with <code>Appointment</code>s
     *                             in the "Number of Appointments by Type and Month" <code>Report</code> on the <code>Reports</code> scene
     * */
    public Appointment(String appointmentMonthString, String appointmentType, int appointmentTypeCount) {
        this.appointmentMonthString = appointmentMonthString;
        this.Type = appointmentType;
        this.appointmentTypeCount = appointmentTypeCount;
    }

    /**
     * Sets the <code>Type</code> for an <code>Appointment</code> object.
     * @param type This is the <code>Type</code> that will be assigned to the selected <code>Appointment</code>.
     * */
    public void setType(String type) {Type = type;}

    /**
     * Gets the <code>Appointment_ID</code> for a selected <code>Appointment</code>.
     * @return the <code>Appointment_ID</code> for a selected <code>Appointment</code>.
     * */
    public int getAppointment_ID() {return Appointment_ID;}

    /**
     * Gets the <code>Title</code> for a selected <code>Appointment</code>.
     * @return the <code>Title</code> for a selected <code>Appointment</code>.
     * */
    public String getTitle() {
        return Title;
    }

    /**
     * Gets the <code>Description</code> for a selected <code>Appointment</code>.
     * @return the <code>Description</code> for a selected <code>Appointment</code>.
     * */
    public String getDescription() {
        return Description;
    }

    /**
     * Gets the <code>Location</code> for a selected <code>Appointment</code>.
     * @return the <code>Location</code> for a selected <code>Appointment</code>.
     * */
    public String getLocation() {
        return Location;
    }

    /**
     * Gets the <code>Type</code> for a selected <code>Appointment</code>.
     * @return the <code>Type</code> for a selected <code>Appointment</code>.
     * */
    public String getType() {
        return Type;
    }

    /**
     * Gets the <code>Start Date / Time</code> for a selected <code>Appointment</code>.
     * @return the <code>Start Date / Time</code> for a selected <code>Appointment</code>.
     * */
    public LocalDateTime getStart() {
        return Start;
    }

    /**
     * Gets the <code>End Date / Time</code> for a selected <code>Appointment</code>.
     * @return the <code>End Date / Time</code> for a selected <code>Appointment</code>.
     * */
    public LocalDateTime getEnd() {return End;}

    /**
     * Gets the <code>Create_Date</code> for a selected <code>Appointment</code>.
     * @return the <code>Create_Date</code> for a selected <code>Appointment</code>.
     * */
    public LocalDateTime getCreate_Date() {return Create_Date;}

    /**
     * Gets the <code>User</code> associated with creating the selected <code>Appointment</code> as a <code>String</code>.
     * @return the <code>User</code> associated with creating the selected <code>Appointment</code> as a <code>String</code>.
     * */
    public String getCreated_By() {return Created_By;}

    /**
     * Gets the <code>Last_Update</code> for a selected <code>Appointment</code> as a <code>LocalDateTime</code> object.
     * @return the <code>Last_Update</code> for a selected <code>Appointment</code> as a <code>LocalDateTime</code> object.
     * */
    public LocalDateTime getLast_Update() {return Last_Update;}

    /**
     * Gets the <code>User</code> associated with the most recent updates for a selected <code>Appointment</code> as a <code>String</code>.
     * @return the <code>User</code> associated with the most recent updates for a selected <code>Appointment</code> as a <code>String</code>.
     * */
    public String getLast_Updated_By() {return Last_Updated_By;}

    /**
     * Gets the <code>Customer_ID</code> for a selected <code>Appointment</code>.
     * @return the <code>Customer_ID</code> for a selected <code>Appointment</code>.
     * */
    public int getCustomer_ID() {return Customer_ID;}

    /**
     * Gets the <code>User_ID</code> for a selected <code>Appointment</code>.
     * @return the <code>User_ID</code> for a selected <code>Appointment</code>.
     * */
    public int getUser_ID() {return User_ID;}

    /**
     * Gets the <code>Contact_ID</code> for a selected <code>Appointment</code>.
     * @return the <code>Contact_ID</code> for a selected <code>Appointment</code>.
     * */
    public int getContact_ID() {return Contact_ID;}

    /**
     * Gets the <code>Contact_Name</code> for a selected <code>Appointment</code>.
     * @return the <code>Contact_Name</code> for a selected <code>Appointment</code>.
     * */
    public String getContact_Name() { return Contact_Name; }

    /**
     * Gets the <code>Appointment</code> <code>Type</code> count for the "Total Number of
     * Appointments by Type and Month" <code>Report</code> on the <code>Reports</code> scene.
     * @return the <code>Appointment</code> <code>Type</code> count for the "Total Number of
     * Appointments by Type and Month" <code>Report</code> on the <code>Reports</code> scene.
     * */
    public int getAppointmentTypeCount() {return appointmentTypeCount;}

    /**
     * Gets the <code>Appointment</code> Months for the "Total Number of
     * Appointments by Type and Month" <code>Report</code> on the <code>Reports</code> scene.
     * @return the <code>Appointment</code> Months for the "Total Number of
     * Appointments by Type and Month" <code>Report</code> on the <code>Reports</code> scene.
     * */
    public String getAppointmentMonthString() {return appointmentMonthString;}


    /**
     * Provides the ability to get <code>User</code>-friendly text versions of each <code>Appointment</code> parameter for
     * display throughout the program.
     * */
    @Override
    public String toString(){
        return (Appointment_ID + Title + Description + Location + Type + Start + End + Create_Date + Created_By + Last_Update + Last_Updated_By + Customer_ID + User_ID + Contact_ID + Contact_Name);
    }
}
