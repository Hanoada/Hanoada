package Main;

import Helper.JDBC;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * <p>@author Adam Hanover - C195: Software II Performance Assessment (Student ID: 001385636)</p>
 * GUI-Based Scheduling Application
 * This class creates an application to display a GUI-Based Scheduling program.
 */
public class Main extends Application{

    /**
     * Displays the text "Starting Application..." in the command line for programmers working with the program.
     * @throws Exception This exception checks for general issues that an application would reasonably want to search for.
     * Produces an exception if some common errors are found.
     */
    @Override
    public void init() throws Exception {
        super.init();
        System.out.println("Starting Application...");
    }

    /**
     *  Starts the application and calls-up the <code>loginStage</code> Stage. Directs the <code>User</code> to the <code>Login</code>
     *  scene, where they can enter credentials to interact with the scheduling program. If the <code>User</code>'s locale is set to
     *  <code>French</code>, this method translates the title of the <code>Stage</code> to French using the <code>Nat_fr</code>
     *  <code>Resource Bundle</code>. Calls the <code>JDBC.openConnection()</code> method to establish a connection with the
     *  locally-hosted database.
     * @param loginStage This parameter is the Stage object that will be called to retrieve the <code>Login</code> scene.
     *                  Gives <code>loginStage</code> a title, declares the dimensions, and calls the <code>Login</code> scene.
     * @throws Exception Checks for general issues that an application would reasonably want to search for. Produces an exception
     * if some common errors are found.
     */
    @Override
    public void start(Stage loginStage) throws Exception {
        JDBC.openConnection();

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Login.fxml")));
        if (Locale.getDefault().getLanguage().equals("fr")) {
            ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());
            loginStage.setTitle(rb.getString("login"));
        }
        else {
            loginStage.setTitle("Login Form");
        }
        loginStage.setScene(new Scene(root, 1000, 600));
        loginStage.show();
    }

    /**
     * Generates the command line message "Exiting Application..." when a user exits the application. Useful for programmers working on the internal files.
     * Also calls the <code>JDBC.closeConnection()</code> method to ensure the connection with the local database is closed upon exiting the program.
     * @throws Exception Checks for general issues that an application would reasonably want to search for. Produces an exception if some common errors are found.
     */
    @Override
    public void stop() throws Exception{
        JDBC.closeConnection();
        super.stop();
        System.out.println("Exiting Application...");
    }

    /**
     * This is the <code>main</code> method. Gets called when the java program executes.
     * @param args Gets command line arguments that are passed during the program's execution.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
