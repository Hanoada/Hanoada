package Controller;

import DBAccess.DBAppointments;
import Helper.JDBC;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * Establishes the <code>HomeScreen</code> scene. Gives the <code>User</code> the ability to navigate the program
 * in order to add, update, and delete <code>Appointment</code>s and <code>Customer</code> as well as access to a <code>Reports</code>
 * scene. Program navigation is provided using buttons in this scene.
 * */
public class HomeScreen {
    static Stage stage;
    static Parent scene;

    /**
     * Event Handler for the "I'd Like to See My Customers" button on the <code>HomeScreen</code> scene.
     * Redirects <code>User</code> to the <code>Customers</code> scene, where they can manage <code>Customers</code>.
     * @param actionEvent Triggered by clicking the "I'd Like to See My Customers" button on the <code>HomeScreen</code>
     *                    scene. Loads the <code>Customers</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActMainCustButton(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Customers.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Event Handler for the "I'd Like to See My Appointments" button on the <code>HomeScreen</code> scene.
     * Redirects <code>User</code> to the <code>Appointments</code> scene, where they can manage <code>Appointments</code>.
     * @param actionEvent Triggered by clicking the "I'd Like to See My Appointments" button on the <code>HomeScreen</code>
     *                    scene. Loads the <code>Appointments</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActMainApptButton(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Appointments.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Event Handler for the "Let's Run Some Reports" button on the <code>HomeScreen</code> scene.
     * Redirects <code>User</code> to the <code>Reports</code> scene, where they can view multiple <code>Reports</code>.
     * @param actionEvent Triggered by clicking the "Let's Run Some Reports" button on the <code>HomeScreen</code>
     *                    scene. Loads the <code>Reports</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActMainReportsButton(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Reports.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Event Handler for the "EXIT" button on the <code>HomeScreen</code> scene. Closes the database connection
     * using the <code>JDBC.closeConnection()</code> method and then closes the application with a System status of "0".
     */
    public void onActExitBtn() {
        JDBC.closeConnection();
        System.exit(0);
    }

    /**
     * Used to check for <code>Appointment</code>s within 15 minutes of the <code>User</code>'s system time. If there is an upcoming
     * <code>Appointment</code> within 15 minutes of the <code>User</code>'s system time, generates an <code>Alert</code> with the
     * <code>Appointment</code>'s identifying information, including <code>Appointment ID</code>, Date, and Time.
     * <p></p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> it until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>. Multiple <code>Alert</code>s are handled
     * with <code>lambda</code> expressions in this method.
     */
    public static void checkAppointments() {
        for (int i = 0; i < DBAppointments.getAllAppointments().size(); ++i) {
            if ((ChronoUnit.MINUTES.between(LocalDateTime.now(), DBAppointments.getAllAppointments().get(i).getStart())) > 0 &&
                    (ChronoUnit.MINUTES.between(LocalDateTime.now(), DBAppointments.getAllAppointments().get(i).getStart())) < 16) {

                Alert appointmentSoon = new Alert(Alert.AlertType.WARNING, "Appointment Upcoming in Less Than 15 Minutes");
                appointmentSoon.setTitle("Upcoming Appointment!");
                appointmentSoon.setHeaderText("You have an appointment within the next 15 minutes... here are the details:\n" +
                        "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID + "\n" +
                        "Date: " + DBAppointments.getAllAppointments().get(i).getStart().toLocalDate() + "\n" +
                        "Time: " + DBAppointments.getAllAppointments().get(i).getStart().toLocalTime());
                appointmentSoon.showAndWait().ifPresent((ok -> {
                    if (ok == ButtonType.OK) {
                        appointmentSoon.close();
                    }
                }));
                return;
            }
        }
        Alert noUpcomingAppts = new Alert(Alert.AlertType.INFORMATION, "No Upcoming Appointments");
        noUpcomingAppts.setTitle("No Upcoming Appointments");
        noUpcomingAppts.setHeaderText("You do not have any appointments within the next 15 minutes.");

        noUpcomingAppts.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noUpcomingAppts.close();
            }
        }));
    }

    /**
     * Used to check for <code>Appointment</code>s within 15 minutes of the <code>User</code>'s system time. If there is an upcoming
     * <code>Appointment</code> within 15 minutes of the <code>User</code>'s system time, generates an <code>Alert</code> in
     * <code>French</code> with the <code>Appointment</code>'s identifying information, including <code>Appointment ID</code>, Date, and Time,
     * all translated to <code>French</code>.
     * <p></p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> it until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>. Multiple <code>Alert</code>s are handled
     * with <code>lambda</code> expressions in this method, all of which are translated to <code>French</code>.
     */
    public static void checkAppointmentsFR() {
        for (int i = 0; i < DBAppointments.getAllAppointments().size(); ++i) {
            if ((ChronoUnit.MINUTES.between(LocalDateTime.now(), DBAppointments.getAllAppointments().get(i).getStart())) > 0 &&
                    (ChronoUnit.MINUTES.between(LocalDateTime.now(), DBAppointments.getAllAppointments().get(i).getStart())) < 16) {
                ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());
                Alert appointmentSoon = new Alert(Alert.AlertType.WARNING, rb.getString("upcomingAppointment"));
                appointmentSoon.setTitle(rb.getString("upcomingAppointmentTitle"));
                appointmentSoon.setHeaderText(rb.getString("upcomingAppointmentHeader") + "\n" +
                        rb.getString("AppointmentID") + " " + DBAppointments.getAllAppointments().get(i).Appointment_ID + "\n" +
                        rb.getString("Date") + " " + DBAppointments.getAllAppointments().get(i).getStart().toLocalDate() + "\n" +
                        rb.getString("Time") + " " + DBAppointments.getAllAppointments().get(i).getStart().toLocalTime());
                appointmentSoon.showAndWait().ifPresent((ok -> {
                    if (ok == ButtonType.OK) {
                        appointmentSoon.close();
                    }
                }));
                return;
            }
        }
        ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());
        Alert noUpcomingAppts = new Alert(Alert.AlertType.INFORMATION, rb.getString("noUpcomingAppointments"));
        noUpcomingAppts.setTitle(rb.getString("noUpcomingAppointments"));
        noUpcomingAppts.setHeaderText(rb.getString("noUpcomingAppointmentsHeader"));
        noUpcomingAppts.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noUpcomingAppts.close();
            }
        }));
    }
}
