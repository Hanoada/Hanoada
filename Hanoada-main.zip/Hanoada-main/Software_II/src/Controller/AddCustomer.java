package Controller;

import DBAccess.DBCountries;
import DBAccess.DBCustomers;
import DBAccess.DBFirst_Level_Divisions;
import DBAccess.DBUsers;
import Helper.CustomerAlerts;
import Model.Countries;
import Model.First_Level_Division;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * Establishes the <code>AddCustomer</code> scene. Gives the user the ability to add <code>Customer</code>s
 * to the connected MySQL server and the "customerList" ObservableList contained in the <code>DBCustomers</code>
 * file using the "Save" button found in the scene.
 * */
public class AddCustomer implements Initializable {
    @FXML
    public ComboBox<Countries> countryComboBox;
    @FXML
    public ComboBox<First_Level_Division> stateComboBox;
    @FXML
    public TextField cNameTxtField;
    @FXML
    public TextField addCustAddressTxtField;
    @FXML
    public TextField addCustPostalCodeTxtField;
    @FXML
    public TextField addCustPhoneTxtField;
    @FXML
    public TextField addCustCustIdTxtField;
    Stage stage;
    Parent scene;

    /**
     * Event handler for the "Cancel" button on the <code>AddCustomer</code> scene. Cancels the action to add a new
     * <code>Customer</code> to the connected database and the "customerList" ObservableList in the
     * <code>DBCustomers</code> file and loads the <code>Customers</code> scene.
     * @param actionEvent Triggered by clicking the "Cancel" button on the <code>AddCustomer</code> scene. Used to trigger
     *                    the program to discard any entered <code>Customer</code> information and load the <code>Customers</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     * */
    public void onActAddCustCancelBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Customers.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Enables use of the objects called by the method. Receives whatever data is necessary to make the object valid and
     * usable. Initializes the <code>AddCustomer</code> scene, sets the items in the <code>Country</code>, and
     * <code>State / Province</code> ComboBoxes using the <code>getAllCountries()</code> and <code>getAllFirstLevelDivisions()</code>
     * methods found in the <code>DBCountries</code> and <code>DBFist_Level_Division</code> files respectively.
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        countryComboBox.setItems(DBCountries.getAllCountries());
        stateComboBox.setItems(DBFirst_Level_Divisions.getAllFirstLeveLDivisions());
    }

    /**
     * Event Handler for the "Save" button in the <code>AddCustomer</code> scene. Provides input validation and logical error
     * checks using <code>Alert</code>s found in the <code>CustomerAlerts</code> <code>Helper</code> class. If proposed
     * <code>Customer</code> validates correctly, the method calls the <code>insert()</code> method in the <code>DBCustomers</code>
     * file, which adds the <code>Customer</code> to the connected database. If the <code>Customer</code> is successfully
     * added to the connected database, the method returns the <code>User</code> to the <code>Customers</code> scene.
     *
     * @param actionEvent Triggered by clicking the "Cancel" button on the <code>AddCustomer</code> scene. Used to trigger
     *                    the program to discard any entered <code>Customer</code> information and load the <code>Customers</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     * */
    public void onActAddCustSaveBtn(ActionEvent actionEvent) throws IOException {
        if (cNameTxtField.getText().isEmpty()) {
            CustomerAlerts.noName();
            return;
        }
        if (addCustAddressTxtField.getText().isEmpty()) {
            CustomerAlerts.noAddress();
            return;
        }
        if (addCustPhoneTxtField.getText().isEmpty()) {
            CustomerAlerts.noPhone();
            return;
        }
        if (addCustPostalCodeTxtField.getText().isEmpty()) {
            CustomerAlerts.noPostal();
            return;
        }
        if (countryComboBox.getSelectionModel().getSelectedItem() == null) {
            CustomerAlerts.noCountry();
            return;
        }
        if (stateComboBox.getSelectionModel().getSelectedItem() == null) {
            CustomerAlerts.noState();
            return;
        }

        String fldName = String.valueOf(stateComboBox.getSelectionModel().getSelectedItem());
        DBCustomers.insert(cNameTxtField.getText(), addCustAddressTxtField.getText(), addCustPostalCodeTxtField.getText(),
                addCustPhoneTxtField.getText(), DBUsers.getActiveUser(), DBUsers.getActiveUser(), fldName);

        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Customers.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Event Handler for the <code>Country</code> ComboBox on the <code>AddCustomer</code> scene. Depending on the <code>Country</code>
     * selected from the ComboBox, generates the appropriate <code>State / Province</code>s in the <code>State / Province</code> ComboBox.
     * */
    public void countryComboOnAct() {
        for (int i = 0; i < countryComboBox.getItems().size(); ++i) {
            if (countryComboBox.getSelectionModel().getSelectedItem().toString().equals("U.S")) {
                stateComboBox.setItems(DBFirst_Level_Divisions.getUSAFLDs());
            }
            else if (countryComboBox.getSelectionModel().getSelectedItem().toString().equals("Canada")) {
                stateComboBox.setItems(DBFirst_Level_Divisions.getCanadaFLDs());
            }
            else if (countryComboBox.getSelectionModel().getSelectedItem().toString().equals("UK")) {
                stateComboBox.setItems(DBFirst_Level_Divisions.getUKFLDs());

            }
        }

    }
}
