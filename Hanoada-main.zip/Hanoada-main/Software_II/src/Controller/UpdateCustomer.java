package Controller;

import DBAccess.DBCountries;
import DBAccess.DBCustomers;
import DBAccess.DBUsers;
import Helper.CustomerAlerts;
import Model.Customer;
import Model.First_Level_Division;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

import static DBAccess.DBFirst_Level_Divisions.*;

/**
 * Establishes the <code>UpdateCustomer</code> scene. Gives the <code>User</code> the ability to update a
 * selected <code>Customer</code> from the connected MySQL server and the "customerList" ObservableList contained
 * in the <code>DBCustomers</code> file.
 * */
public class UpdateCustomer implements Initializable {

    @FXML
    public TextField customerIdTxtField;
    @FXML
    public TextField customerNameTxtField;
    @FXML
    public TextField customerAddressTxtField;
    @FXML
    public TextField customerPostalCodeTxtField;
    @FXML
    public TextField customerPhoneTxtField;
    @FXML
    public ComboBox <String> customerCountryCombo;
    @FXML
    public ComboBox <First_Level_Division> customerStateCombo;
    public ObservableList<String> countryStrings = FXCollections.observableArrayList();


    Stage stage;
    Parent scene;
    public static Customer updateCustomer = null;

    /**
     * Used to collect the appropriate <code>Customer</code> information from the <code>Customers</code> scene when the
     * "Update <code>Customer</code>" button is pressed.
     * */
    public static void setCustomerToUpdate(Customer customerToUpdate) {
        updateCustomer = customerToUpdate;

    }

    /**
     * Event handler for the "Cancel" button on the <code>UpdateCustomer</code> scene. Cancels the action to update the
     * selected <code>Customer</code> in the connected database and the "customerList" ObservableList in the
     * <code>DBCustomers</code> file and loads the <code>Customers</code> scene. Clicking this button will ensure no
     * edits are made to the selected <code>Customer</code>.
     * @param actionEvent Triggered by clicking the "Cancel" button on the <code>UpdateCustomer</code> scene. Used to trigger
     *                    the program to discard any changed <code>Customer</code> information for the selected
     *                    <code>Customer</code> and load the <code>Customers</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     * */
    public void onActUpdateCustCancelBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Customers.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Enables use of the objects called by the method. Receives whatever data is necessary to make the object valid and
     * usable. Initializes the <code>UpdateCustomer</code> scene, sets the values in the <code>Country</code> and
     * <code>State / Province</code> ComboBoxes according to the information already present in the selected
     * <code>Customer</code>. Populates all other <code>Customer</code> data in their respective TextFields. All
     * fields are editable except for the <code>Customer ID</code> field, which is disabled.
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        for (int i = 0; i < DBCountries.getAllCountries().size(); ++i) {
            countryStrings.add(DBCountries.getAllCountries().get(i).getName());
        }
        customerIdTxtField.setText(String.valueOf(updateCustomer.getCustomer_ID()));
        customerNameTxtField.setText(updateCustomer.Customer_Name);
        customerAddressTxtField.setText(updateCustomer.Address);
        customerPostalCodeTxtField.setText(updateCustomer.getPostal_Code());
        customerPhoneTxtField.setText(updateCustomer.Phone);
        customerCountryCombo.setItems(countryStrings);
        customerCountryCombo.setValue(updateCustomer.getCustomerCountry());
        customerStateCombo.setItems(getAllFirstLeveLDivisions());
        customerStateCombo.setValue(updateCustomer.getState(updateCustomer));

        switch (updateCustomer.customerCountry) {
            case "U.S" -> customerStateCombo.setItems(getUSAFLDs());
            case "Canada" -> customerStateCombo.setItems(getCanadaFLDs());
            case "UK" -> customerStateCombo.setItems(getUKFLDs());
        }
    }

    /**
     * Event Handler for the <code>Country</code> ComboBox on the <code>UpdateCustomer</code> scene. Depending on the <code>Country</code>
     * selected from the ComboBox, generates the appropriate <code>State / Province</code>s in the <code>State / Province</code> ComboBox.
     * */
    public void onActCountryCombo() {
            if (customerCountryCombo.getSelectionModel().getSelectedItem().equals("U.S")) {
                customerStateCombo.setValue(null);
                customerStateCombo.setItems(getUSAFLDs());
            }
            else if (customerCountryCombo.getSelectionModel().getSelectedItem().equals("Canada")) {
                customerStateCombo.setValue(null);
                customerStateCombo.setItems(getCanadaFLDs());
            }
            else if (customerCountryCombo.getSelectionModel().getSelectedItem().equals("UK")) {
                customerStateCombo.setValue(null);
                customerStateCombo.setItems(getUKFLDs());
            }
        }

    /**
     * Event Handler for the "Save" button in the <code>UpdateCustomer</code> scene. Provides input validation and logical error
     * checks using <code>Alert</code>s found in the <code>CustomerAlerts</code> <code>Helper</code> class. If proposed
     * <code>Customer</code> updates validate correctly, the method calls the <code>updateCustomer()</code> method
     * in the <code>DBCustomers</code> file, which updates the selected <code>Customer</code> in the connected database.
     * If the <code>Customer</code> is successfully updated in the connected database, the method returns the <code>User</code>
     * to the <code>Customers</code> scene.
     *
     * @param actionEvent Triggered by clicking the "Save" button on the <code>UpdateCustomer</code> scene. Used to trigger
     *                    the program to update the selected <code>Customer</code> information in the connected database
     *                    and load the <code>Customers</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call. */
    public void onActSaveBtn(ActionEvent actionEvent) throws IOException {
        if (customerNameTxtField.getText().isEmpty()) {
            CustomerAlerts.noName();
            return;
        }
        if (customerAddressTxtField.getText().isEmpty()) {
            CustomerAlerts.noAddress();
            return;
        }
        if (customerPhoneTxtField.getText().isEmpty()) {
            CustomerAlerts.noPhone();
            return;
        }
        if (customerPostalCodeTxtField.getText().isEmpty()) {
            CustomerAlerts.noPostal();
            return;
        }
        if (customerCountryCombo.getSelectionModel().getSelectedItem() == null) {
            CustomerAlerts.noCountry();
            return;
        }
        if (customerStateCombo.getSelectionModel().getSelectedItem() == null) {
            CustomerAlerts.noState();
            return;
        }

        String fldName = String.valueOf(customerStateCombo.getSelectionModel().getSelectedItem());
        DBCustomers.updateCustomer(Integer.parseInt(customerIdTxtField.getText()), customerNameTxtField.getText(),
                customerAddressTxtField.getText(), customerPostalCodeTxtField.getText(), customerPhoneTxtField.getText(),
                DBUsers.getActiveUser(), DBUsers.getActiveUser(), fldName);
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Customers.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }
}
