package Controller;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomers;
import Model.Appointment;
import Model.Contact;
import Model.Customer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * Establishes the <code>Reports</code> scene. Gives the <code>User</code> the ability to view <code>Report</code>s
 * from the connected MySQL server. Displays three reports:
 * <p>1) Total Number of <code>Customer</code> <code>Appointment</code>s by <code>Type</code> and <code>Month</code></p>
 * <p>2) Schedule for Each <code>Contact</code> in the organization that includes <code>Appointment ID</code>, <code>Title</code>,
 * <code>Type</code>, <code>Description</code>, <code>Start Date / Time</code>, <code>End Date / Time</code>, and <code>Customer ID</code></p>
 * <p>/-----------------------------------------------------------/</p>
 * <p><b>ADDITIONAL REPORT...</b></p>
 * <p>3) An Additional Report Detailing each <code>Customer</code>'s Account Age, Based on the <code>Create_Date</code> Field in the Connected Database</p>
 * */
public class Reports implements Initializable {
    @FXML
    public TableView <Appointment> appTypeMonthTableView;
    @FXML
    public TableView <Appointment> contactAppointmentsTableView;
    @FXML
    public TableView <Customer> customReportTableView;
    @FXML
    public TableColumn<Appointment, String> monthCol;
    @FXML
    public TableColumn<Appointment, String> typeCol;
    @FXML
    public TableColumn<Appointment, Integer> countCol;
    @FXML
    public TableColumn<Appointment, Integer> appointmentIDCol;
    @FXML
    public TableColumn<Appointment, String> titleCol;
    @FXML
    public TableColumn<Appointment, String> contactTypeCol;
    @FXML
    public TableColumn<Appointment, String> descriptionCol;
    @FXML
    public TableColumn<Appointment, LocalDateTime> startCol;
    @FXML
    public TableColumn<Appointment, LocalDateTime> endCol;
    @FXML
    public TableColumn<Appointment, Integer> customerIDCol;
    @FXML
    public TableColumn<Customer, Integer> customCustomerIDCol;
    @FXML
    public TableColumn<Customer, String> customCustomerNameCol;
    @FXML
    public TableColumn<Customer, LocalDateTime> accountStartCol;
    @FXML
    public TableColumn<Customer, Integer> accountAgeCol;
    @FXML
    public ComboBox<Contact> contactCombo;
    Stage stage;
    Parent scene;

    /**
     * Event Handler for the "Back" button on the <code>Reports</code> scene under all three <code>Reports</code>
     * TableViews. Redirects <code>User</code> to the <code>HomeScreen</code> scene, where they can navigate to other
     * parts of the program.
     * @param actionEvent Triggered by clicking the "Back" button on the <code>Reports</code>
     *                    scene. Loads the <code>HomeScreen</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActReportsExitBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/HomeScreen.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Enables use of the objects called by the method. Receives whatever data is necessary to make the object valid and
     * usable. Initializes the <code>Reports</code> scene and generates the <code>Reports</code> TableViews.
     * Generates <code>Appointments</code> by Month and <code>Type</code> counts in the first TableView. Generates
     * <code>Contact</code> names in a ComboBox, which is used to filter <code>Appointment</code>s by <code>Contact</code> name
     * in the second TableView. Generates <code>Customer</code>s and their account ages in the third TableView using the
     * <code>Create_Date</code> column in the connected database for each <code>Customer</code>.
     *
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //SETTING CONTACT COMBO BOX
        try {
            contactCombo.setItems(DBContacts.getAllContacts());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        //INITIALIZING MONTH/TYPE REPORT DATA
        monthCol.setCellValueFactory(new PropertyValueFactory<>("appointmentMonthString"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        countCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTypeCount"));
        appTypeMonthTableView.setItems(DBAppointments.getMonthTypeAppointments());

        //INITIALIZING CONTACT REPORT DATA
        appointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        contactTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("End"));
        customerIDCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        contactCombo.getSelectionModel().selectFirst();
        try {
            contactAppointmentsTableView.setItems(DBAppointments.getContactAppointment(contactCombo.getSelectionModel().getSelectedItem()));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        //INITIALIZING CUSTOM REPORT DATA
        customCustomerIDCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        customCustomerNameCol.setCellValueFactory(new PropertyValueFactory<>("Customer_Name"));
        accountStartCol.setCellValueFactory(new PropertyValueFactory<>("Create_Date"));
        accountAgeCol.setCellValueFactory(new PropertyValueFactory<>("accountAge"));
        try {
            customReportTableView.setItems(DBCustomers.getCustomCustomerList());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    /**
     * Event Handler for the <code>Contact</code> ComboBox on the <code>Reports</code> scene above the second
     * TableView. Populates the TableView with the <code>Appointment</code>s associated with the selected <code>Contact</code>.
     * @throws SQLException thrown when problems occur while attempting to add information to the connected database.
     */
    public void onActContactCombo() throws SQLException {
        contactAppointmentsTableView.setItems(DBAppointments.getContactAppointment(contactCombo.getSelectionModel().getSelectedItem()));
    }
}
