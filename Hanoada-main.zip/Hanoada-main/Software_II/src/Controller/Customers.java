package Controller;

import DBAccess.DBAppointments;
import DBAccess.DBCustomers;
import Model.Appointment;
import Model.Customer;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import static DBAccess.DBCountries.getAllCountryStrings;
import static Helper.CustomerAlerts.noCustomerSelected;

/**
 * Establishes the <code>Customers</code> scene. Gives the <code>User</code> the ability to view <code>Customer</code>s
 * from the connected MySQL server and the "customerList" ObservableList contained in the <code>DBCustomers</code> file. Also
 * allows access to the <code>AddCustomer</code> and <code>UpdateCustomer</code> scenes and provides the ability to
 * delete <code>Customer</code>s from the program and connected database.
 * */
public class Customers implements Initializable {
    Stage stage;
    Parent scene;
    @FXML
    public TableView<Customer> customersTableView;
    @FXML
    public ComboBox<String> selectCountryCustomerComboBox;
    @FXML
    public TableColumn<Customer, Integer> custCustIdCol;
    @FXML
    public TableColumn<Customer, String> custCustNameCol;
    @FXML
    public TableColumn<Customer, String> custCustAddressCol;
    @FXML
    public TableColumn<Customer, String> custCustPostalCodeCol;
    @FXML
    public TableColumn<Customer, String> custCustPhoneCol;
    @FXML
    public TableColumn<String, String> custCustCountryCol;
    @FXML
    public TableColumn<Customer, String> custCustStateCol;

    /**
     * Event Handler for the "Back" button on the <code>Customers</code> scene under the <code>Customers</code>
     * TableView. Redirects <code>User</code> to the <code>HomeScreen</code> scene, where they can navigate to other
     * parts of the program.
     * @param actionEvent Triggered by clicking the "Back" button on the <code>Customers</code>
     *                    scene. Loads the <code>HomeScreen</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActCustomersExitBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/HomeScreen.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }
    /**
     * Enables use of the objects called by the method. Receives whatever data is necessary to make the object valid and
     * usable. Initializes the <code>Customers</code> scene and generates the <code>Customers</code> TableView data using
     * the <code>getAllCustomers()</code> method in the <code>DBCustomers</code> file.
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * Lambda <code>Comparator</code> is used to provide an initial <code>sort</code> of the <code>Customers</code>
     * TableView by <code>Customer_ID</code> when the scene loads.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        custCustIdCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        custCustNameCol.setCellValueFactory(new PropertyValueFactory<>("Customer_Name"));
        custCustAddressCol.setCellValueFactory(new PropertyValueFactory<>("Address"));
        custCustPostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("Postal_Code"));
        custCustPhoneCol.setCellValueFactory(new PropertyValueFactory<>("Phone"));
        custCustCountryCol.setCellValueFactory(new PropertyValueFactory<>("customerCountry"));
        custCustStateCol.setCellValueFactory(new PropertyValueFactory<>("customerDivision"));
        selectCountryCustomerComboBox.setItems(getAllCountryStrings());
        ObservableList<Customer> observableCustomers = DBCustomers.getAllCustomers();
        //LAMBDA EXPRESSION
        observableCustomers.sort(Comparator.comparingInt(a -> a.Customer_ID));
        customersTableView.setItems(observableCustomers);
    }

    /**
     * Event Handler for the "Update <code>Customer</code>" button on the <code>Customers</code> scene under the
     * <code>Customers</code> TableView. Redirects <code>User</code> to the <code>UpdateCustomer</code> scene,
     * where they can modify existing <code>Customer</code> objects in the connected database and scheduling program.
     * Includes appropriate <code>Alert</code>s for input validation and logical error checks.
     * @param actionEvent Triggered by clicking the "Update <code>Customer</code>" button on the <code>Customers</code>
     *                    scene. Loads the <code>UpdateCustomers</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActCustomersUpdateCustomerBtn(ActionEvent actionEvent) throws IOException {
        if (customersTableView.getSelectionModel().getSelectedItem() == null) {
            noCustomerSelected();
            return;
        }
        Customer selectedCustomer = customersTableView.getSelectionModel().getSelectedItem();
        UpdateCustomer.setCustomerToUpdate(selectedCustomer);

        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/UpdateCustomer.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Event Handler for the "Add <code>Customer</code>" button on the <code>Customers</code> scene under the <code>Customers</code>
     * TableView. Redirects <code>User</code> to the <code>AddCustomers</code> scene, where they can add <code>Customer</code>s to the
     * database and program.
     * @param actionEvent Triggered by clicking the "Add <code>Customer</code>" button on the <code>Customers</code>
     *                    scene. Loads the <code>AddCustomer</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActCustomersAddCustomerBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/AddCustomer.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Event Handler for the <code>Country</code> ComboBox on the <code>Customers</code> scene above the <code>Customers</code>
     * TableView. The <code>Customers</code> TableView will filter the <code>Customers</code> by the <code>User</code>'s
     * selected <code>Country</code> in the ComboBox.
     * @throws SQLException thrown when problems occur while attempting to add information to the connected database.
     */
    public void onActSelectCountryCombo() throws SQLException {
        if (selectCountryCustomerComboBox.getSelectionModel().getSelectedItem().equals("U.S")) {
            customersTableView.setItems(DBCustomers.getUSACustomers());
        } else if (selectCountryCustomerComboBox.getSelectionModel().getSelectedItem().equals("UK")) {
            customersTableView.setItems(DBCustomers.getUKCustomers());
        } else if (selectCountryCustomerComboBox.getSelectionModel().getSelectedItem().equals("Canada")) {
            customersTableView.setItems(DBCustomers.getCanadaCustomers());
        } else if (selectCountryCustomerComboBox.getSelectionModel().getSelectedItem().equals("All")) {
            customersTableView.setItems(DBCustomers.getAllCustomers());
        } else {
            customersTableView.setItems(DBCustomers.getAllCustomers());
        }
    }

    /**
     * Event Handler for the "Delete Customer" button on the <code>Customers</code> scene. Ensures there is a
     * <code>Customer</code> selected before attempting to delete. <code>Alert</code> is provided to inform the <code>User</code>
     * that deleting a <code>Customer</code> will also delete all associated <code>Appointments</code> and gets confirmation.
     * When a <code>Customer</code> is successfully deleted, an <code>Alert</code> confirms the deletion.
     * @throws SQLException thrown when problems occur while attempting to add information to the connected database.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * Lambda <code>Comparator</code> is used to provide an initial <code>sort</code> of the <code>Customers</code>
     * TableView by <code>Customer_ID</code> when a <code>Customer</code> is deleted.
     * */
    public void onActDeleteCustomerBtn() throws SQLException {
        if (customersTableView.getSelectionModel().getSelectedItem() == null) {
            noCustomerSelected();
            return;
        }
        if (DBCustomers.deleteCustomer(customersTableView.getSelectionModel().getSelectedItem().Customer_ID)) {
            Alert associatedAppointments = new Alert(Alert.AlertType.INFORMATION, "The selected customer was successfully deleted.");
            associatedAppointments.setTitle("Customer Deleted");
            associatedAppointments.setHeaderText("Customer Successfully Deleted");
            Optional<ButtonType> associatedAppts = associatedAppointments.showAndWait();
            if (associatedAppts.isPresent() && associatedAppts.get() == ButtonType.OK) {
                associatedAppointments.close();
            }
            ObservableList<Customer> observableCustomers = DBCustomers.getAllCustomers();
            //LAMBDA EXPRESSION
            observableCustomers.sort(Comparator.comparingInt(a -> a.Customer_ID));
            customersTableView.setItems(observableCustomers);
        }
    }
}