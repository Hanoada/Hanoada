package Controller;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomers;
import DBAccess.DBUsers;
import Helper.AppointmentAlerts;
import Helper.LocalTimePicker;
import Model.Contact;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * Establishes the <code>AddAppointment</code> scene. Gives the user the ability to add <code>Appointment</code>s
 * to the connected MySQL server and the "appointmentsList" ObservableList contained in the <code>DBAppointments</code>
 * file using the "Save" button found in the scene.
 * */
public class AddAppointment implements Initializable {
    Stage stage;
    Parent scene;
    @FXML
    private ComboBox<Contact> addAppContactNameCombo;
    @FXML
    private TextField addAppTitleTxtField;
    @FXML
    private TextField addAppDescTxtField;
    @FXML
    private TextField addAppLocTxtField;
    @FXML
    private ComboBox<String> addAppTypeCombo;
    @FXML
    public DatePicker startDatePicker;
    @FXML
    public DatePicker endDatePicker;
    @FXML
    private ComboBox <LocalTime> startTimeCombo;
    @FXML
    private ComboBox<LocalTime> endTimeCombo;
    @FXML
    private ComboBox<Integer> addAppCustIdCombo;
    @FXML
    private ComboBox<Integer> addAppUserIdCombo;
    public LocalDateTime startDateTime;
    public LocalDateTime endDateTime;

    /**
     * Event handler for the "Cancel" button on the <code>AddAppointment</code> scene. Cancels the action to add a new
     * <code>Appointment</code> to the connected database and the "appointmentsList" ObservableList in the
     * <code>DBAppoinments</code> file and loads the <code>Appointments</code> scene.
     * @param actionEvent Triggered by clicking the "Cancel" button on the <code>AddAppointment</code> scene. Used to trigger
     *                    the program to discard any entered <code>Appointment</code> information and load the <code>Appointments</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     * */
    public void onActAddApptCancelBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Appointments.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Enables use of the objects called by the method. Receives whatever data is necessary to make the object valid and
     * usable. Initializes the <code>AddAppointment</code> scene, sets the items in the <code>Type</code>, <code>Contact Name</code>,
     * <code>Customer ID</code>, and <code>User ID</code> ComboBoxes. Also calls the <code>generateTimeCombos()</code> method
     * in the <code>LocalTimePicker</code> <code>Helper</code> class to generate dates and times in the <code>Start</code>
     * and <code>End</code> DatePicker and Time ComboBoxes.
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        addAppTypeCombo.setItems(DBAppointments.generateAppointmentTypes());
        try {
            addAppContactNameCombo.setItems(DBContacts.getAllContacts());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        addAppCustIdCombo.setItems(DBCustomers.getCustomerIds().sorted());
        try {
            addAppUserIdCombo.setItems(DBUsers.getUserIDs().sorted());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        startTimeCombo.setItems(LocalTimePicker.generateTimeCombos());
        endTimeCombo.setItems(LocalTimePicker.generateTimeCombos());
    }

    /**
     * Event Handler for the "Save" button in the <code>AddAppointment</code> scene. Provides input validation and logical error
     * checks using <code>Alert</code>s found in the <code>AppointmentAlerts</code> <code>Helper</code> class. If proposed
     * <code>Appointment</code> validates correctly, the method calls the <code>insert()</code> method in the <code>DBAppointments</code>
     * file, which adds the <code>Appointment</code> to the connected database. If the <code>Appointment</code> is successfully
     * added to the connected database, the method returns the <code>User</code> to the <code>Appointments</code> scene.
     *
     * @param actionEvent Triggered by clicking the "Save" button on the <code>AddAppointment</code> scene. Used to trigger
     *                    the program to upload <code>Appointment</code> information to the connected database and load
     *                    the <code>Appointments</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     * @throws SQLException thrown when problems occur while attempting to add information to the connected database.
     * */
    public void onActAddAppSaveBtn(ActionEvent actionEvent) throws SQLException, IOException {
        if (addAppContactNameCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noContactNameSelected();
            return;
        }
        if (addAppTypeCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noTypeSelected();
            return;
        }
        if (startDatePicker.getValue() == null || startTimeCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noStartDateTime();
            return;
        }
        if (endDatePicker.getValue() == null || endTimeCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noEndDateTime();
            return;
        }
        if (addAppContactNameCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noContactSelected();
            return;
        }
        if (addAppCustIdCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noCustomerIdSelected();
            return;
        }
        if (addAppUserIdCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noUserIdSelected();
            return;
        }

        startDateTime = LocalDateTime.of(startDatePicker.getValue(), startTimeCombo.getSelectionModel().getSelectedItem());
        endDateTime = LocalDateTime.of(endDatePicker.getValue(), endTimeCombo.getSelectionModel().getSelectedItem());
        String contactName = addAppContactNameCombo.getSelectionModel().getSelectedItem().toString();

        if (AppointmentAlerts.validateAppointment(addAppCustIdCombo.getSelectionModel().getSelectedItem(), addAppTitleTxtField.getText(), addAppDescTxtField.getText(), addAppLocTxtField.getText(),
                startDateTime, endDateTime, addAppTypeCombo.getSelectionModel().getSelectedItem())) {
            DBAppointments.insert(
                    addAppTitleTxtField.getText(),
                    addAppDescTxtField.getText(),
                    addAppLocTxtField.getText(),
                    addAppTypeCombo.getValue(),
                    DBUsers.getActiveUser(),
                    startDateTime,
                    endDateTime,
                    DBUsers.getActiveUser(),
                    addAppCustIdCombo.getValue(),
                    addAppUserIdCombo.getValue(),
                    DBContacts.getContactID(contactName));
        }
        else return;
        stage =(Stage)((javafx.scene.control.Button)actionEvent.getSource()).getScene().getWindow();
        scene =FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Appointments.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }
}
