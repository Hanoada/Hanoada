package Controller;

import DBAccess.DBUsers;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.time.ZoneId;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;

import static Helper.LoginAlerts.*;

/**
 * Establishes the <code>Login</code> scene. Gives the <code>User</code> the ability to log into the program using a
 * <code>Username</code> and <code>Password</code>. Provides security to the program by verifying login credentials with the connected database.
 * */
public class Login implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    public PasswordField passTxtField;
    @FXML
    public TextField usernameTxtField;
    @FXML
    public Label loginUserLocationLbl;
    @FXML
    public Label loginTitleLbl;
    @FXML
    public Label enterText;
    @FXML
    public Label locationLbl;
    @FXML
    public Label usernameLbl;
    @FXML
    public Label passwordLbl;
    @FXML
    public Button loginBtn;

    /**
     * Enables use of the objects called by the method. Receives whatever data is necessary to make the object valid and
     * usable. Initializes the <code>Login</code> scene and sets the <code>Location</code> <code>String</code> below the
     * <code>Location</code> Label according to the <code>User</code>'s system location. Enables <code>French</code> translation
     * of the initialized scene text if the <code>User</code>'s system Locale is set to <code>French</code>.
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());
        loginUserLocationLbl.setText(String.valueOf(ZoneId.systemDefault()));

        if (Locale.getDefault().getLanguage().equals("fr")) {
            usernameLbl.setText(rb.getString("username"));
            passwordLbl.setText(rb.getString("password"));
            passTxtField.setPromptText(rb.getString("passwordprompt"));
            loginBtn.setText(rb.getString("login"));
            usernameTxtField.setPromptText(rb.getString("usernameprompt"));
            loginTitleLbl.setText(rb.getString("logintitle"));
            enterText.setText(rb.getString("enterprompt"));
            locationLbl.setText(rb.getString("location"));
        }
    }

    /**
     * Event Handler for the "<code>Login</code>" button on the <code>Login</code> scene. If the <code>User</code>'s
     * credentials are valid, redirects the <code>User</code> to the <code>HomeScreen</code> scene, where they can navigate the program.
     * Provides <code>Alert</code>s if credentials are invalid. Also calls the <code>invalidCredEN()</code> or <code>invalidCredFR()</code>
     * method in the <code>LoginAlerts</code> file, depending on system's locale. All login attempts result in text written to a file
     * that details the <code>User</code>'s <code>Username</code> and local system time, converted to <code>UTC</code>. All
     * text and <code>Alert</code>s are translated to <code>French</code> if the <code>User</code>'s system locale is set to
     * <code>French</code>.
     * @param actionEvent Triggered by clicking the "<code>Login</code>" button on the <code>Login</code>
     *                    scene. Loads the <code>HomeScreen</code> scene.
     * @throws Exception Thrown when input/output problems exist as a result of the method call.
     */
    public void onActLogInButton(ActionEvent actionEvent) throws Exception {
        if (Locale.getDefault().getLanguage().equals("fr")) {
            if (usernameTxtField.getText().isEmpty()) {
                noUserFR();
            }
            else if (passTxtField.getText().isEmpty()) {
                noPassFR();
            }
            else if (!(usernameTxtField.getText().isEmpty() && !(passTxtField.getText().isEmpty()))) {
                if (!(DBUsers.loginCredentialsCheck(usernameTxtField.getText(), passTxtField.getText()))) {
                    DBUsers.loginFailedFileWrite(usernameTxtField.getText());
                    invalidCredFR();
                }
                else {
                    DBUsers.loginSuccessFileWrite();
                    HomeScreen.checkAppointmentsFR();
                    stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                    scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/HomeScreen.fxml")));
                    stage.setScene(new Scene(scene));
                    stage.setTitle("C195 GUI-Based Scheduling Application");
                    stage.show();
                }
            }
        }
        else {
            if (usernameTxtField.getText().isEmpty()) {
                noUserEN();
            }
            else if (passTxtField.getText().isEmpty()) {
                noPassEN();
            }
            else if (!(usernameTxtField.getText().isEmpty()) && (!(passTxtField.getText().isEmpty()))) {
                if (!(DBUsers.loginCredentialsCheck(usernameTxtField.getText(), passTxtField.getText()))) {
                    DBUsers.loginFailedFileWrite(usernameTxtField.getText());
                    invalidCredEN();
                }
                else {
                    DBUsers.loginSuccessFileWrite();
                    HomeScreen.checkAppointments();
                    stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                    scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/HomeScreen.fxml")));
                    stage.setScene(new Scene(scene));
                    stage.setTitle("C195 GUI-Based Scheduling Application");
                    stage.show();
                }
            }
        }
    }
}

