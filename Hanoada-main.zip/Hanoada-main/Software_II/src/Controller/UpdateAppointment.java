package Controller;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomers;
import DBAccess.DBUsers;
import Helper.AppointmentAlerts;
import Helper.LocalTimePicker;
import Model.Appointment;
import Model.Contact;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.function.Supplier;

/**
 * Establishes the <code>UpdateAppointment</code> scene. Gives the <code>User</code> the ability to update a
 * selected <code>Appointment</code> from the connected MySQL server and the "appointmentsList" ObservableList contained
 * in the <code>DBAppointments</code> file.
 * */
public class UpdateAppointment implements Initializable {
    Stage stage;
    Parent scene;
    @FXML
    public TextField appointmentIDTxtField;
    @FXML
    public ComboBox<Contact> contactNameComboBox;
    @FXML
    public ComboBox<Integer> customerIDComboBox;
    @FXML
    public ComboBox<Integer> userIDComboBox;
    @FXML
    public ComboBox<String> typeComboBox;
    @FXML
    public DatePicker startDate;
    @FXML
    public ComboBox<LocalTime> startTimeCombo;
    @FXML
    public DatePicker endDate;
    @FXML
    public ComboBox<LocalTime> endTimeCombo;
    @FXML
    public TextField titleTxtField;
    @FXML
    public TextField descriptionTxtField;
    @FXML
    public TextField locationTxtField;
    public LocalDateTime startDateTime;
    public LocalDateTime endDateTime;

    public static Appointment updateAppointment = null;

    /**
     * Used to collect the appropriate <code>Appointment</code> information from the <code>Appointments</code> scene when the
     * "Update <code>Appointment</code>" button is pressed.
     * */
    public static void setAppointmentToUpdate(Appointment appointmentToUpdate) {
        updateAppointment = appointmentToUpdate;
    }

    /**
     * Event handler for the "Cancel" button on the <code>UpdateAppointment</code> scene. Cancels the action to update the
     * selected <code>Appointment</code> in the connected database and the "appointmentsList" ObservableList in the
     * <code>DBAppointments</code> file and loads the <code>Appointments</code> scene. Clicking this button will ensure no
     * edits are made to the selected <code>Appointment</code>.
     * @param actionEvent Triggered by clicking the "Cancel" button on the <code>UpdateAppointment</code> scene. Used to trigger
     *                    the program to discard any changed <code>Appointment</code> information for the selected
     *                    <code>Appointment</code> and load the <code>Appointments</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     * */
    public void onActUpdateApptCancelBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Appointments.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Enables use of the objects called by the method. Receives whatever data is necessary to make the object valid and
     * usable. Initializes the <code>UpdateAppointment</code> scene, sets the values in the <code>Type</code>, <code>Contact Name</code>,
     * <code>Customer ID</code>, and <code>User ID</code> ComboBoxes according to the information already present in the selected
     * <code>Appointment</code>. Also calls the <code>generateTimeCombos()</code> method
     * in the <code>LocalTimePicker</code> <code>Helper</code> class to generate dates and times in the <code>Start</code>
     * and <code>End</code> DatePicker and Time ComboBoxes and pre-fills them with pre-existing information from the selected
     * <code>Appointment</code>.
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        typeComboBox.setItems(DBAppointments.generateAppointmentTypes());
        try {
            contactNameComboBox.setItems(DBContacts.getAllContacts());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        customerIDComboBox.setItems(DBCustomers.getCustomerIds());
        try {
            userIDComboBox.setItems(DBUsers.getUserIDs());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        appointmentIDTxtField.setText(String.valueOf(updateAppointment.Appointment_ID));
        try {
            contactNameComboBox.setValue(DBContacts.getContact(updateAppointment.Contact_Name));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        startTimeCombo.setItems(LocalTimePicker.generateTimeCombos());
        endTimeCombo.setItems(LocalTimePicker.generateTimeCombos());
        Supplier<String> type = () -> updateAppointment.Type;
        typeComboBox.setValue(String.valueOf(type));
        titleTxtField.setText(updateAppointment.Title);
        descriptionTxtField.setText(updateAppointment.Description);
        locationTxtField.setText(updateAppointment.Location);
        typeComboBox.setValue(updateAppointment.getType());
        startDate.setValue(updateAppointment.Start.toLocalDate());
        endDate.setValue(updateAppointment.End.toLocalDate());
        startTimeCombo.setValue(updateAppointment.Start.toLocalTime());
        endTimeCombo.setValue(updateAppointment.End.toLocalTime());
        customerIDComboBox.setValue(updateAppointment.Customer_ID);
        userIDComboBox.setValue(updateAppointment.User_ID);
    }

    /**
     * Event Handler for the "Save" button in the <code>UpdateAppointment</code> scene. Provides input validation and logical error
     * checks using <code>Alert</code>s found in the <code>AppointmentAlerts</code> <code>Helper</code> class. If proposed
     * <code>Appointment</code> updates validate correctly, the method calls the <code>updateAppointment()</code> method
     * in the <code>DBAppointments</code> file, which updates the selected <code>Appointment</code> in the connected database.
     * If the <code>Appointment</code> is successfully updated in the connected database, the method returns the <code>User</code>
     * to the <code>Appointments</code> scene.
     *
     * @param actionEvent Triggered by clicking the "Save" button on the <code>UpdateAppointment</code> scene. Used to trigger
     *                    the program to update the selected <code>Appointment</code> information in the connected database
     *                    and load the <code>Appointments</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     * @throws SQLException thrown when problems occur while attempting to add information to the connected database.
     * */
    public void onActSaveBtn(ActionEvent actionEvent) throws IOException, SQLException {
        if (contactNameComboBox.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noContactNameSelected();
        }
        if (typeComboBox.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noTypeSelected();
            return;
        }
        if (startDate.getValue() == null || startTimeCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noStartDateTime();
            return;
        }
        if (endDate.getValue() == null || endTimeCombo.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noEndDateTime();
            return;
        }
        if (contactNameComboBox.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noContactSelected();
            return;
        }
        if (customerIDComboBox.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noCustomerIdSelected();
            return;
        }
        if (userIDComboBox.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noUserIdSelected();
            return;
        }
        startDateTime = LocalDateTime.of(startDate.getValue(), startTimeCombo.getSelectionModel().getSelectedItem());
        endDateTime = LocalDateTime.of(endDate.getValue(), endTimeCombo.getSelectionModel().getSelectedItem());

        if (AppointmentAlerts.validateUpdateAppointment(Integer.parseInt(appointmentIDTxtField.getText()), customerIDComboBox.getSelectionModel().getSelectedItem(), titleTxtField.getText(), descriptionTxtField.getText(), locationTxtField.getText(),
                startDateTime, endDateTime, typeComboBox.getSelectionModel().getSelectedItem())) {

            DBAppointments.updateAppointment(
                    Integer.parseInt(appointmentIDTxtField.getText()),
                    titleTxtField.getText(),
                    descriptionTxtField.getText(),
                    locationTxtField.getText(),
                    typeComboBox.getSelectionModel().getSelectedItem(),
                    startDateTime,
                    endDateTime,
                    DBUsers.getActiveUser(),
                    customerIDComboBox.getSelectionModel().getSelectedItem(),
                    userIDComboBox.getSelectionModel().getSelectedItem(),
                    contactNameComboBox.getSelectionModel().getSelectedItem().toString());

            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/Appointments.fxml")));
            stage.setScene(new Scene(scene));
            stage.show();
        }
    }
}
