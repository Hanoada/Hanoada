package Controller;

import DBAccess.DBAppointments;
import Helper.AppointmentAlerts;
import Model.Appointment;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Establishes the <code>Appointments</code> scene. Gives the <code>User</code> the ability to view <code>Appointment</code>s
 * from the connected MySQL server and the "appointmentsList" ObservableList contained in the <code>DBAppointments</code> file. Also
 * allows access to the <code>AddAppointment</code> and <code>UpdateAppointment</code> scenes and provides the ability to
 * delete <code>Appointment</code>s from the program and connected database.
 * */
public class Appointments implements Initializable{

    Stage stage;
    Parent scene;
    @FXML
    public ToggleGroup appointmentFilter;
    @FXML
    public TableView<Appointment> allAppointmentsTableView;
    @FXML
    public TableColumn<Appointment, Integer> apptsApptIdCol;
    @FXML
    public TableColumn<Appointment, String> apptsTitleCol;
    @FXML
    public TableColumn<Appointment, String> apptsDescriptionCol;
    @FXML
    public TableColumn<Appointment, String> apptsLocationCol;
    @FXML
    public TableColumn<Appointment, String> apptsTypeCol;
    @FXML
    public TableColumn<Appointment, LocalDateTime> apptsStartCol;
    @FXML
    public TableColumn<Appointment, LocalDateTime> apptsEndCol;
    @FXML
    public TableColumn<Appointment, Integer> apptsCustomerIdCol;
    @FXML
    public TableColumn<Appointment, Integer> apptsUserIdCol;
    @FXML
    public TableColumn<Appointment, String> appointmentContactCol;

    /**
     * Event Handler for the "Update <code>Appointment</code>" button on the <code>Appointments</code> scene under the
     * <code>Appointments</code> TableView. Redirects <code>User</code> to the <code>UpdateAppointment</code> scene,
     * where they can modify existing <code>Appointment</code> objects in the connected database and scheduling program.
     * Includes appropriate <code>Alert</code>s for input validation and logical error checks.
     * @param actionEvent Triggered by clicking the "Update <code>Appointment</code>" button on the <code>Appointments</code>
     *                    scene. Loads the <code>UpdateAppointment</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActApptUpdateApptBtn(ActionEvent actionEvent) throws IOException {
        if (allAppointmentsTableView.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noAppointmentSelected();
            return;
        }

        Appointment selectedAppointment = allAppointmentsTableView.getSelectionModel().getSelectedItem();
        UpdateAppointment.setAppointmentToUpdate(selectedAppointment);

        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/UpdateAppointment.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Event Handler for the "Back" button on the <code>Appointments</code> scene under the <code>Appointments</code>
     * TableView. Redirects <code>User</code> to the <code>HomeScreen</code> scene, where they can navigate to other
     * parts of the program.
     * @param actionEvent Triggered by clicking the "Back" button on the <code>Appointments</code>
     *                    scene. Loads the <code>HomeScreen</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActApptsExitBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/HomeScreen.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Event Handler for the "Add <code>Appointment</code>" button on the <code>Appointments</code> scene under the <code>Appointments</code>
     * TableView. Redirects <code>User</code> to the <code>AddAppointment</code> scene, where they can add <code>Appointment</code>s to the
     * database and program.
     * @param actionEvent Triggered by clicking the "Add <code>Appointment</code>" button on the <code>Appointments</code>
     *                    scene. Loads the <code>AddAppointment</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActApptAddApptBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/AddAppointment.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**
     * Enables use of the objects called by the method. Receives whatever data is necessary to make the object valid and
     * usable. Initializes the <code>Appointments</code> scene and generates the <code>Appointments</code> TableView.
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * Lambda <code>Comparator</code> is used to provide an initial <code>sort</code> of the <code>Appointments</code>
     * TableView by <code>Appointment_ID</code> when the scene loads.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        apptsApptIdCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
        apptsTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        apptsDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        apptsLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        appointmentContactCol.setCellValueFactory(new PropertyValueFactory<>("Contact_Name"));
        apptsTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        apptsStartCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        apptsEndCol.setCellValueFactory(new PropertyValueFactory<>("End"));
        apptsCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        apptsUserIdCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));
        ObservableList<Appointment> observableAppointments = DBAppointments.getAllAppointments();
        //LAMBDA EXPRESSION
        observableAppointments.sort(Comparator.comparingInt(a -> a.Appointment_ID));
        allAppointmentsTableView.setItems(observableAppointments);
    }

    /**
     * Event Handler for the "Delete Appointment" button on the <code>Appointments</code> scene. Ensures there is an
     * <code>Appointment</code> selected before attempting to delete. <code>Alert</code> is provided when an <code>Appointment</code>
     * is successfully deleted, detailing the <code>Appointment ID</code> and <code>Appointment</code> <code>Type</code>.
     * @throws SQLException thrown when problems occur while attempting to add information to the connected database.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * Lambda <code>Comparator</code> is used to provide a <code>sort</code> of the <code>Appointments</code>
     * TableView by <code>Appointment_ID</code> when an <code>Appointment</code> is deleted.
     * */
    public void onActDeleteAppointmentBtn() throws SQLException {
        if (allAppointmentsTableView.getSelectionModel().getSelectedItem() == null) {
            AppointmentAlerts.noAppointmentSelected();
            return;
        }
        int deletedApptID = allAppointmentsTableView.getSelectionModel().getSelectedItem().Appointment_ID;
        String deletedApptType = allAppointmentsTableView.getSelectionModel().getSelectedItem().Type;
        if (DBAppointments.deleteAppointment(allAppointmentsTableView.getSelectionModel().getSelectedItem().Appointment_ID)){
            Alert appointmentDeleted = new Alert(Alert.AlertType.INFORMATION, "APPOINTMENT DELETED... \n" + "Appointment ID: " + deletedApptID + "\n" + "Appointment Type: " + deletedApptType);
            appointmentDeleted.setTitle("Appointment Successfully Deleted");
            appointmentDeleted.setHeaderText("The selected appointment was successfully deleted.");
            Optional<ButtonType> deleted = appointmentDeleted.showAndWait();
            if (deleted.isPresent() && deleted.get() == ButtonType.OK) {
                appointmentDeleted.close();
            }
        }
        else {
            System.out.println("Appointment NOT Deleted!");
        }
        ObservableList<Appointment> observableAppointments = DBAppointments.getAllAppointments();
        //LAMBDA EXPRESSION
        observableAppointments.sort(Comparator.comparingInt(a -> a.Appointment_ID));
        allAppointmentsTableView.setItems(observableAppointments);
    }
    /**
     * Used in conjunction with <code>appointmentFilter</code> RadioButton ToggleGroup the to display ALL <code>Appointment</code>s
     * in the <code>Appointments</code> TableView.
     * */
    public void onActAllApptRadio() {
        allAppointmentsTableView.setItems(DBAppointments.getAllAppointments());
    }

    /**
     * Used in conjunction with <code>appointmentFilter</code> RadioButton ToggleGroup the to display WEEKLY (Next 7 Days)
     * <code>Appointment</code>s in the <code>Appointments</code> TableView.
     * */
    public void onActWeekApptRadio() {
        allAppointmentsTableView.setItems(DBAppointments.getWeeklyAppointments());
    }

    /**
     * Used in conjunction with <code>appointmentFilter</code> RadioButton ToggleGroup the to display MONTHLY (Next 30 Days)
     * <code>Appointment</code>s in the <code>Appointments</code> TableView.
     * */
    public void onActMonthApptRadio() {
        allAppointmentsTableView.setItems(DBAppointments.getMonthlyAppointments());
    }
}
