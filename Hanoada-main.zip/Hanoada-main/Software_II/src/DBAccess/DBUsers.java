package DBAccess;

import Helper.JDBC;
import Model.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * Establishes the <code>DBUsers</code> class. Provides database access methods specifically related
 * to <code>User</code>s. Uses multiple ObservableLists related to <code>User</code>s. This code uses <code>Constants</code>
 * for database access to facilitate easier updating in the event the code needs to be modified in the future. Rather than
 * updating multiple lines of code, you can simply change the column number in the <code>Constants</code>.
 * */
public class DBUsers {
    public static PrintWriter outputFile;

    /**
     * Used to prepare a <code>PrintWriter</code> called "outputFile" for printing. The <code>String</code> is the file location
     * for the "login_activity.txt" file, which stores all <code>login</code> attempts.
     * */
    public static void readyFile() throws IOException {
        String filename = "C:/Users/LabUser/Desktop/AdamHanover-C195-PerformanceAssessment/login_activity.txt";
        FileWriter fWriter = new FileWriter(filename, true);
        outputFile = new PrintWriter(fWriter);
        }
    public static final int USER_ID = 1;
    public static final int USER_NAME = 2;
    public static final int PASSWORD = 3;
    public static final int CREATE_DATE = 4;
    public static final int CREATED_BY = 5;
    public static final int LAST_UPDATE = 6;
    public static final int LAST_UPDATED_BY = 7;
    public static String activeUser = null;

    /**
     * Retrieves ALL <code>User</code>s from the connected database and adds them to the "usersList" ObservableList.
     * When the method is called, the "usersList" ObservableList is returned.
     * */
    public static ObservableList<User> getAllUsers() {
        ObservableList<User> usersList = FXCollections.observableArrayList();
        try {
            usersList.clear();
            String sql = "SELECT * FROM users";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                User newUser = new User(
                        rs.getInt(USER_ID),
                        rs.getString(USER_NAME),
                        rs.getString(PASSWORD),
                        rs.getTimestamp(CREATE_DATE),
                        rs.getString(CREATED_BY),
                        rs.getTimestamp(LAST_UPDATE),
                        rs.getString(LAST_UPDATED_BY));
                usersList.add(newUser);
            }
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return usersList;
    }

    /**
     * Retrieves <code>User_ID</code>s from the "usersList" ObservableList generated in the <code>DBUsers</code> file
     * and adds them to the "userIDs" ObservableList. When the method is called, the "userIDs" ObservableList is returned.
     * */
    public static ObservableList<Integer> getUserIDs() {
        ObservableList<Integer> userIDs = FXCollections.observableArrayList();

        for (int i = 0; i < getAllUsers().size(); ++i) {
            userIDs.add(getAllUsers().get(i).getUser_ID());
        }
        return userIDs;
    }

    /**
     * Receives a <code>User</code>-entered <code>Username</code> and <code>Password</code> and validates the fields
     * against the "usersList" ObservableList in the <code>DBUsers</code> file. Returns a boolean value; true if the
     * <code>Username</code> and <code>Password</code> match an existing <code>Username</code> and <code>Password</code> in
     * the connected database and program.
     * */
    public static boolean loginCredentialsCheck(String userName, String password) throws Exception {
        readyFile();
        for (int i = 0; i < getAllUsers().size(); ++i) {
            if (getAllUsers().get(i).getUser_Name().equals(userName) && getAllUsers().get(i).getPassword().equals(password)) {
                activeUser = getAllUsers().get(i).getUser_Name();
            return true;
            }
        }
        return false;
    }

    /**
     * Returns the active <code>User</code> that is logged-into the program. Generated during the <code>loginCredentialsCheck()</code>
     * method call in the <code>DBUsers</code> file. Used to set <code>Created_By</code> and <code>Last_Updated_By</code> fields
     * throughout the program.
     * */
    public static String getActiveUser() {
        return activeUser;
    }

    /**
     * Uses a <code>PrintWriter</code> created in the <code>DBUsers</code> file to record login attempts to the "login_activity.txt" file
     * required by this assessment. Generates a <b>successful</b> login attempt message and appends it to the "login_activity.txt" file.
     * */
    public static void loginSuccessFileWrite() throws IOException {
        readyFile();
        outputFile.println("User \"" + activeUser + "\" successfully logged in at " + Instant.now().truncatedTo(ChronoUnit.SECONDS) + " UTC.");
        outputFile.close();
    }

    /**
     * Uses a <code>PrintWriter</code> created in the <code>DBUsers</code> file to record login attempts to the "login_activity.txt" file
     * required by this assessment. Generates a <b>failed</b> login attempt message and appends it to the "login_activity.txt" file.
     * */
    public static void loginFailedFileWrite(String userName) throws IOException {
        readyFile();
        outputFile.println("User \"" + userName + "\" provided invalid logged credentials at " + Instant.now().truncatedTo(ChronoUnit.SECONDS) + " UTC.");
        outputFile.close();
    }
}