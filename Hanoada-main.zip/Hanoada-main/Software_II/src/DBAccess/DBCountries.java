package DBAccess;

import Helper.JDBC;
import Model.Countries;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Establishes the <code>DBCountries</code> class. Provides database access methods specifically related
 * to <code>Countries</code>.
 * */
public class DBCountries {
    /**
     * Retrieves ALL <code>Countries</code> from the connected database and adds them to the "cList" ObservableList.
     * When the method is called, the "cList" ObservableList is returned.
     * */
    public static ObservableList<Countries> getAllCountries() {
        ObservableList<Countries> cList = FXCollections.observableArrayList();
        try {
            String sql = "SELECT * FROM countries";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                int countryId = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");
                Countries C = new Countries(countryId, countryName);
                cList.add(C);
            }
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return cList;
    }

    /**
     * Retrieves ALL <code>Countries</code> from the connected database in a <code>User</code>-friendly <code>String</code>
     * format and adds them to the "cStrings" ObservableList. When the method is called, the "cStrings" ObservableList is returned.
     * */
    public static ObservableList<String> getAllCountryStrings() {
        ObservableList<String> cStrings = FXCollections.observableArrayList();
        cStrings.clear();
        try {
            String sql = "SELECT * FROM countries";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                String countryName = rs.getString("Country");
                cStrings.add(countryName);
            }
            cStrings.add("All");
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return cStrings;
    }

}
