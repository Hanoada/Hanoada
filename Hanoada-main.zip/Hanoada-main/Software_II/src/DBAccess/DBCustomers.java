package DBAccess;

import Helper.JDBC;
import Model.Customer;
import Model.First_Level_Division;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

/**
 * Establishes the <code>DBCustomers</code> class. Provides database access methods specifically related
 * to <code>Customer</code>s. Uses multiple ObservableLists related to <code>Customer</code>s. This code uses <code>Constants</code>
 * for database access to facilitate easier updating in the event the code needs to be modified in the future. Rather than
 * updating multiple lines of code, you can simply change the column number in the <code>Constants</code>.
 * */
public class DBCustomers {

    //CONSTANTS for database access by column for customers.
    public static final int CUSTOMER_ID = 1;
    public static final int CUSTOMER_NAME = 2;
    public static final int ADDRESS = 3;
    public static final int POSTAL_CODE = 4;
    public static final int PHONE = 5;
    public static final int CREATE_DATE = 6;
    public static final int CREATED_BY = 7;
    public static final int LAST_UPDATE = 8;
    public static final int LAST_UPDATED_BY = 9;
    public static final int DIVISION_ID = 10;
    public static final int DIVISION = 11;
    public static final int COUNTRY = 12;
    public static int customerID = 0;
    public static String customerName = null;
    public static String customerAddress = null;
    public static String customerPostalCode = null;
    public static String customerPhone = null;
    public static Timestamp customerCreateDate = null;
    public static String customerCreatedBy = null;
    public static Timestamp customerLastUpdate = null;
    public static String customerLastUpdatedBy = null;
    public static int customerDivisionID = 0;
    public static String customerDivision = null;
    public static String customerCountry = null;

    /**
     * Retrieves ALL <code>Customer</code>s from the connected database and adds them to the "customerList" ObservableList.
     * When the method is called, the "customerList" ObservableList is returned.
     * */
    public static ObservableList<Customer> getAllCustomers() {
        ObservableList<Customer> customerList = FXCollections.observableArrayList();
        try {
            customerList.clear();
            String sql = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, customers.Create_Date, customers.Created_By, customers.Last_Update, customers.Last_Updated_by, customers.Division_ID, first_level_divisions.Division, countries.Country " +
                    "FROM first_level_divisions " +
                    "INNER JOIN customers ON customers.Division_ID=first_level_divisions.Division_ID " +
                    "INNER JOIN countries ON countries.Country_ID=first_level_divisions.Country_ID ";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                customerID = rs.getInt(CUSTOMER_ID);
                customerName = rs.getString(CUSTOMER_NAME);
                customerAddress = rs.getString(ADDRESS);
                customerPostalCode = rs.getString(POSTAL_CODE);
                customerPhone = rs.getString(PHONE);
                customerCreateDate = rs.getTimestamp(CREATE_DATE);
                customerCreatedBy = rs.getString(CREATED_BY);
                customerLastUpdate = rs.getTimestamp(LAST_UPDATE);
                customerLastUpdatedBy = rs.getString(LAST_UPDATED_BY);
                customerDivisionID = rs.getInt(DIVISION_ID);
                customerDivision = rs.getString(DIVISION);
                customerCountry = rs.getString(COUNTRY);

                Customer newCustomer = new Customer(
                        customerID,
                        customerName,
                        customerAddress,
                        customerPostalCode,
                        customerPhone,
                        customerCreateDate.toLocalDateTime(),
                        customerCreatedBy,
                        customerLastUpdate.toLocalDateTime(),
                        customerLastUpdatedBy,
                        customerDivisionID,
                        customerDivision,
                        customerCountry);
                customerList.add(newCustomer);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return customerList;
    }


    /**
     * Retrieves information entered by the <code>User</code> on the <code>AddCustomer</code> scene to generate
     * a <code>SQL</code> statement and add the <code>Customer</code> to the database.
     * @param Customer_Name Passed to the method from the <code>AddCustomer</code> scene, used to specify the <code>Customer</code>
     *                    Name to be stored in the connected database.
     * @param Address Passed to the method from the <code>AddCustomer</code> scene, used to specify the <code>Customer</code>
     *                <code>Address</code> to be stored in the connected database.
     * @param Postal_Code Passed to the method from the <code>AddCustomer</code> scene, used to specify the <code>Customer</code>
     *             <code>Postal_Code</code> to be stored in the connected database.
     * @param Phone Passed to the method from the <code>AddCustomer</code> scene, used to specify the <code>Customer</code>
     *              <code>Phone</code> number to be stored in the connected database.
     * @param Created_By Passed to the method from the <code>AddCustomer</code> scene, used to specify the <code>Customer</code>
     *                   <code>Created_By</code> field to be stored in the connected database.
     * @param Last_Updated_By Passed to the method from the <code>AddCustomer</code> scene, used to specify the <code>Customer</code>
     *                        <code>Last_Updated_By</code> field to be stored in the connected database.
     * @param divisionName Passed to the method from the <code>AddCustomer</code> scene, used to specify the <code>Customer</code>
     *                    <code>divisionName</code> or <code>State / Province</code> to be stored in the connected database.
     * */
        public static void insert(String Customer_Name, String Address, String Postal_Code,
                              String Phone, String Created_By, String Last_Updated_By, String divisionName) {
        First_Level_Division newFLD = DBFirst_Level_Divisions.getFirstLevelDivision(divisionName);
            assert newFLD != null;
            int fldId = newFLD.getfldId();
        int CustomerID = 0;
        String sql = "INSERT INTO customers (Customer_ID, Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) " +
                "VALUES(?, ?, ?, ?, ?, now(), ?, now(), ?, ?)";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ps.setInt(1, CustomerID);
            ps.setString(2, Customer_Name);
            ps.setString(3, Address);
            ps.setString(4, Postal_Code);
            ps.setString(5, Phone);
            ps.setString(6, Created_By);
            ps.setString(7, Last_Updated_By);
            ps.setInt(8, fldId);
            ps.execute();
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
    }

    /**
     * Creates an ObservableList of <code>Customer ID</code>s to display and interact with throughout the program.
     * Returns the "customerIDs" ObservableList when called. Used to display <code>Customer ID</code>s in TableViews in
     * multiple scenes.
     * */
    public static ObservableList<Integer> getCustomerIds() {
        ObservableList<Integer> customerIDs = FXCollections.observableArrayList();

        for (int i = 0; i < getAllCustomers().size(); ++i) {
            customerIDs.add(getAllCustomers().get(i).getCustomer_ID());
        }
        return customerIDs;
    }

    /**
     * Retrieves USA <code>Customer</code>s from the connected database and adds them to the "USACustomers" ObservableList.
     * When the method is called, the "USACustomers" ObservableList is returned. Used in conjunction with a ComboBox on the
     * <code>Customers</code> scene to filter the TableView by <code>Customer</code> <code>Country</code> to only show
     * <code>Customer</code>s in the USA.
     * @throws SQLException thrown when problems occur while attempting to retrieve information from the connected database.
     * */
    public static ObservableList<Customer> getUSACustomers() throws SQLException {
        ObservableList<Customer> USACustomers = FXCollections.observableArrayList();
        String sql = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, customers.Create_Date, customers.Created_By, customers.Last_Update, customers.Last_Updated_by, customers.Division_ID, first_level_divisions.Division, countries.Country " +
                "FROM first_level_divisions " +
                "INNER JOIN customers ON customers.Division_ID=first_level_divisions.Division_ID " +
                "INNER JOIN countries ON countries.Country_ID=first_level_divisions.Country_ID " +
                "WHERE countries.Country_ID = 1 " +
                "ORDER BY countries.Country_ID;";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        try{
        while (rs.next()) {
            customerID = rs.getInt(CUSTOMER_ID);
            customerName = rs.getString(CUSTOMER_NAME);
            customerAddress = rs.getString(ADDRESS);
            customerPostalCode = rs.getString(POSTAL_CODE);
            customerPhone = rs.getString(PHONE);
            customerCreateDate = rs.getTimestamp(CREATE_DATE);
            customerCreatedBy = rs.getString(CREATED_BY);
            customerLastUpdate = rs.getTimestamp(LAST_UPDATE);
            customerLastUpdatedBy = rs.getString(LAST_UPDATED_BY);
            customerDivisionID = rs.getInt(DIVISION_ID);
            customerDivision = rs.getString(DIVISION);
            customerCountry = rs.getString(COUNTRY);

            Customer newCustomer = new Customer(
                    customerID,
                    customerName,
                    customerAddress,
                    customerPostalCode,
                    customerPhone,
                    customerCreateDate.toLocalDateTime(),
                    customerCreatedBy,
                    customerLastUpdate.toLocalDateTime(),
                    customerLastUpdatedBy,
                    customerDivisionID,
                    customerDivision,
                    customerCountry);
            USACustomers.add(newCustomer);
        }
    } catch (SQLException e) {
        throw new RuntimeException(e);
    }
        return USACustomers;
    }

    /**
     * Retrieves UK <code>Customer</code>s from the connected database and adds them to the "UKCustomers" ObservableList.
     * When the method is called, the "UKCustomers" ObservableList is returned. Used in conjunction with a ComboBox on the
     * <code>Customers</code> scene to filter the TableView by <code>Customer</code> <code>Country</code> to only show
     * <code>Customer</code>s in the UK.
     * @throws SQLException thrown when problems occur while attempting to retrieve information from the connected database.
     * */
    public static ObservableList<Customer> getUKCustomers() throws SQLException {
        ObservableList<Customer> UKCustomers = FXCollections.observableArrayList();
        String sql = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, customers.Create_Date, customers.Created_By, customers.Last_Update, customers.Last_Updated_by, customers.Division_ID, first_level_divisions.Division, countries.Country " +
                "FROM first_level_divisions " +
                "INNER JOIN customers ON customers.Division_ID=first_level_divisions.Division_ID " +
                "INNER JOIN countries ON countries.Country_ID=first_level_divisions.Country_ID " +
                "WHERE countries.Country_ID = 2 " +
                "ORDER BY countries.Country_ID;";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        try{
            while (rs.next()) {
                customerID = rs.getInt(CUSTOMER_ID);
                customerName = rs.getString(CUSTOMER_NAME);
                customerAddress = rs.getString(ADDRESS);
                customerPostalCode = rs.getString(POSTAL_CODE);
                customerPhone = rs.getString(PHONE);
                customerCreateDate = rs.getTimestamp(CREATE_DATE);
                customerCreatedBy = rs.getString(CREATED_BY);
                customerLastUpdate = rs.getTimestamp(LAST_UPDATE);
                customerLastUpdatedBy = rs.getString(LAST_UPDATED_BY);
                customerDivisionID = rs.getInt(DIVISION_ID);
                customerDivision = rs.getString(DIVISION);
                customerCountry = rs.getString(COUNTRY);

                Customer newCustomer = new Customer(
                        customerID,
                        customerName,
                        customerAddress,
                        customerPostalCode,
                        customerPhone,
                        customerCreateDate.toLocalDateTime(),
                        customerCreatedBy,
                        customerLastUpdate.toLocalDateTime(),
                        customerLastUpdatedBy,
                        customerDivisionID,
                        customerDivision,
                        customerCountry);
                UKCustomers.add(newCustomer);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return UKCustomers;
    }

    /**
     * Retrieves Canadian <code>Customer</code>s from the connected database and adds them to the "CanadaCustomers" ObservableList.
     * When the method is called, the "CanadaCustomers" ObservableList is returned. Used in conjunction with a ComboBox on the
     * <code>Customers</code> scene to filter the TableView by <code>Customer</code> <code>Country</code> to only show
     * <code>Customer</code>s in Canada.
     * @throws SQLException thrown when problems occur while attempting to retrieve information from the connected database.
     * */
    public static ObservableList<Customer> getCanadaCustomers() throws SQLException {
        ObservableList<Customer> CanadaCustomers = FXCollections.observableArrayList();
        String sql = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, customers.Create_Date, customers.Created_By, customers.Last_Update, customers.Last_Updated_by, customers.Division_ID, first_level_divisions.Division, countries.Country " +
                "FROM first_level_divisions " +
                "INNER JOIN customers ON customers.Division_ID=first_level_divisions.Division_ID " +
                "INNER JOIN countries ON countries.Country_ID=first_level_divisions.Country_ID " +
                "WHERE countries.Country_ID = 3 " +
                "ORDER BY countries.Country_ID;";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        try{
            while (rs.next()) {
                customerID = rs.getInt(CUSTOMER_ID);
                customerName = rs.getString(CUSTOMER_NAME);
                customerAddress = rs.getString(ADDRESS);
                customerPostalCode = rs.getString(POSTAL_CODE);
                customerPhone = rs.getString(PHONE);
                customerCreateDate = rs.getTimestamp(CREATE_DATE);
                customerCreatedBy = rs.getString(CREATED_BY);
                customerLastUpdate = rs.getTimestamp(LAST_UPDATE);
                customerLastUpdatedBy = rs.getString(LAST_UPDATED_BY);
                customerDivisionID = rs.getInt(DIVISION_ID);
                customerDivision = rs.getString(DIVISION);
                customerCountry = rs.getString(COUNTRY);

                Customer newCustomer = new Customer(
                        customerID,
                        customerName,
                        customerAddress,
                        customerPostalCode,
                        customerPhone,
                        customerCreateDate.toLocalDateTime(),
                        customerCreatedBy,
                        customerLastUpdate.toLocalDateTime(),
                        customerLastUpdatedBy,
                        customerDivisionID,
                        customerDivision,
                        customerCountry);
                CanadaCustomers.add(newCustomer);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return CanadaCustomers;
    }

    /**
     * Retrieves information entered by the <code>User</code> on the <code>UpdateCustomer</code> scene to generate
     * a <code>SQL</code> statement and update the <code>Customer</code> in the database.
     * @param Customer_ID Passed to the method from the <code>UpdateCustomer</code> scene, used to locate the
     *                    <code>Customer</code> in the connected database. The <code>Customer_ID</code> is never updated.
     * @param Customer_Name Passed to the method from the <code>UpdateCustomer</code> scene, used to specify the <code>Customer</code>
     *                    Name to be stored in the connected database.
     * @param Address Passed to the method from the <code>UpdateCustomer</code> scene, used to specify the <code>Customer</code>
     *                <code>Address</code> to be stored in the connected database.
     * @param Postal_Code Passed to the method from the <code>UpdateCustomer</code> scene, used to specify the <code>Customer</code>
     *             <code>Postal_Code</code> to be stored in the connected database.
     * @param Phone Passed to the method from the <code>UpdateCustomer</code> scene, used to specify the <code>Customer</code>
     *              <code>Phone</code> number to be stored in the connected database.
     * @param Created_By Passed to the method from the <code>UpdateCustomer</code> scene, used to specify the <code>Customer</code>
     *                   <code>Created_By</code> field to be stored in the connected database.
     * @param Last_Updated_By Passed to the method from the <code>UpdateCustomer</code> scene, used to specify the <code>Customer</code>
     *                        <code>Last_Updated_By</code> field to be stored in the connected database.
     * @param divisionName Passed to the method from the <code>UpdateCustomer</code> scene, used to specify the <code>Customer</code>
     *                    <code>divisionName</code> or <code>State / Province</code> to be stored in the connected database.
     * */
    public static void updateCustomer(int Customer_ID, String Customer_Name, String Address, String Postal_Code,
                              String Phone, String Created_By, String Last_Updated_By, String divisionName) {
        First_Level_Division newFLD = DBFirst_Level_Divisions.getFirstLevelDivision(divisionName);
        assert newFLD != null;
        int fldId = newFLD.getfldId();
        String sql = "UPDATE client_schedule.customers " +
                "SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Created_By = ?, Last_Update = NOW(), Last_Updated_By = ?, Division_ID = ? WHERE Customer_ID = ?;";
        try {
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ps.setString(1, Customer_Name);
            ps.setString(2, Address);
            ps.setString(3, Postal_Code);
            ps.setString(4, Phone);
            ps.setString(5, Created_By);
            ps.setString(6, Last_Updated_By);
            ps.setInt(7, fldId);
            ps.setInt(8, Customer_ID);
            ps.execute();
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
    }

    /**
     * Deletes a <code>Customer</code> from the database when called. Uses the selected <code>Customer</code>'s information
     * to generate a <code>SQL</code> statement to perform the deletion from the connected database.
     *
     * @param customerToDelete Passed to the method from the <code>Customers</code> scene, used to specify the
     *                            <code>Customer</code> to delete from the connected database, using the <code>Customer ID</code>.
     * @throws SQLException thrown when problems occur while attempting to remove information from the connected database.
     * */
    public static boolean deleteCustomer(int customerToDelete) throws SQLException {
        Alert deleteConfirm = new Alert(Alert.AlertType.WARNING, "Are You Sure You Want to Delete This Customer and ALL Associated Appointments?", ButtonType.YES, ButtonType.CANCEL);
        deleteConfirm.setTitle("CONFIRM Delete Customer");
        deleteConfirm.setHeaderText("Deleting This Customer Will Also Delete ALL Appointments Associated With This Customer.");
        Optional<ButtonType> deleteConfirmBtn = deleteConfirm.showAndWait();
        if (deleteConfirmBtn.isPresent() && deleteConfirmBtn.get() == ButtonType.YES) {
            String deleteAssociatedAppointments = "DELETE FROM appointments WHERE Customer_ID = " + customerToDelete;
            PreparedStatement deleteAppts = JDBC.getConnection().prepareStatement(deleteAssociatedAppointments);
            deleteAppts.executeUpdate();
            String deleteCustomer = "DELETE FROM customers WHERE Customer_ID = " + customerToDelete;
            PreparedStatement deleteCust = JDBC.getConnection().prepareStatement(deleteCustomer);
            deleteCust.executeUpdate();
            return true;
        } else {
            return false;
        }
    }

    /**
     * Retrieves all <code>Customer</code>s from the connected database and adds them to the "customReportCustomers" ObservableList.
     * When the method is called, the "customReportCustomers" ObservableList is returned. Used to populate the third (custom)
     * <code>Report</code> in the <code>Reports</code> scene. After gathering the information, it is looped through a while loop to
     * determine the age of each <code>Customer</code> account, based on the <code>Create_Date</code>.
     * @throws SQLException thrown when problems occur while attempting to retrieve information from the connected database.
     * */
    public static ObservableList<Customer> getCustomCustomerList() throws SQLException {
        ObservableList<Customer> customReportCustomers = FXCollections.observableArrayList();
        String sql = "SELECT * FROM customers;";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        try {
            while (rs.next()) {
                int Customer_ID = rs.getInt(1);
                String Customer_Name = rs.getString(2);
                Timestamp LocalTimeStamp = rs.getTimestamp(6);

                long days = ChronoUnit.DAYS.between(LocalTimeStamp.toLocalDateTime(), LocalDateTime.now());

                Customer newCustomer = new Customer(
                        Customer_ID, Customer_Name, LocalTimeStamp.toLocalDateTime(), (int) days);
                customReportCustomers.add(newCustomer);
            }
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return customReportCustomers;
    }
}
