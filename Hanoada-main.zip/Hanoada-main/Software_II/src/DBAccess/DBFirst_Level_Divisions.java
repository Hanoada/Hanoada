package DBAccess;

import Helper.JDBC;
import Model.First_Level_Division;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

/**
 * Establishes the <code>DBFirst_Level_Divisions</code> class. Provides database access methods specifically related
 * to <code>First_Level_Division</code>s (or <code>State / Province</code>s). Uses multiple ObservableLists related to <code>First_Level_Division</code>s.
 * This code uses <code>Constants</code> for database access to facilitate easier updating in the event the code needs to be modified in the future. Rather than
 * updating multiple lines of code, you can simply change the column number in the <code>Constants</code>.
 * */
public class DBFirst_Level_Divisions {

    public static final int FLD_DIVISION_ID = 1;
    public static final int FLD_DIVISION = 2;
    public static final int FLD_CREATE_DATE = 3;
    public static final int FLD_CREATED_BY = 4;
    public static final int FLD_LAST_UPDATE = 5;
    public static final int FLD_LAST_UPDATED_BY = 6;
    public static final int FLD_COUNTRY_ID = 7;

    /**
     * Retrieves ALL <code>First_Level_Division</code>s from the connected database and adds them to the "fldList" ObservableList.
     * When the method is called, the "fldList" ObservableList is returned.
     * */
    public static ObservableList<First_Level_Division> getAllFirstLeveLDivisions() {
        ObservableList<First_Level_Division> fldList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * FROM first_level_divisions";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                int divisionId = rs.getInt(FLD_DIVISION_ID);
                String division = rs.getString(FLD_DIVISION);
                LocalDateTime createDate = rs.getTimestamp(FLD_CREATE_DATE).toLocalDateTime();
                String createdBy = rs.getString(FLD_CREATED_BY);
                LocalDateTime lastUpdate = rs.getTimestamp(FLD_LAST_UPDATE).toLocalDateTime();
                String lastUpdatedBy = rs.getString(FLD_LAST_UPDATED_BY);
                int countryId = rs.getInt(FLD_COUNTRY_ID);

                First_Level_Division fld = new First_Level_Division(divisionId, division, createDate, createdBy, lastUpdate, lastUpdatedBy, countryId);
                fldList.add(fld);
            }
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return fldList;
    }

    /**
     * Retrieves a specific <code>First_Level_Division</code> from the connected database using its name as a parameter to search
     * the connected database. When the method is called, the associated <code>First_Level_Division</code> is returned.
     * */
    public static First_Level_Division getFirstLevelDivision(String fldName){
        for (int i = 0; i < DBFirst_Level_Divisions.getAllFirstLeveLDivisions().size(); ++i){
            if (DBFirst_Level_Divisions.getAllFirstLeveLDivisions().get(i).getFldName().equals(fldName)) {
                return DBFirst_Level_Divisions.getAllFirstLeveLDivisions().get(i);
            }
        }
        return null;
    }

    /**
     * Retrieves USA <code>First_Level_Division</code>s from the connected database and adds them to the "USAFLDs" ObservableList.
     * When the method is called, the "USAFLDs" ObservableList is returned. Used in conjunction with two ComboBoxes on the
     * <code>AddCustomer</code> and <code>UpdateCustomer</code> scenes to allow the <code>User</code> to select or update the
     * <code>State / Province</code> for the <code>Customer</code>. If the <code>User</code> selects "U.S" from the <code>Country</code> ComboBox,
     * this method automatically populates the "State / Province" ComboBox with <code>First_Level_Division</code>s in the USA.
     * */
    public static ObservableList<First_Level_Division> getUSAFLDs() {
        ObservableList<First_Level_Division> USAFLDs = FXCollections.observableArrayList();
        try {
            String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = 1";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                int divisionId = rs.getInt(FLD_DIVISION_ID);
                String division = rs.getString(FLD_DIVISION);
                LocalDateTime createDate = rs.getTimestamp(FLD_CREATE_DATE).toLocalDateTime();
                String createdBy = rs.getString(FLD_CREATED_BY);
                LocalDateTime lastUpdate = rs.getTimestamp(FLD_LAST_UPDATE).toLocalDateTime();
                String lastUpdatedBy = rs.getString(FLD_LAST_UPDATED_BY);
                int countryId = rs.getInt(FLD_COUNTRY_ID);

                First_Level_Division fld = new First_Level_Division(divisionId, division, createDate, createdBy, lastUpdate, lastUpdatedBy, countryId);
                USAFLDs.add(fld);
            }
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return USAFLDs;
    }

    /**
     * Retrieves Canada <code>First_Level_Division</code>s from the connected database and adds them to the "CanadaFLDs" ObservableList.
     * When the method is called, the "CanadaFLDs" ObservableList is returned. Used in conjunction with two ComboBoxes on the
     * <code>AddCustomer</code> and <code>UpdateCustomer</code> scenes to allow the <code>User</code> to select or update the
     * <code>State / Province</code> for the <code>Customer</code>. If the <code>User</code> selects "Canada" from the <code>Country</code> ComboBox,
     * this method automatically populates the "State / Province" ComboBox with <code>First_Level_Division</code>s in Canada.
     * */
    public static ObservableList<First_Level_Division> getCanadaFLDs() {
        ObservableList<First_Level_Division> CanadaFLDs = FXCollections.observableArrayList();
        try {
            String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = 3";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                int divisionId = rs.getInt(FLD_DIVISION_ID);
                String division = rs.getString(FLD_DIVISION);
                LocalDateTime createDate = rs.getTimestamp(FLD_CREATE_DATE).toLocalDateTime();
                String createdBy = rs.getString(FLD_CREATED_BY);
                LocalDateTime lastUpdate = rs.getTimestamp(FLD_LAST_UPDATE).toLocalDateTime();
                String lastUpdatedBy = rs.getString(FLD_LAST_UPDATED_BY);
                int countryId = rs.getInt(FLD_COUNTRY_ID);

                First_Level_Division fld = new First_Level_Division(divisionId, division, createDate, createdBy, lastUpdate, lastUpdatedBy, countryId);
                CanadaFLDs.add(fld);
            }
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return CanadaFLDs;
    }

    /**
     * Retrieves UK <code>First_Level_Division</code>s from the connected database and adds them to the "UKFLDs" ObservableList.
     * When the method is called, the "UKFLDs" ObservableList is returned. Used in conjunction with two ComboBoxes on the
     * <code>AddCustomer</code> and <code>UpdateCustomer</code> scenes to allow the <code>User</code> to select or update the
     * <code>State / Province</code> for the <code>Customer</code>. If the <code>User</code> selects "UK" from the <code>Country</code> ComboBox,
     * this method automatically populates the "State / Province" ComboBox with <code>First_Level_Division</code>s in the UK.
     * */
    public static ObservableList<First_Level_Division> getUKFLDs() {
        ObservableList<First_Level_Division> UKFLDs = FXCollections.observableArrayList();
        try {
            String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = 2";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                int divisionId = rs.getInt(FLD_DIVISION_ID);
                String division = rs.getString(FLD_DIVISION);
                LocalDateTime createDate = rs.getTimestamp(FLD_CREATE_DATE).toLocalDateTime();
                String createdBy = rs.getString(FLD_CREATED_BY);
                LocalDateTime lastUpdate = rs.getTimestamp(FLD_LAST_UPDATE).toLocalDateTime();
                String lastUpdatedBy = rs.getString(FLD_LAST_UPDATED_BY);
                int countryId = rs.getInt(FLD_COUNTRY_ID);

                First_Level_Division fld = new First_Level_Division(divisionId, division, createDate, createdBy, lastUpdate, lastUpdatedBy, countryId);
                UKFLDs.add(fld);
            }
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return UKFLDs;
    }


}
