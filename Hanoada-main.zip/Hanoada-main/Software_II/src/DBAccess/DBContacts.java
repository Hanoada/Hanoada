package DBAccess;

import Helper.JDBC;
import Model.Contact;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Establishes the <code>DBContacts</code> class. Provides database access methods specifically related
 * to <code>Contact</code>s. This code uses <code>Constants</code> for database access to facilitate easier updating
 * in the event the code needs to be modified in the future. Rather than updating multiple lines of code, you can simply
 * change the column number in the <code>Constants</code>.
 * */
public class DBContacts {
    public static final int CONTACT_ID = 1;
    public static final int CONTACT_NAME = 2;
    public static final int EMAIL = 3;
    public static int Contact_ID = 0;
    public static String Contact_Name = null;
    public static String Email = null;

    /**
     * Retrieves ALL <code>Contact</code>s from the connected database and adds them to the "allContacts" ObservableList.
     * When the method is called, the "allContacts" ObservableList is returned.
     * @throws SQLException thrown when problems occur while attempting to remove information from the connected database.
     * */
    public static ObservableList<Contact> getAllContacts() throws SQLException {
        ObservableList<Contact> allContacts = FXCollections.observableArrayList();
        try {
            String sql = "SELECT * FROM contacts";
            PreparedStatement psGetContacts = JDBC.getConnection().prepareStatement(sql);
            ResultSet rsContacts = psGetContacts.executeQuery(sql);

            while (rsContacts.next()) {
                Contact_ID = rsContacts.getInt(CONTACT_ID);
                Contact_Name = rsContacts.getString(CONTACT_NAME);
                Email = rsContacts.getString(EMAIL);

                Contact newContact = new Contact(
                        Contact_ID,
                        Contact_Name,
                        Email);
                allContacts.add(newContact);
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return allContacts;
    }

    /**
     * Retrieves the <code>Contact ID</code> from the connected database associated with the <code>Contact</code> Name passed to
     * the method. When the method is called, the <code>Contact ID</code> is returned by searching the connected database for
     * entries with a matching <code>Contact</code> name.
     * @param contactName Used to search the connected database for entries with a matching <code>Contact</code> Name.
     * @throws SQLException thrown when problems occur while attempting to add information to the connected database.
     * */
    public static int getContactID (String contactName) throws SQLException {

        String sql = "SELECT * FROM contacts WHERE Contact_Name = \"" + contactName + "\";";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery(sql);
        rs.next();
        return rs.getInt(CONTACT_ID);
    }

    /**
     * Retrieves the <code>Contact</code> from the connected database associated with the <code>Contact</code> Name passed to
     * the method. When the method is called, the <code>Contact</code> is returned by searching the connected database for
     * entries with a matching <code>Contact</code> name. Used to populate the <code>Contact</code> ComboBox in the
     * <code>UpdateAppointment</code> scene.
     * @param contactName Used to search the connected database for entries with a matching <code>Contact</code> Name.
     * @throws SQLException thrown when problems occur while attempting to get information to the connected database.
     * */
    public static Contact getContact (String contactName) throws SQLException {
        String sql = "SELECT * FROM contacts WHERE Contact_Name = \"" + contactName + "\";";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery(sql);

        rs.next();
        Contact_ID = rs.getInt(CONTACT_ID);
        Contact_Name = rs.getString(CONTACT_NAME);
        Email = rs.getString(EMAIL);

        return new Contact(
                Contact_ID,
                Contact_Name,
                Email);
    }
    /**
     * Used to generate a <code>User</code>-friendly <code>String</code> version of <code>Contact</code> Names, used in
     * ComboBoxes and TableViews across the program.
     * */
    @Override
    public String toString(){
        return (Contact_Name);
    }
}
