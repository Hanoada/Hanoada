package Helper;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

/**
 * Establishes the <code>CustomerAlerts</code> <code>Helper</code> class. Provides <code>Alert</code>s specifically related
 * to <code>Customer</code>s. Uses information passed to the <code>CustomerAlerts</code> file to generate appropriate
 * <code>Alert</code>s for input validation and logical error checking.
 * */
public class CustomerAlerts {

    /**
     * Logical error check method displays an <code>Alert</code> if the <code>User</code> did not select a <code>Customer</code>
     * from the <code>Customers</code> scene TableView before clicking the "Update Customer" button in the same scene.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noCustomerSelected() {
        Alert noTypeSelected = new Alert(Alert.AlertType.WARNING);
        noTypeSelected.setTitle("No CUSTOMER Selected");
        noTypeSelected.setHeaderText("Please Select a CUSTOMER First");
        noTypeSelected.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noTypeSelected.close();
            }
        }));
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not provide a Name
     * for a <code>Customer</code> they are attempting to add or update from the <code>AddCustomer</code> and
     * <code>UpdateCustomer</code> scenes respectively.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noName() {
        Alert noName = new Alert(Alert.AlertType.WARNING);
        noName.setTitle("No NAME");
        noName.setHeaderText("Please Provide a NAME");
        noName.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noName.close();
            }
        }));
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Country</code>
     * for a <code>Customer</code> they are attempting to add or update from the <code>AddCustomer</code> and <code>UpdateCustomer</code>
     * scenes respectively.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noCountry() {
        Alert noName = new Alert(Alert.AlertType.WARNING);
        noName.setTitle("No COUNTRY");
        noName.setHeaderText("Please Select a COUNTRY from the \"Country\" ComboBox");
        noName.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noName.close();
            }
        }));
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>State / Province</code>
     * for a <code>Customer</code> they are attempting to add or update from the <code>AddCustomer</code> and <code>UpdateCustomer</code>
     * scenes respectively.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noState() {
        Alert noName = new Alert(Alert.AlertType.WARNING);
        noName.setTitle("No STATE / PROVINCE");
        noName.setHeaderText("Please Select a STATE / PROVINCE from the \"State / Province\" ComboBox");
        noName.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noName.close();
            }
        }));
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not provide an <code>Address</code>
     * for a <code>Customer</code> they are attempting to add or update from the <code>AddCustomer</code> and <code>UpdateCustomer</code>
     * scenes respectively.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noAddress() {
        Alert noName = new Alert(Alert.AlertType.WARNING);
        noName.setTitle("No ADDRESS");
        noName.setHeaderText("Please Provide an ADDRESS");
        noName.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noName.close();
            }
        }));
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Postal_Code</code>
     * for a <code>Customer</code> they are attempting to add or update from the <code>AddCustomer</code> and <code>UpdateCustomer</code>
     * scenes respectively.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noPostal() {
        Alert noName = new Alert(Alert.AlertType.WARNING);
        noName.setTitle("No POSTAL CODE");
        noName.setHeaderText("Please Provide a POSTAL CODE");
        noName.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noName.close();
            }
        }));
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Phone</code> Number
     * for a <code>Customer</code> they are attempting to add or update from the <code>AddCustomer</code> and <code>UpdateCustomer</code>
     * scenes respectively.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noPhone() {
        Alert noName = new Alert(Alert.AlertType.WARNING);
        noName.setTitle("No PHONE NUMBER");
        noName.setHeaderText("Please Provide a PHONE NUMBER");
        noName.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noName.close();
            }
        }));
    }
}
