package Helper;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;

import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Establishes the <code>LoginAlerts</code> <code>Helper</code> class. Provides <code>Alert</code>s specifically related
 * to <code>Login</code>-related events. Uses information passed to the <code>Login</code> file to generate appropriate
 * <code>Alert</code>s for input validation and logical error checking.
 * */
public class LoginAlerts {

    /**
     * Logical error check method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Username</code>
     * on the <code>Login</code> scene. Displays in English.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noUserEN() {
        Alert noUser = new Alert(Alert.AlertType.ERROR);
        noUser.setTitle("No Username Provided");
        noUser.setHeaderText("Please Provide a Username");
        noUser.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noUser.close();
            }
        }));
    }

    /**
     * Logical error check method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Password</code>
     * on the <code>Login</code> scene. Displays in English.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noPassEN() {
        Alert noPass = new Alert(Alert.AlertType.ERROR);
        noPass.setTitle("No Password Provided");
        noPass.setHeaderText("Please Provide a Password");
        noPass.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noPass.close();
            }
        }));
    }

    /**
     * Input Validation error check method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Username</code>
     * and <code>Password</code> combination that matches a <code>Username</code> and <code>Password</code> combination in the
     * connected database. Displays in English.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void invalidCredEN() {
        Alert englishCredentialsAlert = new Alert(Alert.AlertType.WARNING);
        englishCredentialsAlert.setTitle("Invalid Credentials");
        englishCredentialsAlert.setHeaderText("The Username and/or Password You Entered is Incorrect");
        englishCredentialsAlert.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                englishCredentialsAlert.close();
            }
        }));
    }

    /**
     * Logical error check method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Username</code>
     * on the <code>Login</code> scene. Displays in French.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noUserFR() {
        ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());
        Alert noUserFR = new Alert(Alert.AlertType.ERROR);
        noUserFR.setTitle(rb.getString("noUsername"));
        noUserFR.setHeaderText(rb.getString("provideUsername"));
        noUserFR.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noUserFR.close();
            }
        }));
    }

    /**
     * Logical error check method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Password</code>
     * on the <code>Login</code> scene. Displays in French.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void noPassFR() {
        ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());
        Alert noPassFR = new Alert(Alert.AlertType.ERROR);
        noPassFR.setTitle(rb.getString("noPassword"));
        noPassFR.setHeaderText(rb.getString("providePassword"));
        noPassFR.showAndWait().ifPresent((ok -> {
            if (ok == ButtonType.OK) {
                noPassFR.close();
            }
        }));
    }

    /**
     * Input Validation error check method displays an <code>Alert</code> if the <code>User</code> did not provide a <code>Username</code>
     * and <code>Password</code> combination that matches a <code>Username</code> and <code>Password</code> combination in the
     * connected database. Displays in French.
     * <p>/-----------------------------------------------------------/</p>
     * <p><b>LAMBDA EXPRESSION DOCUMENTATION...</b></p>
     * <code>Lambda</code> is used to show an <code>Alert</code> with an "OK" button. Displays the <code>Alert</code> until the <code>User</code> clicks
     * the "OK" button, at which point the <code>lambda</code> expression closes the <code>Alert</code>.
     * */
    public static void invalidCredFR() {
        ResourceBundle rb = ResourceBundle.getBundle("Helper/Nat", Locale.getDefault());
        ButtonType ok = new ButtonType(rb.getString("ok"), ButtonBar.ButtonData.OK_DONE);
        Alert incorrectCredentialsAlert = new Alert(Alert.AlertType.WARNING, rb.getString("credentialerror"), ok);
        incorrectCredentialsAlert.setTitle(rb.getString("invalidcredentials"));
        incorrectCredentialsAlert.setHeaderText(rb.getString("invalidcredheadertext"));
        Optional<ButtonType> credAlert = incorrectCredentialsAlert.showAndWait();

        if (credAlert.isPresent() && credAlert.get() == ButtonType.OK) {
            incorrectCredentialsAlert.close();
        }
    }
}
