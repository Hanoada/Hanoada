package Helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Establishes the <code>JDBC</code> <code>Helper</code> class. Provides database access for the <code>User</code> through
 * a Java <code>MySQL Connector Driver</code> that is directed to a locally-hosted database.
 * */
public abstract class JDBC {
    private static final String protocol = "jdbc";
    private static final String vendor = ":mysql:";
    private static final String location = "//localhost/";
    private static final String databaseName = "client_schedule";
    private static final String jdbcUrl = protocol + vendor + location + databaseName + "?connectionTimeZone = SERVER"; // LOCAL
    private static final String driver = "com.mysql.cj.jdbc.Driver"; // Driver reference
    private static final String userName = "sqlUser"; // Username
    private static final String password = "Passw0rd!"; // Password
    public static Connection connection;  // Connection Interface

    /**
     * Connects the application with a locally-hosted MySQL server using the <code>MySQL Connector Driver</code>. Called after
     * successful program <code>Login</code> to open a connection to the locally-hosted database, which will be closed on program exit.
     * */
    public static void openConnection()
    {
        try {
            Class.forName(driver); // Locate Driver
            connection = DriverManager.getConnection(jdbcUrl, userName, password); // Reference Connection object
            System.out.println("Connection successful!");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            System.out.println("Error:" + e.getMessage());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Connects the application with a locally-hosted MySQL server using the <code>MySQL Connector Driver</code>. Used
     * as an easy way for the program's various methods to establish a database connection. Returns the <code>connection</code>
     * established in the <code>openConnection()</code> method in the <code>JDBC</code> file.
     * */
    public static Connection getConnection() {
        return connection;
    }

    /**
     * Closes the connection to the locally-hosted MySQL server using the <code>MySQL Connector Driver</code>. Called at
     * program exit to ensure the connection is closed.
     * */
    public static void closeConnection() {
        try {
            connection.close();
            System.out.println("Connection closed!");
        }
        catch(Exception e)
        {
            System.out.println("Error:" + e.getMessage());
        }
    }
}
