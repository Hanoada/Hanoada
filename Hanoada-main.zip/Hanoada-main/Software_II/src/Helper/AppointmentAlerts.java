package Helper;

import DBAccess.DBAppointments;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.time.*;
import java.util.Optional;

/**
 * Establishes the <code>AppointmentAlerts</code> <code>Helper</code> class. Provides <code>Alert</code>s specifically related
 * to <code>Appointment</code>s. Uses a combination of <code>LocalDateTime</code>, <code>LocalDate</code>, <code>LocalTime</code>,
 * <code>ZonedDateTime</code>, and <code>ZoneID</code> objects as well as information passed to the <code>AppointmentAlerts</code>
 * file to generate appropriate <code>Alert</code>s for input validation and logical error checking.
 * */
public class AppointmentAlerts {
    public static LocalTime businessOpen = LocalTime.of(8, 0);
    public static LocalTime businessClosed = LocalTime.of(22, 0);
    public static ZoneId estZDT = ZoneId.of("US/Eastern");
    public static ZonedDateTime bizOpen = ZonedDateTime.of(LocalDate.of(2022, 9, 1), businessOpen, estZDT);
    public static ZonedDateTime bizClosed = ZonedDateTime.of(LocalDate.of(2022, 9, 1), businessClosed, estZDT);
    public static LocalTime closedTime = bizClosed.toLocalTime();

    /**
     * Used to provide input validation and logical error checking <code>Alert</code>s specifically related to <code>Appointment</code>s.
     * Returns a boolean value depending on whether the <code>Appointment</code> passes all input validation and logical error checking.
     * Produces appropriate <code>Alert</code>s when the <code>Appointment</code> fails input validation and logical error checks.
     * @param customerID Passed to the method from the <code>AddAppointment</code> or <code>UpdateAppointment</code> scene,
     *                   used to specify the <code>Appointment</code> <code>Customer_ID</code> to be validated.
     * @param title Passed to the method from the <code>AddAppointment</code> or <code>UpdateAppointment</code> scene,
     *              used to specify the <code>Appointment</code> <code>Title</code> to be validated.
     * @param description Passed to the method from the <code>AddAppointment</code> or <code>UpdateAppointment</code> scene,
     *                    used to specify the <code>Appointment</code> <code>Description</code> to be validated.
     * @param location Passed to the method from the <code>AddAppointment</code> or <code>UpdateAppointment</code> scene,
     *                 used to specify the <code>Appointment</code> <code>Location</code> to be validated.
     * @param start Passed to the method from the <code>AddAppointment</code> or <code>UpdateAppointment</code> scene,
     *              used to specify the <code>Appointment</code> <code>Start Date / Time</code> to be validated.
     * @param end Passed to the method from the <code>AddAppointment</code> or <code>UpdateAppointment</code> scene,
     *            used to specify the <code>Appointment</code> <code>End Date / Time</code> to be validated.
     * @param type Passed to the method from the <code>AddAppointment</code> or <code>UpdateAppointment</code> scene,
     *             used to specify the <code>Appointment</code> <code>Type</code> to be validated.
     * @return boolean Used to determine if the <code>Appointment</code> was validated to be correctly formatted and no data
     * is missing. Returns <code>true</code> if the <code>Appointment</code> is validated.
     * */
    public static boolean validateAppointment(Integer customerID, String title, String description, String location, LocalDateTime start, LocalDateTime end, String type) {

        ZoneId systemZoneId = ZoneId.systemDefault();
        ZonedDateTime startZDT = ZonedDateTime.of(start, systemZoneId);
        ZonedDateTime endZDT = ZonedDateTime.of(end, systemZoneId);

        ZoneId convertedZone = ZoneId.of("US/Eastern");
        ZonedDateTime startESTZDT = startZDT.withZoneSameInstant(convertedZone);
        ZonedDateTime endESTZDT = endZDT.withZoneSameInstant(convertedZone);


        if (title.isEmpty()) {
            Alert emptyTitle = new Alert(Alert.AlertType.ERROR, "No TITLE Set");
            emptyTitle.setTitle("You did not provide a TITLE for your appointment.");
            emptyTitle.setHeaderText("Please set a TITLE for your appointment.");
            Optional<ButtonType> emptyTitleButton = emptyTitle.showAndWait();
            if (emptyTitleButton.isPresent() && emptyTitleButton.get() == ButtonType.OK) {
                emptyTitle.close();
                return false;
            }
        }
        else if (start.isBefore(LocalDateTime.now())) {
            Alert emptyDescription = new Alert(Alert.AlertType.ERROR, "START Time is Before Current Time");
            emptyDescription.setTitle("Your START Time is Before the Current Time.");
            emptyDescription.setHeaderText("Please provide a START time that is in the future.");
            Optional<ButtonType> emptyDesc = emptyDescription.showAndWait();
            if (emptyDesc.isPresent() && emptyDesc.get() == ButtonType.OK) {
                emptyDescription.close();
                return false;
            }
        }
        else if (end.isBefore(LocalDateTime.now())) {
            Alert emptyDescription = new Alert(Alert.AlertType.ERROR, "END Time is Before Current Time");
            emptyDescription.setTitle("Your END Time is Before the Current Time.");
            emptyDescription.setHeaderText("Please provide a END time that is in the future.");
            Optional<ButtonType> emptyDesc = emptyDescription.showAndWait();
            if (emptyDesc.isPresent() && emptyDesc.get() == ButtonType.OK) {
                emptyDescription.close();
                return false;
            }
        }
        else if (description.isEmpty()) {
            Alert emptyDescription = new Alert(Alert.AlertType.ERROR, "No DESCRIPTION");
            emptyDescription.setTitle("You did not provide a DESCRIPTION for your appointment.");
            emptyDescription.setHeaderText("Please provide a DESCRIPTION for your appointment.");
            Optional<ButtonType> emptyDesc = emptyDescription.showAndWait();
            if (emptyDesc.isPresent() && emptyDesc.get() == ButtonType.OK) {
                emptyDescription.close();
                return false;
            }
        } else if (location.isEmpty()) {
            Alert emptyLocation = new Alert(Alert.AlertType.ERROR, "No LOCATION");
            emptyLocation.setTitle("You did not provide a LOCATION for your appointment.");
            emptyLocation.setHeaderText("Please provide a LOCATION for your appointment.");
            Optional<ButtonType> emptyLoc = emptyLocation.showAndWait();
            if (emptyLoc.isPresent() && emptyLoc.get() == ButtonType.OK) {
                emptyLocation.close();
                return false;
            }
        } else if (type.isEmpty()) {
            Alert emptyType = new Alert(Alert.AlertType.ERROR, "No TYPE Selected");
            emptyType.setTitle("You did select a TYPE for your appointment.");
            emptyType.setHeaderText("Please select a TYPE for your appointment.");
            Optional<ButtonType> noType = emptyType.showAndWait();
            if (noType.isPresent() && noType.get() == ButtonType.OK) {
                emptyType.close();
                return false;
            }
        } else if (startESTZDT.toLocalTime().isBefore(bizOpen.toLocalTime())) {
            Alert startBeforeBizOpen = new Alert(Alert.AlertType.ERROR, "START Time is Before Business Hours");
            startBeforeBizOpen.setTitle("Your START Time is set BEFORE business hours.");
            startBeforeBizOpen.setHeaderText("Please provide a START Time that is within Business Hours (8:00 a.m. to 10:00 p.m. EST).");
            Optional<ButtonType> startBeforeOpen = startBeforeBizOpen.showAndWait();
            if (startBeforeOpen.isPresent() && startBeforeOpen.get() == ButtonType.OK) {
                startBeforeBizOpen.close();
                return false;
            }
        } else if (endESTZDT.isAfter(ZonedDateTime.of(start.toLocalDate(), closedTime, convertedZone))) {
            Alert endAfterBizClosed = new Alert(Alert.AlertType.ERROR, "END Time is After Business Hours");
            endAfterBizClosed.setTitle("Your END Time is set AFTER business hours.");
            endAfterBizClosed.setHeaderText("Please provide an END Time that is within Business Hours (8:00 a.m. to 10:00 p.m. EST).");
            Optional<ButtonType> endAfterClosed = endAfterBizClosed.showAndWait();
            if (endAfterClosed.isPresent() && endAfterClosed.get() == ButtonType.OK) {
                endAfterBizClosed.close();
                return false;
            }
        } else if (start.isAfter(end)) {
            Alert startAfterEnd = new Alert(Alert.AlertType.ERROR, "START Date / Time AFTER END Date / Time");
            startAfterEnd.setTitle("Your START Date / Time is AFTER your END Date / Time.");
            startAfterEnd.setHeaderText("Please provide a START Date / Time that is BEFORE your END Date / Time \nOR an END Date / Time that is AFTER your START Date / Time.");
            Optional<ButtonType> startAfter = startAfterEnd.showAndWait();
            if (startAfter.isPresent() && startAfter.get() == ButtonType.OK) {
                startAfterEnd.close();
                return false;
            }
        } else return !checkOverlaps(customerID, start, end);
        return false;
    }

    /**
     * Uses the <code>Customer_ID</code>, <code>Start Date / Time</code>, and <code>End Date / Time</code> of a given <code>Appointment</code>
     * to ensure no other <code>Appointment</code>s associated with the <code>Customer_ID</code> overlap each other in any way.
     *
     * @param customerID The <code>Customer_ID</code> of the <code>Customer</code> object passed to the method. Used to check for
     *                   <code>Appointment</code> overlaps, ensuring the <code>Appointment</code> can't overlap itself in the
     *                   <code>UpdateAppointment</code> scene by checking the list of all <code>Appointments</code> against their
     *                   respective <code>Customer_ID</code>.
     * @param start The <code>Start Date / Time</code> for the proposed <code>Appointment</code> to check against all other <code>Appointment</code>s.
     * @param end The <code>End Date / Time</code> for the proposed <code>Appointment</code> to check against all other <code>Appointment</code>s.
     * @return boolean <code>True</code> if there is an overlapping <code>Appointment</code> and <code>false</code> if the proposed <code>Appointment</code>
     * doesn't overlap any other <code>Customer</code> <code>Appointment</code>s in the database and program.
     * */
    public static boolean checkOverlaps(int customerID, LocalDateTime start, LocalDateTime end) {

        for (int i = 0; i < DBAppointments.getAllAppointments().size(); ++i) {
            if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerID) && start.isAfter(DBAppointments.getAllAppointments().get(i).Start) && start.isBefore(DBAppointments.getAllAppointments().get(i).End)) {
                Alert startOverOtherAppt = new Alert(Alert.AlertType.ERROR, "START Time Overlap");
                startOverOtherAppt.setTitle("START Time Overlap");
                startOverOtherAppt.setHeaderText("START Overlaps the Following Appointment...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                        "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                        "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                        "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                Optional<ButtonType> startOver = startOverOtherAppt.showAndWait();
                if (startOver.isPresent() && startOver.get() == ButtonType.OK) {
                    startOverOtherAppt.close();
                    return true;
                }
            } else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerID) && end.isAfter(DBAppointments.getAllAppointments().get(i).Start) && end.isBefore(DBAppointments.getAllAppointments().get(i).End)) {
                Alert endOverOtherAppt = new Alert(Alert.AlertType.ERROR, "END Time Overlap");
                endOverOtherAppt.setTitle("END Time Overlap");
                endOverOtherAppt.setHeaderText("END Overlaps the Following Appointment...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                        "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                        "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                        "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                Optional<ButtonType> endOver = endOverOtherAppt.showAndWait();
                if (endOver.isPresent() && endOver.get() == ButtonType.OK) {
                    endOverOtherAppt.close();
                    return true;
                }
            } else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerID) && start.isBefore(DBAppointments.getAllAppointments().get(i).Start) && end.isAfter(DBAppointments.getAllAppointments().get(i).End)) {
                Alert completeOverlap = new Alert(Alert.AlertType.ERROR, "Complete Appointment Overlap");
                completeOverlap.setTitle("Complete Appointment Overlap");
                completeOverlap.setHeaderText("Proposed Appointment Completely Overlaps the Following Appointment...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                        "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                        "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                        "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                Optional<ButtonType> completeOver = completeOverlap.showAndWait();
                if (completeOver.isPresent() && completeOver.get() == ButtonType.OK) {
                    completeOverlap.close();
                    return true;
                }
            }
            else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerID) && start.isEqual(DBAppointments.getAllAppointments().get(i).Start)) {
                    Alert startStartOverlap = new Alert(Alert.AlertType.ERROR, "START Time is Equal to Another Appointment's START Time");
                    startStartOverlap.setTitle("START Time is Equal to Another Appointment's START Time");
                    startStartOverlap.setHeaderText("START Time is Equal to the Following Appointment's START Time...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                            "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                            "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                            "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                    Optional<ButtonType> startStartOver = startStartOverlap.showAndWait();
                    if (startStartOver.isPresent() && startStartOver.get() == ButtonType.OK) {
                        startStartOverlap.close();
                        return true;
                    }
                }
                else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerID) && end.isEqual(DBAppointments.getAllAppointments().get(i).End)) {
                    Alert endEndOver = new Alert(Alert.AlertType.ERROR, "END Time is Equal to Another Appointment's END Time");
                    endEndOver.setTitle("END Time is Equal to Another Appointment's END Time");
                    endEndOver.setHeaderText("END Time is Equal to the Following Appointment's END Time...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                            "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                            "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                            "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                    Optional<ButtonType> endEndOverBtn = endEndOver.showAndWait();
                    if (endEndOverBtn.isPresent() && endEndOverBtn.get() == ButtonType.OK) {
                        endEndOver.close();
                        return true;
                    }
                }
            else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerID) && start.isEqual(end)) {
                Alert endEndOver = new Alert(Alert.AlertType.ERROR, "START and END Times are the SAME");
                endEndOver.setTitle("START and END Times are the SAME.");
                endEndOver.setHeaderText("START and END Times are the SAME");
                Optional<ButtonType> endEndOverBtn = endEndOver.showAndWait();
                if (endEndOverBtn.isPresent() && endEndOverBtn.get() == ButtonType.OK) {
                    endEndOver.close();
                    return true;
                }
            }
            }
        return false;
    }

    /**
     * Used to provide input validation and logical error checking <code>Alert</code>s specifically related to <code>Appointment</code>s.
     * Returns a boolean value depending on whether the <code>Appointment</code> passes all input validation and logical error checking.
     * Produces appropriate <code>Alert</code>s when the <code>Appointment</code> fails input validation and logical error checks.
     * @param Appointment_ID Passed to the method from the <code>UpdateAppointment</code> scene, used to specify the
     *                       <code>Appointment_ID</code> to be validated.
     * @param customerId Passed to the method from the <code>UpdateAppointment</code> scene, used to specify the
     *                   <code>Appointment</code> <code>Customer_ID</code> to be validated.
     * @param title Passed to the method from the <code>UpdateAppointment</code> scene, used to specify the
     *              <code>Appointment</code> <code>Title</code> to be validated.
     * @param description Passed to the method from the <code>UpdateAppointment</code> scene, used to specify the
     *                    <code>Appointment</code> <code>Description</code> to be validated.
     * @param location Passed to the method from the <code>UpdateAppointment</code> scene, used to specify the
     *                 <code>Appointment</code> <code>Location</code> to be validated.
     * @param start Passed to the method from the <code>UpdateAppointment</code> scene, used to specify the
     *              <code>Appointment</code> <code>Start Date / Time</code> to be validated.
     * @param end Passed to the method from the <code>UpdateAppointment</code> scene, used to specify the
     *            <code>Appointment</code> <code>End Date / Time</code> to be validated.
     * @param type Passed to the method from the <code>UpdateAppointment</code> scene, used to specify the
     *             <code>Appointment</code> <code>Type</code> to be validated.
     * @return boolean <code>True</code> if the proposed updated <code>Appointment</code> passes all input and logical error
     * checks.
     * */
    public static boolean validateUpdateAppointment(int Appointment_ID, Integer customerId, String title, String description,
                                                    String location, LocalDateTime start, LocalDateTime end, String type) {

        ZoneId systemZoneId = ZoneId.systemDefault();
        ZonedDateTime startZDT = ZonedDateTime.of(start, systemZoneId);
        ZonedDateTime endZDT = ZonedDateTime.of(end, systemZoneId);

        ZoneId convertedZone = ZoneId.of("US/Eastern");
        ZonedDateTime startESTZDT = startZDT.withZoneSameInstant(convertedZone);
        ZonedDateTime endESTZDT = endZDT.withZoneSameInstant(convertedZone);


        if (title.isEmpty()) {
            Alert emptyTitle = new Alert(Alert.AlertType.ERROR, "No TITLE");
            emptyTitle.setTitle("You did not provide a TITLE for your appointment.");
            emptyTitle.setHeaderText("Please set a TITLE for your appointment.");
            Optional<ButtonType> emptyTitleButton = emptyTitle.showAndWait();
            if (emptyTitleButton.isPresent() && emptyTitleButton.get() == ButtonType.OK) {
                emptyTitle.close();
                return false;
            }
        } else if (description.isEmpty()) {
            Alert emptyDescription = new Alert(Alert.AlertType.ERROR, "No DESCRIPTION");
            emptyDescription.setTitle("You did not provide a DESCRIPTION for your appointment.");
            emptyDescription.setHeaderText("Please provide a DESCRIPTION for your appointment.");
            Optional<ButtonType> emptyDesc = emptyDescription.showAndWait();
            if (emptyDesc.isPresent() && emptyDesc.get() == ButtonType.OK) {
                emptyDescription.close();
                return false;
            }
        } else if (location.isEmpty()) {
            Alert emptyLocation = new Alert(Alert.AlertType.ERROR, "No LOCATION");
            emptyLocation.setTitle("You did not provide a LOCATION for your appointment.");
            emptyLocation.setHeaderText("Please provide a LOCATION for your appointment.");
            Optional<ButtonType> emptyLoc = emptyLocation.showAndWait();
            if (emptyLoc.isPresent() && emptyLoc.get() == ButtonType.OK) {
                emptyLocation.close();
                return false;
            }
        } else if (type.isEmpty()) {
            Alert emptyType = new Alert(Alert.AlertType.ERROR, "No TYPE Selected");
            emptyType.setTitle("You did not select a TYPE for your appointment.");
            emptyType.setHeaderText("Please select a TYPE for your appointment.");
            Optional<ButtonType> noType = emptyType.showAndWait();
            if (noType.isPresent() && noType.get() == ButtonType.OK) {
                emptyType.close();
                return false;
            }
        }
        else if (start.isBefore(LocalDateTime.now())) {
            Alert emptyDescription = new Alert(Alert.AlertType.ERROR, "START Time is BEFORE Current Time");
            emptyDescription.setTitle("Your START Time is in the past.");
            emptyDescription.setHeaderText("Please provide a START time that is in the future.");
            Optional<ButtonType> emptyDesc = emptyDescription.showAndWait();
            if (emptyDesc.isPresent() && emptyDesc.get() == ButtonType.OK) {
                emptyDescription.close();
                return false;
            }
        }
        else if (end.isBefore(LocalDateTime.now())) {
            Alert emptyDescription = new Alert(Alert.AlertType.ERROR, "END Time is BEFORE Current Time");
            emptyDescription.setTitle("Your END Time is in the past.");
            emptyDescription.setHeaderText("Please provide a END time that is in the future.");
            Optional<ButtonType> emptyDesc = emptyDescription.showAndWait();
            if (emptyDesc.isPresent() && emptyDesc.get() == ButtonType.OK) {
                emptyDescription.close();
                return false;
            }
        }
        else if (startESTZDT.toLocalTime().isBefore(bizOpen.toLocalTime())) {
            Alert startBeforeBizOpen = new Alert(Alert.AlertType.ERROR, "START Time is Before Business Hours");
            startBeforeBizOpen.setTitle("Your START Time is set before business hours.");
            startBeforeBizOpen.setHeaderText("Please provide a START Time that is within Business Hours (8:00 a.m. to 10:00 p.m. EST).");
            Optional<ButtonType> startBeforeOpen = startBeforeBizOpen.showAndWait();
            if (startBeforeOpen.isPresent() && startBeforeOpen.get() == ButtonType.OK) {
                startBeforeBizOpen.close();
                return false;
            }
        } else if (endESTZDT.isAfter(ZonedDateTime.of(start.toLocalDate(), closedTime, convertedZone))) {
            Alert endAfterBizClosed = new Alert(Alert.AlertType.ERROR, "END Time is After Business Hours");
            endAfterBizClosed.setTitle("Your END Time is set after business hours.");
            endAfterBizClosed.setHeaderText("Please provide an END Time that is within Business Hours (8:00 a.m. to 10:00 p.m. EST).");
            Optional<ButtonType> endAfterClosed = endAfterBizClosed.showAndWait();
            if (endAfterClosed.isPresent() && endAfterClosed.get() == ButtonType.OK) {
                endAfterBizClosed.close();
                return false;
            }
        } else if (start.isAfter(end)) {
            Alert startAfterEnd = new Alert(Alert.AlertType.ERROR, "Start Date / Time AFTER END Date / Time");
            startAfterEnd.setTitle("Your START Date / Time is AFTER your END Date / Time.");
            startAfterEnd.setHeaderText("Please provide a START Date / Time that is BEFORE your END Date / Time.");
            Optional<ButtonType> startAfter = startAfterEnd.showAndWait();
            if (startAfter.isPresent() && startAfter.get() == ButtonType.OK) {
                startAfterEnd.close();
                return false;
            }
        } else return !checkUpdateOverlaps(Appointment_ID, customerId, start, end);
        return false;
    }

    /**
     * Uses the <code>Appointment_ID</code>, <code>Customer_ID</code>, <code>Start Date / Time</code>, and <code>End Date / Time</code>
     * of a given <code>Appointment</code> to ensure no other <code>Appointment</code>s associated with the updated
     * <code>Appointment_ID</code> and <code>Customer_ID</code> combination overlap each other in any way.
     *
     * @param AppointmentId The <code>Appointment_ID</code> for the proposed updated <code>Appointment</code>. Used to reference the list of all <code>Appointment</code>s
     * @param customerId The <code>Customer_ID</code> for the proposed updated <code>Appointment</code>. Used to reference the list of all <code>Appointment</code>s
     * @param start The <code>Start Date / Time</code> for the proposed updated <code>Appointment</code>. Used to reference the list of all <code>Appointment</code>s
     * @param end The <code>End Date / Time</code> for the proposed updated <code>Appointment</code>. Used to reference the list of all <code>Appointment</code>s
     * @return boolean <code>True</code> if the proposed updated <code>Appointment</code> overlaps another <code>Appointment</code> for the same <code>Customer</code>.
     * */
    public static boolean checkUpdateOverlaps(int AppointmentId, Integer customerId, LocalDateTime start, LocalDateTime end) {

        for (int i = 0; i < DBAppointments.getAllAppointments().size(); ++i) {
            if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerId) && start.isAfter(DBAppointments.getAllAppointments().get(i).Start)
                    && start.isBefore(DBAppointments.getAllAppointments().get(i).End)
                    && DBAppointments.getAllAppointments().get(i).Appointment_ID != AppointmentId) {
                Alert startOverOtherAppt = new Alert(Alert.AlertType.ERROR, "START Time Overlap");
                startOverOtherAppt.setTitle("START Time Overlap");
                startOverOtherAppt.setHeaderText("START Overlaps the Following Appointment...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                        "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                        "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                        "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                Optional<ButtonType> startOver = startOverOtherAppt.showAndWait();
                if (startOver.isPresent() && startOver.get() == ButtonType.OK) {
                    startOverOtherAppt.close();
                    return true;
                }
            } else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerId) && end.isAfter(DBAppointments.getAllAppointments().get(i).Start)
                    && end.isBefore(DBAppointments.getAllAppointments().get(i).End)
                    && DBAppointments.getAllAppointments().get(i).Appointment_ID != AppointmentId) {
                Alert endOverOtherAppt = new Alert(Alert.AlertType.ERROR, "END Time Overlap");
                endOverOtherAppt.setTitle("END Time Overlap");
                endOverOtherAppt.setHeaderText("END Overlaps the Following Appointment...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                        "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                        "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                        "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                Optional<ButtonType> endOver = endOverOtherAppt.showAndWait();
                if (endOver.isPresent() && endOver.get() == ButtonType.OK) {
                    endOverOtherAppt.close();
                    return true;
                }
            } else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerId) && start.isBefore(DBAppointments.getAllAppointments().get(i).Start)
                    && end.isAfter(DBAppointments.getAllAppointments().get(i).End)
                    && DBAppointments.getAllAppointments().get(i).Appointment_ID != AppointmentId) {
                Alert completeOverlap = new Alert(Alert.AlertType.ERROR, "Complete Appointment Overlap");
                completeOverlap.setTitle("Complete Appointment Overlap");
                completeOverlap.setHeaderText("Proposed Appointment Completely Overlaps the Following Appointment...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                        "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                        "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                        "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                Optional<ButtonType> completeOver = completeOverlap.showAndWait();
                if (completeOver.isPresent() && completeOver.get() == ButtonType.OK) {
                    completeOverlap.close();
                    return true;
                }
            }
            else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerId) && start.isEqual(DBAppointments.getAllAppointments().get(i).Start)
                    && DBAppointments.getAllAppointments().get(i).Appointment_ID != AppointmentId) {
                Alert startStartOverlap = new Alert(Alert.AlertType.ERROR, "START Time is Equal to Another Appointment's START Time");
                startStartOverlap.setTitle("START Time is Equal to Another Appointment's START Time");
                startStartOverlap.setHeaderText("START Time is Equal to the Following Appointment's START Time...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                        "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                        "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                        "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                Optional<ButtonType> startStartOver = startStartOverlap.showAndWait();
                if (startStartOver.isPresent() && startStartOver.get() == ButtonType.OK) {
                    startStartOverlap.close();
                    return true;
                }
            }
            else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerId) && end.isEqual(DBAppointments.getAllAppointments().get(i).End)
                    && DBAppointments.getAllAppointments().get(i).Appointment_ID != AppointmentId) {
                Alert endEndOver = new Alert(Alert.AlertType.ERROR, "END Time is Equal to Another Appointment's END Time");
                endEndOver.setTitle("END Time is Equal to Another Appointment's END Time");
                endEndOver.setHeaderText("END Time is Equal to the Following Appointment's END Time...\n" + "Appointment ID: " + DBAppointments.getAllAppointments().get(i).Appointment_ID +
                        "\n" + "Appointment DATE: " + DBAppointments.getAllAppointments().get(i).Start.toLocalDate() +
                        "\n" + "Appointment START Time: " + DBAppointments.getAllAppointments().get(i).Start.toLocalTime() +
                        "\n" + "Appointment END Time: " + DBAppointments.getAllAppointments().get(i).End.toLocalTime());
                Optional<ButtonType> endEndOverBtn = endEndOver.showAndWait();
                if (endEndOverBtn.isPresent() && endEndOverBtn.get() == ButtonType.OK) {
                    endEndOver.close();
                    return true;
                }
            }
            else if ((DBAppointments.getAllAppointments().get(i).getCustomer_ID() == customerId) && start.isEqual(end)) {
                Alert endEndOver = new Alert(Alert.AlertType.ERROR, "START and END Times are the SAME");
                endEndOver.setTitle("START and END times are the SAME.");
                endEndOver.setHeaderText("Please choose a START time that is different from your END time.");
                Optional<ButtonType> endEndOverBtn = endEndOver.showAndWait();
                if (endEndOverBtn.isPresent() && endEndOverBtn.get() == ButtonType.OK) {
                    endEndOver.close();
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not set a <code>Start Date / Time</code>
     * for an <code>Appointment</code> they are attempting to add or update.
     * */
    public static void noStartDateTime() {
        Alert emptyTitle = new Alert(Alert.AlertType.ERROR, "No START Date / Time Set");
        emptyTitle.setTitle("You did not provide a START Date / Time for your appointment.");
        emptyTitle.setHeaderText("Please set a START Date / Time for your appointment.");
        Optional<ButtonType> deleted = emptyTitle.showAndWait();
        if (deleted.isPresent() && deleted.get() == ButtonType.OK) {
            emptyTitle.close();
        }
    }
    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not set an <code>End Date / Time</code>
     * for an <code>Appointment</code> they are attempting to add or update.
     * */
    public static void noEndDateTime() {
        Alert emptyTitle = new Alert(Alert.AlertType.ERROR, "No END Date / Time Set");
        emptyTitle.setTitle("You did not provide an END Date / Time for your appointment.");
        emptyTitle.setHeaderText("Please set an END Date / Time for your appointment.");
        Optional<ButtonType> deleted = emptyTitle.showAndWait();
        if (deleted.isPresent() && deleted.get() == ButtonType.OK) {
            emptyTitle.close();
        }
    }
    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not select a <code>Contact</code>
     * for an <code>Appointment</code> they are attempting to add or update.
     * */
    public static void noContactSelected() {
        Alert emptyTitle = new Alert(Alert.AlertType.ERROR, "No CONTACT");
        emptyTitle.setTitle("You did select a CONTACT for your appointment.");
        emptyTitle.setHeaderText("Please select a CONTACT for your appointment.");
        Optional<ButtonType> deleted = emptyTitle.showAndWait();
        if (deleted.isPresent() && deleted.get() == ButtonType.OK) {
            emptyTitle.close();
        }
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not select a <code>Customer_ID</code>
     * for an <code>Appointment</code> they are attempting to add or update.
     * */
    public static void noCustomerIdSelected() {
        Alert noCustomerID = new Alert(Alert.AlertType.ERROR, "No CUSTOMER ID");
        noCustomerID.setTitle("You did select a CUSTOMER ID for your appointment.");
        noCustomerID.setHeaderText("Please select a CUSTOMER ID for your appointment.");
        Optional<ButtonType> noCID = noCustomerID.showAndWait();
        if (noCID.isPresent() && noCID.get() == ButtonType.OK) {
            noCustomerID.close();
        }
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not select a <code>User_ID</code>
     * for an <code>Appointment</code> they are attempting to add or update.
     * */
    public static void noUserIdSelected() {
        Alert noUserID = new Alert(Alert.AlertType.ERROR, "No USER ID");
        noUserID.setTitle("You did select a USER ID for your appointment.");
        noUserID.setHeaderText("Please select a USER ID for your appointment.");
        Optional<ButtonType> noUID = noUserID.showAndWait();
        if (noUID.isPresent() && noUID.get() == ButtonType.OK) {
            noUserID.close();
        }
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not select a <code>Contact</code>
     * Name for an <code>Appointment</code> they are attempting to add or update.
     * */
    public static void noContactNameSelected() {
        Alert noContactNameSelected = new Alert(Alert.AlertType.ERROR, "No CONTACT Name Selected");
        noContactNameSelected.setTitle("You did not select a CONTACT Name for your appointment.");
        noContactNameSelected.setHeaderText("Please select a CONTACT Name for your appointment.");
        Optional<ButtonType> noContact = noContactNameSelected.showAndWait();
        if (noContact.isPresent() && noContact.get() == ButtonType.OK) {
            noContactNameSelected.close();
        }
    }

    /**
     * Input validation method displays an <code>Alert</code> if the <code>User</code> did not select a <code>Type</code>
     * for an <code>Appointment</code> they are attempting to add or update.
     * */
    public static void noTypeSelected() {
        Alert noTypeSelected = new Alert(Alert.AlertType.ERROR, "No TYPE Selected");
        noTypeSelected.setTitle("You did not select a TYPE for your appointment.");
        noTypeSelected.setHeaderText("Please select a TYPE for your appointment.");
        Optional<ButtonType> noType = noTypeSelected.showAndWait();
        if (noType.isPresent() && noType.get() == ButtonType.OK) {
            noTypeSelected.close();
        }
    }

    /**
     * Logical error check method displays an <code>Alert</code> if the <code>User</code> did not select an <code>Appointment</code>
     * from the <code>Appointments</code> scene TableView before clicking the "Update Appointment" button in the same scene.
     * */
    public static void noAppointmentSelected() {
        Alert noTypeSelected = new Alert(Alert.AlertType.WARNING, "Please select an appointment first.");
        noTypeSelected.setTitle("No Appointment Selected");
        noTypeSelected.setHeaderText("No Appointment Selected");
        Optional<ButtonType> noType = noTypeSelected.showAndWait();
        if (noType.isPresent() && noType.get() == ButtonType.OK) {
            noTypeSelected.close();
        }
    }
}
