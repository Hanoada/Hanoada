package Helper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.*;
import java.util.TimeZone;

/**
 * Establishes the <code>LocalTimePicker</code> <code>Helper</code> class. Generates <code>Appointment</code>
 * Times for ComboBoxes found in the <code>AddAppointment</code> and <code>UpdateAppointment</code> scenes in <code>LocalTime</code>.
 * */
public class LocalTimePicker {

    /**
     * Generates <code>Appointment</code> Times for ComboBoxes found in the <code>AddAppointment</code> and
     * <code>UpdateAppointment</code> scenes in <code>LocalTime</code>. Uses a combination of <code>LocalDate</code>s,
     * <code>LocalTime</code>s, <code>ZoneId</code>s, <code>ZonedDateTime</code>s, and <code>Instant</code>s to loop through
     * a <code>for loop</code> the correct number of times to populate the ComboBoxes with only enough <code>LocalTime</code>
     * 15-Minute intervals to span business hours (8:00am to 10:00pm EST). Always displays in <code>LocalTime</code> and
     * always shows appropriate hours between 8:00am and 10:00pm EST, translated to the system's <code>LocalTime</code>.
     * */
    public static ObservableList<LocalTime> generateTimeCombos () {
        ObservableList<LocalTime> TimeLoader = FXCollections.observableArrayList();
        LocalDate estDate = LocalDate.of(2022, 9, 1);
        LocalTime estTime = LocalTime.of(8, 0);
        ZoneId estZoneId = ZoneId.of("America/New_York");
        ZonedDateTime estZDT = ZonedDateTime.of(estDate, estTime, estZoneId);
        ZoneId localZoneId = ZoneId.of(TimeZone.getDefault().getID());

        Instant estToGMTInstant = estZDT.toInstant();
        ZonedDateTime gmtToLocalZDT = estToGMTInstant.atZone(localZoneId);

        TimeLoader.clear();
        for (int i = 0; i < 57; ++i) {
            TimeLoader.add(gmtToLocalZDT.toLocalTime());
            gmtToLocalZDT = gmtToLocalZDT.plusMinutes(15);
        }
        return TimeLoader;
    }

}
