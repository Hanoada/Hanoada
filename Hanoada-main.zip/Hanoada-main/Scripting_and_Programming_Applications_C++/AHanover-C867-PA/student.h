#pragma once
#include "degree.h"
#include <iostream>
using namespace std;

class Student{
private:
	string studentID;
	string fName;
	string lName;
	string emailAddress;
	int age;
	DegreeProgram program;
	int daysInCourse[3];

public:
	Student(string studentID, string fName, string lName, string emailAddress, int age, int daysInCourse[], DegreeProgram program);

	//Accessors
	string GetStudentID();
	string GetFirstName();
	string GetLastName();
	string GetEmailAddress();
	int GetAge();
	int* GetNumDaysToComplete();
	virtual DegreeProgram GetDegree();
	int AverageDaysInCourse();

	//Mutators
	void SetStudentID(string studentID);							
	void SetFirstName(string fName);
	void SetLastName(string lName);
	void SetEmailAddress(string emailAddress);
	void SetAge(int age);
	void SetNumDaysToComplete(int numDaysToComplete[]);
	virtual void SetDegree(DegreeProgram program);

	//Student print() function
	virtual void print();
};