#include "roster.h"
#include <iostream>
#include <string>
using namespace std;

	void Roster::parse(string row) {
		unsigned int rhs = row.find(",");
		string studentID = row.substr(0, rhs);

		unsigned int lhs = rhs + 1;
		rhs = row.find(",", lhs);
		string fName = row.substr(lhs, rhs - lhs);

		lhs = rhs + 1;
		rhs = row.find(",", lhs);
		string lName = row.substr(lhs, rhs - lhs);

		lhs = rhs + 1;
		rhs = row.find(",", lhs);
		string emailAddress = row.substr(lhs, rhs - lhs);

		lhs = rhs + 1;
		rhs = row.find(",", lhs);
		int age = stoi(row.substr(lhs, rhs - lhs));

		lhs = rhs + 1;
		rhs = row.find(",", lhs);
		int daysInCourse1 = stoi(row.substr(lhs, rhs - lhs));

		lhs = rhs + 1;
		rhs = row.find(",", lhs);
		int daysInCourse2 = stoi(row.substr(lhs, rhs - lhs));

		lhs = rhs + 1;
		rhs = row.find(",", lhs);
		int daysInCourse3 = stoi(row.substr(lhs, rhs - lhs));

		lhs = rhs + 1;
		rhs = row.find(",", lhs);
		string program = row.substr(lhs, rhs - lhs);

		DegreeProgram degreeProgram = DegreeProgram::NETWORK;
		if (program == "NETWORK") {
			degreeProgram = DegreeProgram::NETWORK;
		}
		else if (program == "SECURITY") {
			degreeProgram = DegreeProgram::SECURITY;
		}
		else {
			degreeProgram = DegreeProgram::SOFTWARE;
		}
		add(studentID, fName, lName, emailAddress, age, daysInCourse1, daysInCourse2, daysInCourse3, degreeProgram);
	}

	void Roster::add(string studentID, string firstName, string lastName, string emailAddress, int age,
		int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeprogram) {
		int DaysInCourse[3];
		DaysInCourse[0] = daysInCourse1;
		DaysInCourse[1] = daysInCourse2;
		DaysInCourse[2] = daysInCourse3;

		classRosterArray[index++] = new Student(studentID, firstName, lastName, emailAddress, age, DaysInCourse, degreeprogram);
	}

	void Roster::remove(string studentID) {
		bool isStudentID = false;

		for (int i = 0; i < sizeof(classRosterArray) / sizeof(classRosterArray[i]); i++) {
			if (classRosterArray[i] != nullptr && classRosterArray[i]->GetStudentID() == studentID) {
				cout << "Removing " << studentID << ":" << endl;
				cout << endl;
				classRosterArray[i] = nullptr;
				isStudentID = true;
				break;
			}
		}

		if (isStudentID == false) {
			cout << "Removing " << studentID << " again" << endl;
			cout << endl;
			cout << "The student with the ID: " << studentID << " was not found." << endl;
		}
	}

	void Roster::printAll() {
		for (int i = 0; i < Roster::index; i++) {
			if (classRosterArray[i] == nullptr) {
				continue;
			}
			classRosterArray[i]->print();
		}
		cout << endl;
	}

	void Roster::printInvalidEmails() {
		cout << "Displaying invalid emails: " << endl;
		cout << endl;
		for (int i = 0; i < index; ++i) {
			if (classRosterArray[i]->GetEmailAddress().find('@') == string::npos
				|| classRosterArray[i]->GetEmailAddress().find('.') == string::npos
				|| classRosterArray[i]->GetEmailAddress().find(' ') != string::npos) {
				cout << classRosterArray[i]->GetEmailAddress() << " - is invalid." << endl;
			}

		}
		cout << endl;
	}

	void Roster::printAverageDaysInCourse(string studentID) {
		for (int i = 0; i < 5; ++i) {
			if (classRosterArray[i]->GetStudentID() == studentID) {
				cout << "Student ID: ";
				cout << classRosterArray[i]->GetStudentID();
				cout << ", average days in course is: ";
				cout << classRosterArray[i]->AverageDaysInCourse();
				cout << endl;
			}
		}
	}

	void Roster::printByDegreeProgram(DegreeProgram degreeProgram) {
		cout << "Showing students in degree program: SOFTWARE" << endl;
		cout << endl;
		for (int i = 0; i < index; ++i) {
			if (classRosterArray[i]->GetDegree() == DegreeProgram::SOFTWARE) {
				classRosterArray[i]->print();
			}
		}
		cout << endl;
	}

	Roster::~Roster() {
		for (int i = 0; i < 5; ++i) {
			delete classRosterArray[i];
			classRosterArray[i] = nullptr;
		}
	}