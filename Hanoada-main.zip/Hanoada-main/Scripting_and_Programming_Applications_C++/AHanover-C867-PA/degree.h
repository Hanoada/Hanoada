#pragma once
#include <string>
using namespace std;

enum class DegreeProgram {SECURITY, NETWORK, SOFTWARE};
const string strDegree[] = { "SECURITY", "NETWORK", "SOFTWARE" };