#include "student.h"
#include <iostream>
#include <string>
using namespace std;

Student::Student(string StudentID, string FirstName, string LastName, string email, int Age, int daysInCourseArray[], DegreeProgram program) {  
	studentID = StudentID;
	fName = FirstName;
	lName = LastName;
	emailAddress = email;
	age = Age;
	this->program = program;  
	for (int i = 0; i < 3; ++i) {
		this->daysInCourse[i] = daysInCourseArray[i];
	}
}

//Accessors
string Student::GetStudentID() {
	return studentID;
}
string Student::GetFirstName() {
	return fName;
}
string Student::GetLastName() {
	return lName;
}
string Student::GetEmailAddress() {
	return emailAddress;
}
int Student::GetAge() {
	return age;
}
int* Student::GetNumDaysToComplete() {
	return daysInCourse;
}
DegreeProgram Student::GetDegree() {
	return program;
}

int Student::AverageDaysInCourse() {
	return (Student::GetNumDaysToComplete()[0] + Student::GetNumDaysToComplete()[1] + Student::GetNumDaysToComplete()[2]) / 3;
}

//Mutators
void Student::SetStudentID(string studentId) {
	this->studentID = studentId;
}
void Student::SetFirstName(string FirstName) {
	this->fName = FirstName;
}
void Student::SetLastName(string LastName) {
	this->lName = LastName;
}
void Student::SetEmailAddress(string EmailAddress) {
	this->emailAddress = EmailAddress;
}
void Student::SetAge(int Age) {
	this->age = Age;
}
void Student::SetNumDaysToComplete(int daysInCourse[]) {

	for (int i = 0; i < 3; ++i) {
		this->daysInCourse[i] = daysInCourse[i];
	}
}
void Student::SetDegree(DegreeProgram degree) {
	program = degree;
}

//Student print() function
void Student::print() {

	cout << GetStudentID() << "\t" << GetFirstName() << "\t" << GetLastName() << "\t" << GetAge() << "\t";
	cout << "{" << daysInCourse[0] << "," << daysInCourse[1] << "," << daysInCourse[2] << "}" << "\t";

	if (GetDegree() == DegreeProgram::NETWORK) {
		cout << "NETWORK" << endl;
	}
	else if (GetDegree() == DegreeProgram::SECURITY) {
		cout << "SECURITY" << endl;
	}
	else {
		cout << "SOFTWARE" << endl;
	}
}