package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Optional;


/**
 * @Inventory Class is used to store information on all <code>Part</code>s and <code>Product</code>s in the inventory system. Uses
 * multiple ObservableLists to contain, modify, and delete <code>Part</code> and <code>Product</code> data throughout the entire program. Used
 * in all scenes/stages of the program.
 */
public class Inventory {


    /**
     * The "allParts" ObservableList of type <code>Part</code> is used to track all <code>Part</code>s in the program.
     * Since this ObservableList is of type <code>Part</code>, it can be used to store both <code>InHouse</code> and
     * <code>Outsourced</code> <code>Part</code>s, which are subclasses of the superclass <code>Part</code>.
     */
    private static final ObservableList<Part> allParts = FXCollections.observableArrayList();


    /**
     * The "allProducts" ObservableList of type <code>Product</code> is used to track all <code>Product</code>s in the program.
     */
    private static final ObservableList<Product> allProducts = FXCollections.observableArrayList();

    private static int partTracker = 0;
    private static int productTracker = 0;


    /**
     * Adds a user-specified part to the "allParts" ObservableList found in the <code>Inventory</code> file.
     *
     * @param part The <code>Part</code> that will be added to the "allParts" ObservableList of <code>Part</code>s contained in the <code>Inventory</code> controller.
     */
    public static void addPart(Part part) {
        allParts.add(part);
    }


    /**
     * Adds a user-specified <code>Product</code> to the "allProducts" ObservableList found in the <code>Inventory</code> file.
     *
     * @param product The <code>Product</code> that will be added to the "allProducts" ObservableList of <code>Product</code>s contained in the <code>Inventory</code> controller.
     */
    public static void addProduct(Product product) {
        allProducts.add(product);
    }


    /**
     * Provides <code>Part</code> search functionality on the <code>MainScreen</code> scene by "partId".
     * The "lookupPart(partId:int):Part" method on the UML in the <code>Inventory</code> class. Gets an int from
     * <code>MainScreen</code> and compares it with the list of <code>Part</code>s in the allParts ObservableList
     * contained in the <code>Inventory</code> file. Cycles through the allParts ObservableList using an if statement
     * nested inside an enhanced for loop and returns a <code>Part</code> with matching "partId" if one exists.
     *
     * @param partId The int passed from the <code>MainScreen</code> scene to be used as search criteria for the method
     *               to look up <code>Part</code>s by "partId".
     * @return The <code>Part</code> in the allParts ObservableList that has a "partId" that matches the "partId" int
     * passed into this method.
     */
    public static Part lookupPart(int partId) {
        for (Part allPart : allParts) {
            if (allPart.getId() == partId) {
                return allPart;
            }
        }
        return null;
    }


    /**
     * Provides <code>Product</code> search functionality on the <code>MainScreen</code> scene by "productId".
     * The "lookupProduct(productId:int):Product" method on the UML in the <code>Inventory</code> class. Gets an int from
     * <code>MainScreen</code> and compares it with the list of <code>Product</code>s in the allProducts ObservableList
     * contained in the <code>Inventory</code> file. Cycles through the allProducts ObservableList using an if statement
     * nested inside an enhanced for loop and returns a <code>Product</code> with matching "productId" if one exists.
     *
     * @param productId The int passed from the <code>MainScreen</code> scene to be used as search criteria for the method
     *                  to look up <code>Product</code>s by "productId".
     * @return The <code>Product</code> in the allProducts ObservableList that has a "productId" that matches the "productId"
     * int passed into this method.
     */
    public static Product lookupProduct(int productId) {
        for (Product allProduct : allProducts) {
            if (allProduct.getId() == productId) return allProduct;
        }
        return null;
    }


    /**
     * Provides <code>Part</code> search functionality on the <code>MainScreen</code> scene by "partName".
     * The "lookupPart(partName:String):ObservableList:Part" method on the UML in the <code>Inventory</code> class.
     * Gets a String from <code>MainScreen</code> and compares it with the list of <code>Part</code>s in the allParts
     * ObservableList contained in the <code>Inventory</code> file. Cycles through the allParts ObservableList using an
     * if statement nested inside an enhanced for loop and returns a <code>Part</code> with matching "partName" if one exists.
     *
     * @param partName The String passed from the <code>MainScreen</code> scene to be used as search criteria for the method to
     *                 look up <code>Part</code>s by partName.
     * @return the filteredData ObservableList, which is a list containing the <code>Part</code>s in the allParts list that
     * contain at least one character that matches the "Name" parameter.
     */
    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> filteredData = FXCollections.observableArrayList();
        for (Part allPart : allParts) {
            if ((allPart.getName().toUpperCase().contains(partName.toUpperCase())) || (allPart.getName().toLowerCase().contains(partName.toLowerCase()))) {
                filteredData.add(allPart);
            }
        }
        return filteredData;
    }


    /**
     * Provides <code>Product</code> search functionality on the <code>MainScreen</code> scene by "productName".
     * The "lookupProduct(productName:String):ObservableList:Product" method on the UML in the <code>Inventory</code> class. Gets a
     * String from <code>MainScreen</code> and compares it with the list of <code>Product</code>s in the allProducts ObservableList
     * contained in the <code>Inventory</code> file. Cycles through the allProducts ObservableList using an if statement
     * nested inside an enhanced for loop and returns a <code>Product</code> with matching "productName" if one exists.
     *
     * @param productName The String passed from the <code>MainScreen</code> scene to be used as search criteria for the method
     *                    to look up <code>Product</code>s by "productName".
     * @return the filteredData ObservableList, which is a list containing the <code>Product</code>s in the allProducts list that
     * contain at least one character that matches the "Name" parameter.
     */
    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> filteredData = FXCollections.observableArrayList();
        for (Product allProduct : allProducts) {
            if ((allProduct.getName().toUpperCase().contains(productName.toUpperCase())) || (allProduct.getName().toLowerCase().contains(productName.toLowerCase()))) {
                filteredData.add(allProduct);
            }
        }
        return filteredData;
    }


    /**
     * The "updatePart" method in the UML Diagram. Updates a <code>Part</code> in the "allParts" ObservableList using the <code>Part</code>'s
     * index within the "allParts" ObservableList, which is stored in the <code>Inventory</code> file.
     *
     * @param Index   Used to identify the index of the <code>Part</code> to be updated.
     * @param newPart The updated <code>Part</code> that will be placed in the "allParts" ObservableList,
     *                replacing the original entry at the specified "Index"
     */
    public static void updatePart(int Index, Part newPart) {
        allParts.set(Index, newPart);
    }


    /**
     * The "updateProduct" method in the UML Diagram. Updates a <code>Product</code> in the "allProducts" ObservableList
     * using the <code>Product</code>'s index within the "allProducts" and "associatedParts" ObservableLists, which are
     * stored in the <code>Inventory</code> file.
     *
     * @param Index           Used to identify the index of the <code>Product</code> to be updated.
     * @param productToUpdate The updated <code>Product</code> that will be placed in the "allProducts" ObservableList
     *                        at the specified "Index", replacing the original entry at the specified "Index"
     */
    public static void updateProduct(int Index, Product productToUpdate) {
        allProducts.set(Index, productToUpdate);
    }


    /**
     * Provides the ability to delete a <code>Part</code> from user inventory. The "deletePart(selectedPart:Part):boolean"
     * method in the UML diagram. A <code>Part</code> is passed into the method from the <code>MainScreen</code> using the "delete"
     * button. The customer is then confronted with a <code>CONFIRMATION</code> dialog to confirm their choice to delete the <code>Part</code>.
     * If they confirm, the <code>Part</code> is run through a for loop and if statement to determine if the <code>Part</code> is
     * indeed in the "allParts" ObservableList, which generates the "mainPartTableView" TableView on the <code>MainScreen</code>> scene.
     * If the <code>Part</code> is in the "allParts" list, the <code>Part</code> is deleted and a boolean value of "true" is returned
     * to confirm the <code>Part</code>'s deletion from inventory.
     *
     * @param selectedPart The <code>Part</code> selected by the user for deletion from the <code>MainScreen</code> scene.
     * @return The boolean value of "true" if the <code>Part</code> was successfully deleted, or "false" if it was not
     * successfully deleted.
     */
    public static boolean deletePart(Part selectedPart) {
        Alert confirmDelete = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this Part?", ButtonType.YES, ButtonType.CANCEL);
        confirmDelete.setTitle("Are You Sure?");
        Optional<ButtonType> yes = confirmDelete.showAndWait();
        if (yes.isPresent() && yes.get() == ButtonType.YES) {
            for (int index = 0; index < Inventory.getAllParts().size(); index++) {
                if (Inventory.getAllParts().contains(selectedPart)) {
                    Inventory.getAllParts().remove(selectedPart);
                    return true;
                }
            }


        }
        return false;
    }


    /**
     * Provides the ability to delete a <code>Product</code> from user inventory. The "deleteProduct(selectedProduct:Product):boolean"
     * method in the UML diagram. A <code>Product</code> is passed into the method from the <code>MainScreen</code> using the "delete"
     * button. Then, the <code>Product</code> is run through a for loop and if statement to determine if the <code>Product</code> is
     * indeed in the "allProducts" ObservableList, which generates the "mainProductTableView" TableView on the <code>MainScreen</code>> scene.
     * If the <code>Product</code> is in the "allProducts" list, the <code>Product</code> is deleted and a boolean value of "true" is returned
     * to confirm the <code>Product</code>'s deletion from inventory.
     * <b>NOTE:</b> A dialog box notifies the user that they must first remove all associated <code>Part</code>s for the selected
     * <code>Product</code> on the <code>MainScreen</code> and does not allow <code>Product</code> deletion until all <code>Part</code>s
     * are removed from the selected <code>Product</code>.
     *
     * @param selectedProduct The <code>Product</code> selected by the user for deletion from the <code>MainScreen</code> scene.
     * @return The boolean value of "true" if the <code>Product</code> was successfully deleted, or "false" if it was not successfully deleted.
     */
    public static boolean deleteProduct(Product selectedProduct) {
        boolean prodNotNull = false;
        if (selectedProduct == null)
            return prodNotNull;
        else {
            allProducts.remove(selectedProduct);
        }
        return true;
    }


    /**
     * Gets an ObservableList of all <code>Part</code>s.
     *
     * @return the "allParts" ObservableList of <code>Part</code>s from the <code>Inventory</code> controller file.
     */
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }


    /**
     * Gets an ObservableList of all <code>Product</code>s.
     *
     * @return the "allProducts" ObservableList of <code>Product</code>s from the <code>Inventory</code> controller file.
     */
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }


    /**
     * Sets a unique "partId" for each newly-created <code>Part</code>. Used with the "partTracker" to assign a unique
     * "part ID" to each <code>Part</code> added to the "allParts" ObservableList. Allows auto-generation of "partId"s by
     * adding 1 to the "partTracker" each time a new <code>Part</code> is added.
     *
     * @return partTracker is used to assign a unique "part ID" to each Part that is added to the "allParts" ObservableList.
     */
    public static int getPartTracker() {
        partTracker++;
        return partTracker;
    }


    /**
     * Gets a unique "productId" for each newly-created <code>Product</code>. Used with the "productTracker" to assign a unique "product ID"
     * to each <code>Product</code> added to the "allProducts" ObservableList. Allows auto-generation of "productId"s by adding 1 to
     * the "productTracker" each time a new <code>Product</code> is added.
     *
     * @return productTracker Used to assign a unique "productId" to each <code>Product</code> that is added to the "allProducts" ObservableList.
     */
    public static int getProductTracker() {
        productTracker++;
        return productTracker;
    }


    /**
     * Provides input validation when a <code>Part</code> is added through the <code>AddPart</code> scene or modified through the
     * <code>ModifyParts</code> scene. Includes checks for inventory, min, and max values entered into the TextFields at the time of
     * <code>Part</code> creation or modification.
     * @param partToValidate The <code>Part</code> passed to the method for adding or modifying. Passed from the <code>AddPart</code> and
     *                       <code>ModifyParts</code> scenes respectively.
     * @return A <code>boolean</code> value of <code>true</code> if the provided <code>Part</code> passes the input validation checks.
     */
    public static boolean validatePart(Part partToValidate) {
        if (partToValidate.getStock() > partToValidate.getMax()) {
            Alert InvOverMax = new Alert(Alert.AlertType.WARNING, "Your Part's Inventory value cannot be greater than it's Max value.");
            InvOverMax.setTitle("Inventory > Max");
            InvOverMax.setHeaderText("Inventory is Greater Than Max");
            Optional<ButtonType> InvOver = InvOverMax.showAndWait();
            if (InvOver.isPresent() && InvOver.get() == ButtonType.OK) {
                InvOverMax.close();
                return false;
            }
        } else if (partToValidate.getMin() > partToValidate.getMax()) {
            Alert MinOverMax = new Alert(Alert.AlertType.WARNING, "Your Part's Min value cannot be greater than it's Max value.");
            MinOverMax.setTitle("Min > Max");
            MinOverMax.setHeaderText("Min is Greater Than Max");
            Optional<ButtonType> MinOver = MinOverMax.showAndWait();
            if (MinOver.isPresent() && MinOver.get() == ButtonType.OK) {
                MinOverMax.close();
                return false;
            }
        } else if (partToValidate.getMin() > partToValidate.getStock()) {
            Alert MinOverInv = new Alert(Alert.AlertType.WARNING, "Your Part's Min value cannot be greater than it's Inventory value.");
            MinOverInv.setTitle("Min > Stock");
            MinOverInv.setHeaderText("Min is Greater Than Inventory Level");
            Optional<ButtonType> MinOverStock = MinOverInv.showAndWait();
            if (MinOverStock.isPresent() && MinOverStock.get() == ButtonType.OK) {
                MinOverInv.close();
                return false;
            }
        }
        return true;
    }


    /**
     * Provides input validation when a <code>Product</code> is added through the <code>AddProduct</code> scene or modified through the
     * <code>ModifyProduct</code> scene. Includes checks for inventory, min, and max values entered into the TextFields at the time of
     * <code>Product</code> creation or modification.
     * @param prodToValidate The <code>Product</code> passed to the method for adding or modifying. Passed from the <code>AddProduct</code> and
     *                       <code>ModifyProduct</code> scenes respectively.
     * @return A <code>boolean</code> value of <code>true</code> if the provided <code>Product</code> passes the input validation checks.
     */
    public static boolean validateProduct(Product prodToValidate) {

        if(prodToValidate.getMin() > prodToValidate.getMax()) {
            Alert MinOverMax = new Alert(Alert.AlertType.WARNING, "Your Product's Min value cannot be greater than it's Max value.");
            MinOverMax.setTitle("Min > Max");
            MinOverMax.setHeaderText("Min is Greater Than Max");
            Optional<ButtonType> MinOver = MinOverMax.showAndWait();
            if (MinOver.isPresent() && MinOver.get() == ButtonType.OK) {
                MinOverMax.close();
                return false;
            }
        }
        else if (prodToValidate.getStock() > prodToValidate.getMax()) {
            Alert InvOverMax = new Alert(Alert.AlertType.WARNING, "Your Product's Inventory value cannot be greater than it's Max value.");
            InvOverMax.setTitle("Inventory > Max");
            InvOverMax.setHeaderText("Inventory is Greater Than Max");
            Optional<ButtonType> InvOver = InvOverMax.showAndWait();
            if (InvOver.isPresent() && InvOver.get() == ButtonType.OK) {
                InvOverMax.close();
                return false;
            }
        }
        else if(prodToValidate.getMin() > prodToValidate.getStock()) {
            Alert MinOverInv = new Alert(Alert.AlertType.WARNING, "Your Product's Inventory value cannot be smaller than it's Min value.");
            MinOverInv.setTitle("Inventory < Min");
            MinOverInv.setHeaderText("Inventory is Less Than Min");
            Optional<ButtonType> InvUnder = MinOverInv.showAndWait();
            if (InvUnder.isPresent() && InvUnder.get() == ButtonType.OK) {
                MinOverInv.close();
                return false;
            }
        }
        return true;
    }


    /**
     * Tests a provided <code>String</code> to determine if it represents an <code>int</code>. Returns a <code>boolean</code> depending
     * on the result. If the <code>String</code> represents an <code>int</code>, the value returned will be <code>true</code>. Used
     * for input validation.
     * @param stringToTest The <code>String</code> that is passed to the method when a user enters numbers into a <code>TextField</code>. Since
     *                     <code>TextField</code>s are <code>String</code> values, a <code>String</code> is passed to the method.
     * @return <code>boolean</code> value of <code>true</code> or <code>false</code>, depending on whether the <code>String</code> passed
     * to the method represents an <code>int</code> or not.
     */
    public static boolean isInt(String stringToTest){
        try {
            Integer.parseInt(stringToTest);
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }


    /**
     * Tests a provided <code>String</code> to determine if it represents a <code>Double</code>. Returns a <code>boolean</code> depending
     * on the result. If the <code>String</code> represents an <code>Double</code>, the value returned will be <code>true</code>. Used
     * for input validation.
     * @param stringToTest The <code>String</code> that is passed to the method when a user enters numbers into a <code>TextField</code>. Since
     *                     <code>TextField</code>s are <code>String</code> values, a <code>String</code> is passed to the method.
     * @return <code>boolean</code> value of <code>true</code> or <code>false</code>, depending on whether the <code>String</code> passed
     * to the method represents a <code>Double</code> or not.
     */
    public static boolean isDouble(String stringToTest){
        try {
            Double.parseDouble(stringToTest);
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }


    /**
     * Displays a <code>WARNING</code> dialog with a message that a Price entered was not in number format. Part of data
     * input validation for <code>Part</code>s and <code>Product</code>s.
     */
    public static void displayPriceNotDoubleError() {
        Alert PartPriceNotDouble = new Alert(Alert.AlertType.WARNING, "Your Price should be a number (#.## OR #).");
        PartPriceNotDouble.setTitle("Price Format");
        PartPriceNotDouble.setHeaderText("Wrong Price Format");
        Optional<ButtonType> partPriceError = PartPriceNotDouble.showAndWait();
        if (partPriceError.isPresent() && partPriceError.get() == ButtonType.OK) {
            PartPriceNotDouble.close();
        }
    }


    /**
     * Displays a <code>WARNING</code> dialog with a message that an Inventory (or Stock) level entered was not in whole number format. Part of data
     * input validation for <code>Part</code>s and <code>Product</code>s.
     */
    public static void displayStockNotIntError() {
        Alert PartStockNotInt = new Alert(Alert.AlertType.WARNING, "Your Inventory level should be a whole number.");
        PartStockNotInt.setTitle("Inventory Number Format");
        PartStockNotInt.setHeaderText("Inventory Number Formatting Error");
        Optional<ButtonType> InvNumType = PartStockNotInt.showAndWait();
        if (InvNumType.isPresent() && InvNumType.get() == ButtonType.OK) {
            PartStockNotInt.close();
        }
    }


    /**
     * Displays a <code>WARNING</code> dialog with a message that a "Min" value entered was not in whole number format. Part of data
     * input validation for <code>Part</code>s and <code>Product</code>s.
     */
    public static void displayMinNotIntError() {
        Alert PartMinNotInt = new Alert(Alert.AlertType.WARNING, "Min should be a whole number.");
        PartMinNotInt.setTitle("Min Number Format");
        PartMinNotInt.setHeaderText("Min Number Formatting Error");
        Optional<ButtonType> MinNotInt = PartMinNotInt.showAndWait();
        if (MinNotInt.isPresent() && MinNotInt.get() == ButtonType.OK) {
            PartMinNotInt.close();
        }
    }


    /**
     * Displays a <code>WARNING</code> dialog with a message that a "Max" value entered was not in whole number format. Part of data
     * input validation for <code>Part</code>s and <code>Product</code>s.
     */
    public static void displayMaxNotNumberError() {
        Alert PartMaxNotInt = new Alert(Alert.AlertType.WARNING, "Max should be a whole number.");
        PartMaxNotInt.setTitle("Max Number Format");
        PartMaxNotInt.setHeaderText("Max Number Formatting Error");
        Optional<ButtonType> MaxNotInt = PartMaxNotInt.showAndWait();
        if (MaxNotInt.isPresent() && MaxNotInt.get() == ButtonType.OK) {
            PartMaxNotInt.close();
        }
    }


    /**
     * Displays a <code>WARNING</code> dialog with a message that a "Machine ID" entered was not in <code>String</code> format. Part of data
     * input validation for <code>InHouse</code> <code>Part</code>s.
     */
    public static void displayMachIdNotIntError(){
        Alert MachIdNotText = new Alert(Alert.AlertType.WARNING, "Your Part's Machine ID must be a whole number.");
        MachIdNotText.setTitle("Invalid Machine ID");
        MachIdNotText.setHeaderText("Machine ID Must Be Whole Number");
        Optional<ButtonType> MachId = MachIdNotText.showAndWait();
        if (MachId.isPresent() && MachId.get() == ButtonType.OK) {
            MachIdNotText.close();
        }
    }


    /**
     * Displays a <code>WARNING</code> dialog with a message that a "Company Name" was not entered. Part of data
     * input validation for <code>OutSourced</code> <code>Part</code>s.
     */
    public static void compNameNotEnteredError() {
        Alert CompNameEmpty = new Alert(Alert.AlertType.WARNING, "Your Outsourced Part must have a Company Name.");
        CompNameEmpty.setTitle("Empty Company Name");
        CompNameEmpty.setHeaderText("Outsourced Parts Require a Company Name");
        Optional<ButtonType> CompName = CompNameEmpty.showAndWait();
        if (CompName.isPresent() && CompName.get() == ButtonType.OK) {
            CompNameEmpty.close();
        }
    }


    /**
     * Displays a <code>WARNING</code> dialog with a message that the user must fill in all TextFields when adding or
     * modifying <code>Part</code>s or <code>Product</code>s. Part of data input validation for <code>Part</code>s and <code>Product</code>s.
     */
    public static void displayEmptyNameError() {
        Alert NameEmpty = new Alert(Alert.AlertType.WARNING, "Please fill-in all fields to continue.");
        NameEmpty.setTitle("Empty Fields");
        NameEmpty.setHeaderText("Empty Fields");
        Optional<ButtonType> nameMissing = NameEmpty.showAndWait();
        if (nameMissing.isPresent() && nameMissing.get() == ButtonType.OK) {
            NameEmpty.close();
        }
    }
}
