package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 * @Product Class is used to create <code>Product</code> objects. <code>Product</code> objects can have <code>Part</code>
 * objects associated with them individually or no <code>Parts</code> associated with them.
 */
public class Product {
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;


    /**
     * The "associatedParts" ObservableList of type <code>Part</code> is used to track <code>Part</code>s associated with any
     * given <code>Product</code> in the program. Since this ObservableList is of type <code>Part</code>, it can be used
     * to store both <code>InHouse</code> and <code>Outsourced</code> <code>Part</code>s, which are subclasses of the
     * superclass <code>Part</code>.
     */
    private final ObservableList<Part> associatedParts = FXCollections.observableArrayList();


    /**
     * @Product Constructor is used to create <code>Product</code>s. <code>Product</code>s each have a unique "productId",
     * which is automatically-generated using the "productTracker" in the <code>Inventory</code> file.
     * @param id the <code>Product</code> "productId". Automatically-generated and used in the program to search for, find, and modify <code>Product</code>s.
     * @param name the <code>Product</code> "name". User-generated and used in the program to search for, find, and modify <code>Product</code>s.
     *             Can be updated in the <code>ModifyProducts</code> scene.
     * @param price the <code>Product</code> "price". User-generated for all <code>Product</code>s. Can be updated in the <code>ModifyProducts</code> scene.
     * @param stock the <code>Product</code> "stock" parameter, representing the inventory level for a given <code>Product</code>. User-generated for all <code>Product</code>s.
     *              Can be updated in the <code>ModifyProducts</code> scene.
     * @param min the <code>Product</code> "min" parameter, representing the minimum inventory level for a given <code>Product</code>. User-generated for all <code>Product</code>s.
     *            Can be updated in the <code>ModifyProducts</code> scene.
     * @param max the <code>Product</code> "max" parameter, representing the maximum inventory level for a given <code>Product</code>. User-generated for all <code>Product</code>s.
     *            Can be updated in the <code>ModifyProducts</code> scene.
     */
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }


    /**
     * Sets the "productId" for a selected <code>Product</code>.
     * @param id This is the "productId" that will be assigned to the selected <code>Product</code>.
     */
    public void setId(int id) {
        this.id = id;
    }


    /**
     * Sets the "name" for a selected <code>Product</code>.
     * @param name This is the "name" for a selected <code>Product</code>.
     */
    public void setName(String name) {
        this.name = name;
    }


    /**
     * Sets the "price" for a selected <code>Product</code>.
     * @param price This is the "price" for a selected <code>Product</code>.
     */
    public void setPrice(double price) {
        this.price = price;
    }


    /**
     * Sets the "stock" for a selected <code>Product</code>.
     * @param stock This is the "stock" or "inventory level" for a selected <code>Product</code>.
     */
    public void setStock(int stock) {
        this.stock = stock;
    }


    /**
     * Sets the "min" value for a selected <code>Product</code>.
     * @param min This is the "min" value or "minimum inventory level" value for a <code>Product</code>.
     */
    public void setMin(int min) {
        this.min = min;
    }


    /**
     * Sets the "max" value for a selected <code>Product</code>.
     * @param max This is the "max" value or "maximum inventory level" value for a <code>Product</code>.
     */
    public void setMax(int max) {
        this.max = max;
    }


    /**
     * Gets the "productId" for a selected <code>Product</code>.
     * @return the "productId" for a selected <code>Product</code>.
     */
    public int getId() {
        return id;
    }


    /**
     * Gets the "name" for a selected <code>Product</code>.
     * @return the "name" for a selected <code>Product</code>.
     */
    public String getName() {
        return name;
    }


    /**
     * Gets the "price" for a selected <code>Product</code>.
     * @return the "price" for a selected <code>Product</code>.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Gets the "stock" for a selected <code>Product</code>.
     * @return the "stock" or "inventory level" for a selected <code>Product</code>.
     */
    public int getStock() {
        return stock;
    }


    /**
     * Gets the "min" value for a selected <code>Product</code>.
     * @return the "min" value or "minimum inventory level" value for a <code>Product</code>.
     */
    public int getMin() {
        return min;
    }


    /**
     * Gets the "max" value for a selected <code>Product</code>.
     * @return the "max" value or "maximum inventory level" value for a <code>Product</code>.
     */
    public int getMax() {
        return max;
    }


    /**
     * Adds a <code>Part</code> to a <code>Product</code>'s "associatedParts" ObservableList.
     * @param part This is the <code>Part</code> that should be added to the "associatedParts" ObservableList for the selected <code>Product</code>.
     */
    public void addAssociatedPart(Part part) {
        associatedParts.add(part);
    }


    /**
     * Removes <b></b> a <code>Part</code> from a <code>Product</code>'s "associatedParts" ObservableList.
     * @param selectedAssociatedPart This is the <code>Part</code> that should be removed from the "associatedParts"
     *                               ObservableList for the selected <code>Product</code>.
     */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart) {
        if (!((selectedAssociatedPart) == null)) {
            associatedParts.remove(selectedAssociatedPart);
            return true;
        } else return false;
    }


    /**
     * Gets a list of <code>Part</code>s that are associated to a user-selected <code>Product</code>.
     * @return associatedParts The ObservableList of associated <code>Part</code>s for the given user-selected <code>Product</code>.
     */
    public ObservableList<Part> getAllAssociatedParts() {
        return associatedParts;
    }

}
