package model;


/**
 * @InHouse Class extends the <code>Part</code> abstract class. Used to create <code>InHouse</code> <code>Part</code>s that
 * have a "machineId" parameter associated with their constructor. The "machineId" parameter is unique to the <code>InHouse</code> <code>Part</code> subclass.
 */
public class InHouse extends Part{
    private int machineId;


    /**
     * @InHouse constructor is used to create <code>InHouse</code> <code>Parts</code>, which are a subclass of the <code>Part</code> superclass. <code>InHouse</code>
     * <code>Part</code>s have a unique field, titled "machineId", which represents the machine ID that a <code>Part</code> was created on/with.
     * @param id the <code>InHouse</code> <code>Part</code> "partId". Automatically-generated and used in the program to search for, find, and modify <code>Part</code>s.
     * @param name the <code>InHouse</code> <code>Part</code> "name". User-generated and used in the program to search for, find, and modify <code>Part</code>s.
     *             Can be updated in the <code>ModifyParts</code> scene.
     * @param price the <code>InHouse</code> <code>Part</code> "price". User-generated for all <code>InHouse</code> <code>Part</code>s.
     *              Can be updated in the <code>ModifyParts</code> scene.
     * @param stock the <code>InHouse</code> <code>Part</code> "stock" parameter, representing the inventory level for a given <code>Part</code>.
     *              User-generated for all <code>Part</code>s. Can be updated in the <code>ModifyParts</code> scene.
     * @param min the <code>InHouse</code> <code>Part</code> "min" parameter, representing the minimum inventory level for a given <code>Part</code>.
     *            User-generated for all <code>Part</code>s. Can be updated in the <code>ModifyParts</code> scene.
     * @param max the <code>InHouse</code><code>Part</code> "max" parameter, representing the maximum inventory level for a given <code>Part</code>.
     *            User-generated for all <code>Part</code>s. Can be updated in the <code>ModifyParts</code> scene.
     * @param machineId the <code>InHouse</code> <code>Part</code> "machineId" parameter. Unique to <code>InHouse</code> <code>Part</code>s.
     *                  Represents the machine ID that an <code>InHouse</code> <code>Part</code> was created on/with.
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;
    }


    /**
     * Sets a <code>Part</code>'s "machineId". Used when constructing a new <code>InHouse</code> <code>Part</code> object
     * to set the "machineId" for the <code>InHouse</code> <code>Part</code>.
     * @param machineId The "machineId" for a newly-created <code>InHouse</code> <code>Part</code> object that will be
     *                  added to the "allParts" ObservableList contained in the <code>Inventory</code> controller.
     */
    public void setMachineId(int machineId) {

        this.machineId = machineId + 1;
    }


    /**
     * Gets an <code>InHouse</code> <code>Part</code>'s "machineId". Used when adding and updating <code>InHouse</code> <code>Part</code> objects.
     * @return the "machineId" used when adding or updating <code>InHouse</code> <code>Part</code> objects in the "allParts" ObservableList
     * contained in the <code>Inventory</code> controller.
     */
    public int getMachineId() {
        return machineId;
    }
}
