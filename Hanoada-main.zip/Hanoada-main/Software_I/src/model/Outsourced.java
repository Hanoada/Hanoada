package model;


/**
 * @Outsourced Class extends the <code>Part</code> abstract class. Used to create <code>Outsourced</code> <code>Part</code>s
 * that have a "companyName" parameter associated with their constructor. The "companyName" parameter is unique to the <code>Outsourced</code> <code>Part</code> subclass.
 */
public class Outsourced extends Part{
    private String companyName;


    /**
     * @Outsourced Constructor is used to create <code>Outsourced</code> <code>Part</code>s that have a "companyName" parameter
     * associated with their constructor. The "companyName" parameter is unique to the <code>Outsourced</code> <code>Part</code> subclass.
     * @param id the <code>Outsourced</code> <code>Part</code> "partId". Automatically-generated and used in the program to search for, find, and modify <code>Part</code>s.
     * @param name the <code>Outsourced</code> <code>Part</code> "name". User-generated and used in the program to search for, find, and modify <code>Part</code>s.
     *             Can be updated in the <code>ModifyParts</code> scene.
     * @param price the <code>Outsourced</code> <code>Part</code> "price". User-generated for all <code>Outsourced</code> <code>Part</code>s.
     *              Can be updated in the <code>ModifyParts</code> scene.
     * @param stock the <code>Outsourced</code> <code>Part</code> "stock" parameter, representing the inventory level for a given <code>Part</code>.
     *              User-generated for all <code>Part</code>s. Can be updated in the <code>ModifyParts</code> scene.
     * @param min the <code>Outsourced</code> <code>Part</code> "min" parameter, representing the minimum inventory level for a given <code>Part</code>.
     *            User-generated for all <code>Part</code>s. Can be updated in the <code>ModifyParts</code> scene.
     * @param max the <code>Outsourced</code><code>Part</code> "max" parameter, representing the maximum inventory level for a given <code>Part</code>.
     *            User-generated for all <code>Part</code>s. Can be updated in the <code>ModifyParts</code> scene.
     * @param companyName the <code>Outsourced</code> <code>Part</code> "companyName" parameter. Unique to <code>Outsourced</code> <code>Part</code>s.
     *                    Represents the company name that an <code>Outsourced</code> <code>Part</code> was created by.
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }


    /**
     * Sets an <code>Outsourced</code> <code>Part</code>'s "companyName". Used when constructing a new <code>Outsourced</code> <code>Part</code>
     * object to set the "companyName" for the <code>Outsourced</code> <code>Part</code>.
     * @param companyName The "companyName" for a newly-created <code>Outsourced</code> <code>Part</code> object that will be added to the
     *                    "allParts" ObservableList contained in the <code>Inventory</code> controller.
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }


    /**
     * Gets an <code>Outsourced</code> <code>Part</code>'s "companyName". Used when adding and updating <code>Outsourced</code> <code>Part</code> objects.
     * @return the "companyName" used when adding or updating <code>Outsourced</code> <code>Part</code> objects in the "allParts" ObservableList contained
     * in the <code>Inventory</code> controller.
     */
    public String getCompanyName() {
        return companyName;
    }
}
