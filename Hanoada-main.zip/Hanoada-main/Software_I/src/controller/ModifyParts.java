package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Part;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import static model.Inventory.isDouble;
import static model.Inventory.isInt;


/**
 * @ModifyParts Establishes the <code>ModifyParts</code> class. Gives the user the ability to modify existing <code>Part</code>s
 * in the "allParts" ObservableList contained in the <code>Inventory</code> file using the "Save" button found in the scene.
 */
public class ModifyParts implements Initializable {

    @FXML
    public RadioButton modifyPartRadioInHouse;
    @FXML
    public RadioButton modifyPartRadioOutsourced;

    @FXML
    public TextField partNameTxtField;
    @FXML
    public TextField partInvTxtField;
    @FXML
    public TextField partPriceTxtField;
    @FXML
    public TextField partMinTxtField;
    @FXML
    public TextField partMaxTxtField;
    @FXML
    private TextField modPartCompNameORMachIdTxt;
    @FXML
    private TextField partIdTxtField;
    @FXML
    public Label modProdMachineIdLbl;
    private static Part modifiablePart;
    public static InHouse inHousePart;
    public static Outsourced outsourcedPart;


    /**
     * Event Handler for the "Cancel" button on the <code>ModifyParts</code> scene. Allows a user to cancel the modifications made
     * to an existing <code>Part</code> object, displaying a <code>CONFIRMATION</code> dialog box to confirm the user's choice to
     * cancel modifications before returning the user to the <code>MainScreen</code> scene.
     * @param actionEvent Loads the "MainScreen.fxml" resource which redirects the user to the <code>MainScreen</code> stage.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    @FXML
    private void onActionModifyPartCancelBtn(ActionEvent actionEvent) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Your modifications will not be saved. Would you like to continue?");
        alert.setTitle("Please Confirm");

        Optional<ButtonType> result = alert.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
            Stage stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 1000, 450);
            stage.setScene(scene);
            stage.show();
        }
    }


    /**
     * Sets the <code>Part</code> object "modifiablePart" to the <code>Part</code> object that is passed as an argument. "modifiablePart" parameter
     * will be used with the "onActModPartSaveBtn()" method to modify/update data on a user-specified <code>Part</code> object.
     * @param partToModify Represents the <code>Part</code> object passed as an argument from the <code>MainScreen</code> scene when
     *                     a user selects a <code>Part</code> object from the "mainPartTableView" TableView and then clicks the "Modify"
     *                     button under the same TableView.
     */
    public static void setPartToModify(Part partToModify){
        modifiablePart = partToModify;
    }


    /**
     * Event Handler for the "modifyPartRadioInHouse" RadioButton. If the "modifiablePart" that was passed to this screen
     * using the "setModifiablePart()" method is of <code>Part</code> subclass type <code>InHouse</code>, this method changes the "modProdMachineIdLbl"
     * text to "Machine ID" when a user selects the "modifyPartRadioInHouse" RadioButton. Also casts the "modifiablePart"
     * <code>Part</code> item mentioned in the "setPartToModify()" method to an <code>InHouse</code> <code>Part</code> subclass object created in this file.
     * Then changes the text in the "addPartCompNameORMachIdTxt" TextField to the value of the "inHousePart" <code>InHouse</code> <code>Part</code> subclass
     * object's "machineId". Alternatively, if the object is not part of the <code>InHouse</code> <code>Part</code> subclass (meaning it is part of the
     * <code>Outsourced</code> <code>Part</code> subclass or the <code>Part</code> superclass), the "addPartCompNameORMachIdTxt" TexField is set to an empty String.
     */
    public void onActModPartInHouseRadio() {
        modProdMachineIdLbl.setText("Machine ID");
        if (modifiablePart.getClass().getName().equals("model.InHouse")){
            inHousePart = ((InHouse) modifiablePart);
            modPartCompNameORMachIdTxt.setText(String.valueOf(inHousePart.getMachineId()));
        }
        else {
            modPartCompNameORMachIdTxt.setText("");
        }
    }


    /**
     * Event Handler for the "modifyPartRadioOutsourced" RadioButton. If the "modifiablePart" that was passed to this screen
     * using the "setModifiablePart()" method is of <code>Part</code> subclass type <code>Outsourced</code>, this method changes the "modProdMachineIdLbl" text to "Company Name"
     * when a user selects the "modifyPartRadioOutsourced" RadioButton. Also casts the "modifiablePart" <code>Part</code> item mentioned in the
     * "setPartToModify()" method to an <code>Outsourced</code> <code>Part</code> subclass object created in this file. This method then changes the text
     * in the "addPartCompNameORMachIdTxt" TextField to the value of the "outsourcedPart" <code>Outsourced</code> <code>Part</code> subclass object's "companyName".
     * Alternatively, if the object is not part of the <code>Outsourced</code> <code>Part</code> subclass (meaning, it is part of the <code>InHouse</code> <code>Part</code> subclass or the
     * <code>Part</code> superclass), the "addPartCompNameORMachIdTxt" TexField is set to an empty String.
     */
    public void onActModPartOutsourcedRadio() {
        modProdMachineIdLbl.setText("Company Name");
        if (modifiablePart.getClass().getName().equals("model.Outsourced")){
            outsourcedPart = ((Outsourced) modifiablePart);
            modPartCompNameORMachIdTxt.setText(String.valueOf(outsourcedPart.getCompanyName()));
        }
        else {
            modPartCompNameORMachIdTxt.setText("");
        }
    }


    /**
     * Saves the updated <code>Part</code> data entered by the user, using the "Save" button on the <code>ModifyParts</code> scene. Uses the "getAllParts()"
     * method from the <code>Inventory</code> file to retrieve and modify <code>Part</code>s from the "allParts" ObservableList. Cycles through
     * the "allParts" list using the index of each <code>Part</code> to compare each <code>Part</code>'s "partId" with the "partIdTxtField" that
     * is automatically retrieved when a user selects a <code>Part</code> to modify on the <code>MainScreen</code> scene. If the <code>Part</code> from the
     * "allParts" ObservableList at index (index) has a matching "partId" with the data in the "partIdTxtField", a new
     * <code>InHouse</code> or <code>Outsourced</code> <code>Part</code> subclass type object is created, depending on which RadioButton is selected.
     * If the "modifyPartRadioInHouse" RadioButton is selected, a new <code>InHouse</code> <code>Part</code> subclass object will be created which
     * will replace the <code>Part</code> with matching "partId" from the "allParts" ObservableList in the <code>Inventory</code> file.
     * If the "modifyPartRadioInHouse" is not selected, the method will generate an <code>Outsourced</code> <code>Part</code> subclass object instead,
     * and use the same process to replace the existing <code>Part</code> with matching "partId" from the "allParts" ObservableList in the
     * <code>Inventory</code> file. Multiple data validation methods are used, including methods in the <code>ModifyParts</code> file and the
     * <code>Inventory</code> file.
     * @param actionEvent Loads the <code>MainScreen</code> resource which redirects the user to the <code>MainScreen</code> stage.
     *                    to the <code>MainScreen</code> scene after clicking the "Save" button.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActModPartSaveBtn(ActionEvent actionEvent) throws IOException {
        for (int i = 0; i < Inventory.getAllParts().size(); i++) {
            if (Inventory.getAllParts().get(i).getId() == Integer.parseInt(partIdTxtField.getText())) {
                if ((partNameTxtField.getText().isEmpty()) ||
                        partPriceTxtField.getText().isEmpty() ||
                        partInvTxtField.getText().isEmpty() ||
                        partMinTxtField.getText().isEmpty() ||
                        partMaxTxtField.getText().isEmpty()) {
                    Inventory.displayEmptyNameError();
                    return;
                }
                else if ((!(isDouble(partPriceTxtField.getText()))) && (!(isInt(partPriceTxtField.getText())))) {
                    Inventory.displayPriceNotDoubleError();
                    return;
                } else if (!(isInt(String.valueOf(partInvTxtField.getText())))) {
                    Inventory.displayStockNotIntError();
                    return;
                } else if (!(isInt(partMinTxtField.getText()))) {
                    Inventory.displayMinNotIntError();
                    return;
                } else if (!(isInt(partMaxTxtField.getText()))) {
                    Inventory.displayMaxNotNumberError();
                    return;
                } else {
                    if (modifyPartRadioInHouse.isSelected()) {
                        if (!(isInt(modPartCompNameORMachIdTxt.getText()))) {
                            Inventory.displayMachIdNotIntError();
                            return;
                        } else {
                            InHouse modInHouse = new InHouse((Integer.parseInt(partIdTxtField.getText())),
                                    (partNameTxtField.getText()),
                                    (Double.parseDouble(partPriceTxtField.getText())),
                                    (Integer.parseInt(partInvTxtField.getText())),
                                    (Integer.parseInt(String.valueOf(partMinTxtField.getText()))),
                                    (Integer.parseInt(String.valueOf(partMaxTxtField.getText()))),
                                    (Integer.parseInt(modPartCompNameORMachIdTxt.getText())));
                            if (Inventory.validatePart(modInHouse)) {
                                Inventory.updatePart(i, modInHouse);
                            }
                            else {
                                return;
                            }
                        }
                    } else {
                        if ((!(isDouble(partPriceTxtField.getText()))) && (!(isInt(partPriceTxtField.getText())))) {
                            Inventory.displayPriceNotDoubleError();
                            return;
                        } else if (!(isInt(String.valueOf(partInvTxtField.getText())))) {
                            Inventory.displayStockNotIntError();
                            return;
                        } else if (!(isInt(partMinTxtField.getText()))) {
                            Inventory.displayMinNotIntError();
                            return;
                        } else if (!(isInt(partMaxTxtField.getText()))) {
                            Inventory.displayMaxNotNumberError();
                            return;
                        } else {
                            if (modPartCompNameORMachIdTxt.getText().isEmpty()) {
                                Inventory.compNameNotEnteredError();
                                return;
                            }
                            Outsourced modOutsourced = new Outsourced((Integer.parseInt(partIdTxtField.getText())),
                                    (partNameTxtField.getText()),
                                    (Double.parseDouble(partPriceTxtField.getText())),
                                    (Integer.parseInt(partInvTxtField.getText())),
                                    (Integer.parseInt(String.valueOf(partMinTxtField.getText()))),
                                    (Integer.parseInt(String.valueOf(partMaxTxtField.getText()))),
                                    (String.valueOf(modPartCompNameORMachIdTxt.getText())));
                            if (Inventory.validatePart(modOutsourced)) {
                                Inventory.updatePart(i, modOutsourced);
                            }
                            else {
                                return;
                            }
                        }
                    }
                }
            }
        }
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 1000, 450);
        stage.setScene(scene);
        stage.show();
    }


    /**
     * Makes it possible to use the objects called by the method. Receives whatever object data is necessary to make
     * the object valid and usable. Initializes the <code>ModifyParts</code> screen, makes the "partIdTxtField" TextField uneditable,
     * and sets the text within the "addProdIdTxt" TextField to the selected <code>Part</code>'s "partId". This shows that the "partId"
     * field cannot be modified, even through the <code>ModifyParts</code> scene. Populates the TextFields with the selected
     * <code>Part</code>'s other information. If the class of the <code>Part</code> selected on the <code>MainScreen</code>
     * scene is of type <code>InHouse</code>, this method sets the "modifyPartRadioInHouse" radio button to "true" and casts
     * the "modifiablePart" <code>Part</code> object created in the <code>ModifyProduct</code> file to an <code>InHouse</code>
     * <code>Part</code> subclass object so that the "getMachineId()" method can be used from the <code>InHouse</code> <code>Part</code>
     * subclass to populate the "addPartCompNameORMachIdTxt" TextField. Alternatively, if the class of the item selected on the
     * <code>MainScreen</code> scene is of type <code>Outsourced</code>, this method sets the "modifyPartRadioOutsourced" radio
     * button to "true" and casts the "modifiablePart" <code>Part</code> object created in the <code>ModifyProduct</code> file
     * to an <code>Outsourced</code> <code>Part</code> subclass item so that the "getCompanyName()" method can be used from the
     * <code>Outsourced</code> <code>Part</code> subclass to populate the "addPartCompNameORMachIdTxt" TextField.
     * @param url Used to locate resources. Can be used to locate online resources, files, or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        partIdTxtField.setText(String.valueOf(modifiablePart.getId()));
        partIdTxtField.setEditable(false);
        partIdTxtField.setDisable(true);

        partNameTxtField.setText(modifiablePart.getName());
        partInvTxtField.setText(String.valueOf(modifiablePart.getStock()));
        partPriceTxtField.setText(String.valueOf(modifiablePart.getPrice()));
        partMinTxtField.setText(String.valueOf(modifiablePart.getMin()));
        partMaxTxtField.setText(String.valueOf(modifiablePart.getMax()));

        if ((modifiablePart.getClass().getName().equals("model.InHouse"))){
            modifyPartRadioInHouse.setSelected(true);
            inHousePart = ((InHouse) modifiablePart);
            modPartCompNameORMachIdTxt.setText(String.valueOf(inHousePart.getMachineId()));
        }
        else {
            outsourcedPart = ((Outsourced) modifiablePart);
            modifyPartRadioOutsourced.setSelected(true);
            modProdMachineIdLbl.setText("Company Name");
            modPartCompNameORMachIdTxt.setText(outsourcedPart.getCompanyName());
        }
    }
}
