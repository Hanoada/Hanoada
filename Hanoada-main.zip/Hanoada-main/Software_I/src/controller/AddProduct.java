package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import static model.Inventory.*;


/**
 * @AddProduct
 * Establishes the <code>AddProduct</code> class. This class also gives the user the ability to add
 * <code>Product</code>s to the "allProducts" ObservableList contained in the <code>Inventory</code> file using the
 * "Save" button found in the scene.
 */
public class AddProduct implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private TableView<Part> addProdTopTblView;
    @FXML
    private TableColumn<Object, Object> addProductTopPartIdCol;
    @FXML
    private TableColumn<Object, Object> addProductTopPartNameCol;
    @FXML
    private TableColumn<Object, Object> addProductTopInvLvlCol;
    @FXML
    private TableColumn<Object, Object> addProductTopPartPriceCol;
    @FXML
    public TableView<Part> addProdBotTblView;
    @FXML
    private TableColumn<Object, Object> addProdBotIdCol;
    @FXML
    private TableColumn<Object, Object> addProdBotNameCol;
    @FXML
    private TableColumn<Object, Object> addProdBotInvCol;
    @FXML
    private TableColumn<Object, Object> addProdBotPriceCol;
    @FXML
    public TextField addProdIdTxt;
    @FXML
    public TextField addProdNameTxt;
    @FXML
    public TextField addProdInvTxt;
    @FXML
    public TextField addProdPriceTxt;
    @FXML
    public TextField addProdMaxTxt;
    @FXML
    public TextField addProdMinTxt;
    @FXML
    public Label addProdSearchPartNotFound;
    @FXML
    public TextField addProdSearchText;
    public ObservableList<Part> lowerTableList = FXCollections.observableArrayList();


    /**
     * Adds a new <code>Part</code> to the "lowerTableList" ObservableList when the "Add" button is pressed on the <code>AddProduct</code> scene. Gets
     * a user selection from the "addProdTopTblView" TableView and adds the selected item to the "addProdBotTblView" Tableview
     * using the lowerTableList ObservableList, which is a list of <code>Part</code>s that should be associated with a new <code>Part</code>
     * if changes are saved. Error checks by displaying a message if the user has not selected a part before clicking the "Add" button.
     */
    @FXML
    public void onActAddProdAddPartBtn() {
        Part selectedPart = addProdTopTblView.getSelectionModel().getSelectedItem();

        if (selectedPart == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Please Select a Part");
            alert.setHeaderText("Please select a Part first.");
            alert.setContentText("You must select a part to add to the product.");
            alert.showAndWait();
        } else {
            lowerTableList.add(selectedPart);
            addProdBotTblView.setItems(lowerTableList);
        }
    }


    /**
     * Saves a user's new <code>Part</code>. This method gets the information from the cells in the <code>AddProduct</code>
     * scene if all information is entered correctly. Also adds the user's new <code>Part</code> to the "allProducts"
     * ObservableList found in the <code>Inventory</code> file and loads the <code>MainScreen</code> resource, returning
     * the user to the <code>MainScreen</code> scene automatically. Error checking happens in this method and through method
     * calls to the <code>Inventory</code> file.
     *
     * @param event This parameter is used to get the <code>MainScreen</code> scene. This parameter is activated after a user fills-in appropriate
     *              <code>Part</code> data and presses the "Save" button. The <code>Part</code> is added to the "allProducts" ObservableList contained
     *              in the <code>Inventory</code> file and the user is automatically directed to the <code>MainScreen</code> scene.
     * @throws IOException The IOException is thrown when input/output problems exist as a result of the method call.
     */
    @FXML
    void onActAddProdSaveBtn(ActionEvent event) throws IOException {
        if ((addProdNameTxt.getText().isEmpty()) ||
                addProdPriceTxt.getText().isEmpty() ||
                addProdInvTxt.getText().isEmpty() ||
                addProdMinTxt.getText().isEmpty() ||
                addProdMaxTxt.getText().isEmpty()) {
            Inventory.displayEmptyNameError();
        } else if ((!(isDouble(addProdPriceTxt.getText()))) && (!(isInt(addProdPriceTxt.getText())))) {
            Inventory.displayPriceNotDoubleError();
        } else if (!(isInt(String.valueOf(addProdInvTxt.getText())))) {
            Inventory.displayStockNotIntError();
        } else if (!(isInt(addProdMinTxt.getText()))) {
            Inventory.displayMinNotIntError();
        } else if (!(isInt(addProdMaxTxt.getText()))) {
            Inventory.displayMaxNotNumberError();
        } else {
            Product newProduct = new Product(0, "", 0, 0, 0, 0);
            ObservableList<Part> selectedParts = addProdBotTblView.getItems();
            newProduct.setId(getProductTracker());
            newProduct.setName(addProdNameTxt.getText());
            newProduct.setStock(Integer.parseInt(addProdInvTxt.getText()));
            newProduct.setPrice(Double.parseDouble(addProdPriceTxt.getText()));
            newProduct.setMin(Integer.parseInt(addProdMinTxt.getText()));
            newProduct.setMax(Integer.parseInt(addProdMaxTxt.getText()));

            for (Part selectedPart : selectedParts) {
                newProduct.addAssociatedPart(selectedPart);
            }
            if (Inventory.validateProduct(newProduct)) {
                Inventory.addProduct(newProduct);
            } else {
                return;
            }
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
            stage.setScene(new Scene(scene));
            stage.show();
        }
    }


    /**
     * Removes a selected <code>Part</code> from the "lowerTableList" ObservableList when the "Remove Associated Part" button
     * is pressed on the <code>AddProduct</code> screen. Gets a user selection from the "addProdBotTblView" TableView and removes
     * it from the "addProdBotTblView" Tableview using the lowerTableList ObservableList, which is a list of <code>Part</code>s
     * that should be associated with a new <code>Part</code> if changes are saved. A <code>CONFIRMATION</code> dialog displays
     * to confirm the user's choice.
     */
    @FXML
    public void onActRemoveAssociatedPartBtn() {
        Part selectedPartToRemove = addProdBotTblView.getSelectionModel().getSelectedItem();

        if (selectedPartToRemove == null) {
            Alert PartNotSelected = new Alert(Alert.AlertType.WARNING, "Please select a Part to remove first.");
            PartNotSelected.setTitle("No Part Selected");
            PartNotSelected.setHeaderText("No Part Selected");
            Optional<ButtonType> noPartSelected = PartNotSelected.showAndWait();
            if (noPartSelected.isPresent() && noPartSelected.get() == ButtonType.OK) {
                PartNotSelected.close();
            }
        } else {
            Alert confirmDelete = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to remove this Part?", ButtonType.YES, ButtonType.CANCEL);
            confirmDelete.setTitle("Are You Sure?");
            Optional<ButtonType> yes = confirmDelete.showAndWait();
            if (yes.isPresent() && yes.get() == ButtonType.YES) {
                for (int i = 0; i < addProdBotTblView.getItems().size(); ++i) {
                    if (selectedPartToRemove == addProdBotTblView.getItems().get(i)) {
                        addProdBotTblView.getItems().remove(i);
                        break;
                    }
                    if (yes.get() == ButtonType.OK) {
                        confirmDelete.close();
                    }
                }
            }
        }
    }


    /**
     * Makes it possible to use the objects called by the method. Receives whatever object data is necessary to make the object valid and usable.
     * Initializes the <code>AddProduct</code> screen, makes the "addProdIdTxt" TextField uneditable, and sets the text within the "addProdIdTxt"
     * TextField to "Disabled: Auto-Generated", which shows that the "productId" for new <code>Part</code>s is auto-generated and is not changeable by users.
     * Also sets the Cell Value Factory data for the addProdTobTblView and addProdBotTblView TableViews on the <code>AddProduct</code> screen.
     * The PropertyValueFactory Strings can then be used when inserting data into the TableViews and their various TableColumns.
     *
     * @param url            This parameter is used to locate resources. It can be used to locate files or directories.
     * @param resourceBundle This parameter contains locale-specific objects for the program to retrieve when needed.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        addProdIdTxt.setEditable(false);
        addProdIdTxt.setText("Disabled: Auto-Generated");
        addProdIdTxt.setDisable(true);

        addProdTopTblView.setItems(Inventory.getAllParts());
        addProductTopPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        addProductTopPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        addProductTopInvLvlCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        addProductTopPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        addProdBotIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        addProdBotNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        addProdBotInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        addProdBotPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
    }


    /**
     * Returns the user to the <code>MainScreen</code> scene. Discards all entered <code>Part</code> information (after a <code>CONFIRMATION</code> dialog)
     * before returning the user back to the <code>MainScreen</code> scene. Triggered by clicking the "Cancel" button on the <code>AddProduct</code> scene.
     *
     * @param actionEvent Triggered by clicking the "Cancel" button on the <code>AddProduct</code> scene. Used to trigger the program to discard any entered
     *                    <code>Part</code> information and load the <code>MainScreen</code> scene.
     * @throws IOException The IOException is thrown when input/output problems exist as a result of the method call.
     */
    public void onActionAddProdCancelBtn(ActionEvent actionEvent) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will clear all text values. Would you like to continue?");
        alert.setTitle("Please Confirm");

        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 1000, 450);
            stage.setScene(scene);
            stage.show();
        }
    }


    /**
     * Adds search functionality to the <code>AddProduct</code> "addProdTopTblView" TableView. Allows for the ability to search
     * by <code>Part</code> name or <code>Part</code> ID. Searching is initiated by pressing the "Enter" key.
     */
    public void onActAddProdSearchPart() {
        addProdSearchPartNotFound.setVisible(false);
        String searchText;
        searchText = addProdSearchText.getText();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        if (addProdSearchText == null) {
            addProdTopTblView.setItems(getAllParts());
        } else if (!(isInt(searchText))) {
            for (int i = 0; i < getAllParts().size(); ++i) {
                addProdTopTblView.setItems(Inventory.lookupPart(addProdSearchText.getText()));
            }
        } else if (isInt(searchText)) {
            int searchTextToInt = Integer.parseInt(searchText);
            filteredParts.add(Inventory.lookupPart(searchTextToInt));
            addProdTopTblView.setItems(filteredParts);
            if (addProdTopTblView.getItems().get(0) == null) {
                addProdSearchPartNotFound.setVisible(true);
            }
        }
        if (addProdTopTblView.getItems().size() == 0) {
            addProdSearchPartNotFound.setVisible(true);
        }
    }
}
