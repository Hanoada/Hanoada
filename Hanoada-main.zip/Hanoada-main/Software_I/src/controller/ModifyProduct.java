package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import static model.Inventory.*;


/**
 * @ModifyProduct Establishes the <code>ModifyProduct</code> class. Gives the user the ability to modify existing <code>Product</code>s in the
 * "allProducts" ObservableList contained in the <code>Inventory</code> file using the "Save" button found in the scene.
 */
public class ModifyProduct implements Initializable {
    Stage stage;
    Parent scene;
    @FXML
    public TextField modProdIdField;
    @FXML
    public TextField modProdNameField;
    @FXML
    public TextField modifyProductInventoryField;
    @FXML
    public TextField modifyProductPriceField;
    @FXML
    public TextField modifyProductMaxField;
    @FXML
    public TextField modifyProductMinField;
    @FXML
    public TableView<Part> modProdTopTbl;
    @FXML
    public TableView<Part> modProdBotTbl;
    @FXML
    private TableColumn<Object, Object> modProdTopPartIdCol;
    @FXML
    private TableColumn<Object, Object> modProdTopPartNameCol;
    @FXML
    private TableColumn<Object, Object> modProdTopInvCol;
    @FXML
    private TableColumn<Object, Object> modProdTopPriceCol;
    @FXML
    private TableColumn<Object, Object> modProdBotPartIdCol;
    @FXML
    private TableColumn<Object, Object> modProdBotPartNameCol;
    @FXML
    private TableColumn<Object, Object> modProdBotInvCol;
    @FXML
    private TableColumn<Object, Object> modProdBotPriceCol;
    @FXML
    private TextField modProdSearchText;
    @FXML
    private Label modProdSearchPartNotFound;
    public static Product modifiableProductCopy;


    /**
     * A copy of the user-selected <code>Product</code> from the <code>MainScreen</code> scene. Used to access non-static
     * <code>Product</code> methods and fields in agreement with inheritance requirements.
     */
    public static Product modifiableProduct;
    public static int modifiableProductIndex;
    public static ObservableList<Part> modifiableProductParts = FXCollections.observableArrayList();


    /**
     * Event Handler for the "Cancel" button on the <code>ModifyProduct</code> scene. Allows a user to cancel the modifications made
     * to an existing <code>Product</code>, displaying a <code>CONFIRMATION</code> dialog to confirm the user's choice to cancel modifications before
     * returning the user to the <code>MainScreen</code> scene.
     * @param actionEvent Loads the <code>MainScreen</code>.fxml resource which redirects the user to the <code>MainScreen</code> stage.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActModProdCancelBtn(ActionEvent actionEvent) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Your modifications will not be saved. Would you like to continue?");
        alert.setTitle("Please Confirm");

        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            alert.close();
            modifiableProduct.getAllAssociatedParts().setAll(modifiableProductParts);

            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 1000, 450);
            stage.setScene(scene);
            stage.show();
        }
    }


    /**
     * Event Handler for the "Add" button under the "modProdTopTbl" TableView. Takes the user-selected <code>Part</code>
     * from the "modProdTopTbl" TableView and adds it to the "modProdBotTbl" TableView. Ensures a user has selected a
     * <code>Part</code> from the "modProdTopTbl" TableView and displays a <code>WARNING</code> dialog box if the user has not
     * selected a <code>Part</code>. If the user has successfully selected a <code>Part</code>, the <code>Part</code>
     * is added to the "modProdBotTbl" TableView when the user clicks the "Add" button under the "modProdTopTbl"
     * TableView and a <code>CONFIRMATION</code> dialog is displayed.
     */
    public void onActAddPartAddBtn() {
        Part selectedPart = modProdTopTbl.getSelectionModel().getSelectedItem();

        if(selectedPart == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Select a Part");
            alert.setHeaderText("Select a Part");
            alert.setContentText("You must select a part to add to the product.");
            alert.showAndWait();
        }
        else {
            modifiableProduct.addAssociatedPart(selectedPart);
        }
    }


    /**
     * Event Handler for the "Remove" button under the "modProdTopTbl" TableView. Removes the user-selected <code>Part</code>
     * from the "modProdBotTbl" TableView. Ensures a user has selected a <code>Part</code> from the "modProdBotTbl"
     * TableView and displays a <code>WARNING</code> dialog box if the user has not selected a <code>Part</code>.
     * If the user has successfully selected a <code>Part</code>, the <code>Part</code> is removed from the "modProdBotTbl"
     * TableView when the user clicks the "Remove" button under the "modProdBotTbl" TableView after a <code>CONFIRMATION</code>
     * dialog.
     */
    public void onActRemovePart() {
        Part selectedPartToRemove = modProdBotTbl.getSelectionModel().getSelectedItem();

        if (selectedPartToRemove == null) {
            Alert PartNotSelected = new Alert(Alert.AlertType.WARNING, "Please select a Part to remove first.");
            PartNotSelected.setTitle("No Part Selected");
            PartNotSelected.setHeaderText("No Part Selected");
            Optional<ButtonType> noPartSelected = PartNotSelected.showAndWait();
            if (noPartSelected.isPresent() && noPartSelected.get() == ButtonType.OK) {
                PartNotSelected.close();
            }
        }
        else {
            Alert confirmDelete = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to remove this Part?", ButtonType.YES, ButtonType.CANCEL);
            confirmDelete.setTitle("Are You Sure?");
            Optional<ButtonType> yes = confirmDelete.showAndWait();

            if (yes.isPresent() && yes.get() == ButtonType.YES) {
                if (modifiableProduct.deleteAssociatedPart(selectedPartToRemove)) {
                    if (yes.get() == ButtonType.OK) {
                        confirmDelete.close();
                        modProdBotPartIdCol.setSortType(TableColumn.SortType.DESCENDING);
                        modProdBotTbl.sort();
                    }
                }
            }
        }
    }


    /**
     * Event Handler to save the modifications a user has made to a specific <code>Product</code>. Uses the "modifiableProduct"
     * found in the <code>ModifyProduct</code> controller file to get a copy of the user-selected <code>Product</code>.
     * Uses methods in the <code>ModifyProduct</code> and <code>Inventory</code> files to provide error checking and set the updated <code>Part</code>s
     * associated with the modified <code>Product</code>. Also uses the "updateProduct()" method found in the <code>Inventory</code> file.
     * @param actionEvent Loads the <code>MainScreen</code> resource which redirects the user to the <code>MainScreen</code> stage.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    public void onActModProdSaveBtn(ActionEvent actionEvent) throws IOException {
        if ((modProdNameField.getText().isEmpty()) ||
                modifyProductPriceField.getText().isEmpty() ||
                modifyProductInventoryField.getText().isEmpty() ||
                modifyProductMinField.getText().isEmpty() ||
                modifyProductMaxField.getText().isEmpty()) {
            Inventory.displayEmptyNameError();
            return;
        }
        else if ((!(isDouble(modifyProductPriceField.getText()))) && (!(isInt(modifyProductPriceField.getText())))) {
            Inventory.displayPriceNotDoubleError();
            return;
        }
        else if (!(isInt(String.valueOf(modifyProductInventoryField.getText())))) {
            Inventory.displayStockNotIntError();
            return;
        }
        else if (!(isInt(modifyProductMinField.getText()))) {
            Inventory.displayMinNotIntError();
            return;
        }
        else if (!(isInt(modifyProductMaxField.getText()))) {
            Inventory.displayMaxNotNumberError();
            return;
        }
        else {

            modifiableProduct.setName(modProdNameField.getText());
            modifiableProduct.setStock(Integer.parseInt(modifyProductInventoryField.getText()));
            modifiableProduct.setPrice(Double.parseDouble(modifyProductPriceField.getText()));
            modifiableProduct.setMin(Integer.parseInt(modifyProductMinField.getText()));
            modifiableProduct.setMax(Integer.parseInt(modifyProductMaxField.getText()));
            modifiableProductIndex = Inventory.getAllProducts().indexOf(modifiableProduct);

            if (Inventory.validateProduct(modifiableProduct)) {
                Inventory.updateProduct(modifiableProductIndex, modifiableProduct);
            }
            else {
                return;
            }
        }
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * Adds search functionality to the <code>ModifyProduct</code> "modProdTopTbl" TableView. Allows for the ability
     * to search by <code>Part</code> name or <code>Part</code> ID. Searching is initiated by pressing the "Enter" key.
     */
    public void onActModProdSearchPart() {
        modProdSearchPartNotFound.setVisible(false);
        String searchText;
        searchText = modProdSearchText.getText();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        if (modProdSearchText == null) {
            modProdTopTbl.setItems(getAllParts());
        }
        else if (!(isInt(searchText))) {
            for (int i = 0; i < getAllParts().size(); ++i) {
                modProdTopTbl.setItems(Inventory.lookupPart(modProdSearchText.getText()));
            }
        }
        else if (isInt(searchText)) {
            int searchTextToInt = Integer.parseInt(searchText);
            filteredParts.add(Inventory.lookupPart(searchTextToInt));
            modProdTopTbl.setItems(filteredParts);
            if (modProdTopTbl.getItems().get(0) == null){
                modProdSearchPartNotFound.setVisible(true);
            }
        }
        if (modProdTopTbl.getItems().size() == 0){
            modProdSearchPartNotFound.setVisible(true);
        }
    }


    /**
     * Makes it possible to use the objects called by the method. Receives whatever object data is necessary to make
     * the object valid and usable. Initializes the <code>ModifyProduct</code> scene, makes the "modProdIdField" TextField
     * uneditable, and sets the text within the "modProdIdField" TextField to the selected <code>Product</code>'s "partId".
     * This shows that the "productId" field cannot be modified, even through the <code>ModifyProduct</code> scene.
     * Populates the TextFields with the selected <code>Product</code>'s information using the "setCellValueFactory" method
     * and the "PropertyValueFactory" object to produce an easily-identifiable string associated with each column of the
     * "modProdTobTbl" and "modProdBotTbl" TableViews. Uses the "setItems()" method along with the "getAllParts()" method, and
     * "modifiableProduct" items to accomplish the task.
     * @param url Used to locate resources. Can be used to locate online resources, files, or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        modProdTopTbl.setItems(Inventory.getAllParts());

        modProdTopPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        modProdTopPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        modProdTopInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        modProdTopPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        modProdBotPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        modProdBotPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        modProdBotInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        modProdBotPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        modProdIdField.setText(String.valueOf(modifiableProduct.getId()));
        modProdIdField.setDisable(true);

        modProdTopTbl.setItems(Inventory.getAllParts());

        modProdBotTbl.setItems(modifiableProduct.getAllAssociatedParts());

        modProdNameField.setText(String.valueOf(modifiableProduct.getName()));
        modifyProductInventoryField.setText(String.valueOf(modifiableProduct.getStock()));
        modifyProductPriceField.setText(String.valueOf(modifiableProduct.getPrice()));
        modifyProductMinField.setText(String.valueOf(modifiableProduct.getMin()));
        modifyProductMaxField.setText(String.valueOf(modifiableProduct.getMax()));

        modifiableProductCopy = modifiableProduct;
        modifiableProductParts.setAll(modifiableProduct.getAllAssociatedParts());

    }
}
