package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import static controller.ModifyProduct.modifiableProduct;
import static model.Inventory.*;


/**
 * @MainScreen Establishes the <code>MainScreen</code> class. Gives the user the ability to access the <code>AddPart</code>, <code>AddProduct</code>,
 * <code>ModifyProduct</code>, and <code>ModifyParts</code> scenes using buttons placed inside the scene. The "mainPartTableView" TableView
 * is populated with information from the "allParts" ObservableList contained in the <code>Inventory</code> file. The
 * "mainProductTableView" TableView is populated with information from the "allProducts" ObservableList contained in the
 * <code>Inventory</code> file.
 */
public class MainScreen implements Initializable {

    Stage stage;
    Parent scene;

    public MainScreen() {
    }

    @FXML
    private TableColumn<Product, Integer> productIdCol;
    @FXML
    private TableColumn<Product, String> productNameCol;
    @FXML
    private TableColumn<Product, Integer> productInventoryLevelCol;
    @FXML
    private TableColumn<Product, Double> productPriceCol;
    @FXML
    private TableView<Part> mainPartTableView;

    @FXML
    private TableColumn<Object, Object> partIdCol;
    @FXML
    private TableColumn<Object, Object> partNameCol;
    @FXML
    private TableColumn<Object, Object> partInventoryLevelCol;
    @FXML
    private TableColumn<Object, Object> partPriceCol;
    @FXML
    private TableView<Product> mainProductTableView;
    @FXML
    TextField mainSearchProdTxtField;
    @FXML
    public TextField mainPartSearchTxt;
    @FXML
    public Label noMatchingPartsLbl;
    @FXML
    public Label noMatchingProductsLbl;


    /**
     * Makes it possible to use the objects called by the method. Receives whatever object data is necessary to make the
     * object valid and usable. Initializes the <code>MainScreen</code> scene and sets the CellValueFactory data
     * for the "mainPartTableView" and "mainProductTableView" TableViews in the <code>MainScreen</code> scene. The PropertyValueFactory Strings
     * can then be used when inserting data into the TableViews and their various TableColumns.
     * @param url            This parameter is used to locate resources. It can be used to locate files or directories.
     * @param resourceBundle This parameter contains locale-specific objects for the program to retrieve when needed.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        mainPartTableView.setItems(Inventory.getAllParts());
        partIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        partInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        mainProductTableView.setItems(Inventory.getAllProducts());
        productIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        productInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

    }


    /**
     * Event handler for the "Add" button on the <code>MainScreen</code> <code>AddPart</code> menu. Redirects the user to the <code>AddPart</code> scene using
     * the "Add" button located under the "mainPartTableView" TableView on the <code>MainScreen</code> scene.
     *
     * @param actionEvent Loads the <code>AddPart</code> resource which redirects the user to the <code>AddPart</code>> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    @FXML
    private void onActionMainAddPart(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/AddParts.fxml")));
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 500, 450);
        stage.setTitle("Add Part");
        stage.setScene(scene);
        stage.show();
    }


    /**
     * Event Handler for the "Delete" button on the <code>MainScreen</code> <code>Part</code>s menu. Deletes a <code>Part</code> from the "mainPartTableView"
     * TableView using the "Delete" button on the left-hand side of the <code>MainScreen</code> scene by getting the selected item from the
     * "mainPartTableView" TableView. Produces a dialog box to confirm that the user wants to delete the selected
     * <code>Part</code> before it is deleted from the "allParts" ObservableList. Dialog boxes are also generated if there are no <code>Part</code>s in
     * the user's inventory and if they have not selected a <code>Part</code> before pressing the "Delete" button.
     */
    @FXML
    private void onActionMainPartDeleteBtn() {
        Part partToDelete = mainPartTableView.getSelectionModel().getSelectedItem();

        if (Inventory.deletePart(partToDelete)) {
            Alert confirm = new Alert(Alert.AlertType.INFORMATION, "Part was successfully deleted from your inventory.");
            confirm.setTitle("Part Deleted");
            confirm.setHeaderText("The Selected Part Has Been Deleted");
            Optional<ButtonType> result1 = confirm.showAndWait();
            if (result1.isPresent() && result1.get() == ButtonType.OK) {
                confirm.close();
            }
        }
        else {
                return;
            }

        if (Inventory.getAllParts().isEmpty()) {
            Alert emptyParts = new Alert(Alert.AlertType.WARNING, "There are no Parts in your inventory.");
            emptyParts.setTitle("No Parts Exist");
            Optional<ButtonType> result2 = emptyParts.showAndWait();
            if (result2.isPresent() && result2.get() == ButtonType.OK) {
                emptyParts.close();
            }
        } else if (mainPartTableView.getSelectionModel().getSelectedItem() == null) {
            Alert noPartSelected = new Alert(Alert.AlertType.ERROR, "Please select a Part you would like to delete first.");
            noPartSelected.setTitle("No Selection Made");
            noPartSelected.setHeaderText("Please Select a Part First");
            Optional<ButtonType> result3 = noPartSelected.showAndWait();
            if (result3.isPresent() && result3.get() == ButtonType.OK) {
                noPartSelected.close();
            }
        }
        if (!(mainPartTableView.getItems() == Inventory.getAllParts())) {
            mainPartTableView.setItems(Inventory.getAllParts());
        }
    }


    /**
     * Event Handler for the "Add" button on the <code>MainScreen</code> scene under the "mainProductTableView" TableView. Redirects
     * a user to the <code>AddProduct</code> scene, where they can add new <code>Product</code> objects to the inventory system using
     * the "addProduct" ObservableList found in the <code>Inventory</code> file.
     *
     * @param actionEvent Used to direct the user to the <code>ModifyProduct</code>scene. Activated after a user clicks the
     *                    "Modify" button on the <code>MainScreen</code> scene. If the user has an item selected, they will be redirected;
     *                    if not, they will see a dialog box informing them to select a <code>Product</code> first.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    @FXML
    private void onActionMainProdAddBtn(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/AddProducts.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * Event Handler for the "Modify" button on the <code>MainScreen</code> scene under the "mainPartTableView" TableView. Redirects
     * a user to the <code>ModifyParts</code> scene, where they can modify existing <code>Part</code> objects in the inventory system
     * using the "allParts" ObservableList found in the <code>Inventory</code> file. Includes an <code>ERROR</code> dialog if a user
     * tries to enter the <code>ModifyPart</code> screen without first selecting a part and a <code>WARNING</code> dialog if there are
     * no <code>Part</code>s in the user's inventory.
     */
    @FXML
    private void onActionMainModifyPart(ActionEvent actionEvent) throws IOException {
        Part selectedPart = mainPartTableView.getSelectionModel().getSelectedItem();

        if (Inventory.getAllParts().isEmpty()) {
            Alert emptyParts = new Alert(Alert.AlertType.WARNING, "There are no Parts in your inventory.");
            emptyParts.setTitle("NO PARTS EXIST");
            Optional<ButtonType> result1 = emptyParts.showAndWait();
            if (result1.isPresent() && result1.get() == ButtonType.OK) {
                emptyParts.close();
            }
        } else if (mainPartTableView.getSelectionModel().getSelectedItem() == null) {
            Alert noPartSelected = new Alert(Alert.AlertType.ERROR, "Please select a Part you would like to delete first.");
            noPartSelected.setTitle("NO SELECTION MADE");
            Optional<ButtonType> result2 = noPartSelected.showAndWait();
            if (result2.isPresent() && result2.get() == ButtonType.OK) {
                noPartSelected.close();
            }
        }

        ModifyParts.setPartToModify(selectedPart);

        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/ModifyParts.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * Event Handler for the "Modify" button on the <code>MainScreen</code> scene under the "mainProductTableView" TableView. Redirects
     * a user to the <code>ModifyProduct</code> scene, where they can modify existing <code>Product</code> objects in the inventory system
     * using the "allProducts" ObservableList found in the <code>Inventory</code> file. Includes a <code>WARNING</code> dialog if the user
     * tries to enter the <code>ModifyProduct</code> scene without first selecting a <code>Product</code>.
     */
    @FXML
    private void onActionMainModProdBtn(ActionEvent actionEvent) throws IOException {

        if (mainProductTableView.getSelectionModel().getSelectedItem() == null) {
            Alert emptyParts = new Alert(Alert.AlertType.WARNING, "Please select a Product to Modify.");
            emptyParts.setTitle("No Product Selected");
            emptyParts.setContentText("Please Select a Product");
            Optional<ButtonType> result1 = emptyParts.showAndWait();
            if (result1.isPresent() && result1.get() == ButtonType.OK) {
                emptyParts.close();
            }
        }
        else {
            modifiableProduct = mainProductTableView.getSelectionModel().getSelectedItem();

            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/ModifyProduct.fxml")));
            stage.setScene(new Scene(scene));
            stage.show();
        }
    }


    /**
     * Event Handler for the "Exit" button on the <code>MainScreen</code> scene. Allows a user to exit the application using
     * the "Exit" button on the <code>MainScreen</code> scene. Status code "0" means the application ran and exited
     * successfully without errors.
     */
    @FXML
    private void onActionExitMain() {
        System.exit(0);
    }


    /**
     * <p>Event Handler for the "Delete" button found under the "mainProductTableView" on the <code>MainScreen</code> scene. Allows
     * a user to delete a selected <code>Product</code> object from inventory using the "allProducts" ObservableList found in the
     * <code>Inventory</code> file. Along with an <code>INFORMATION</code> dialog to verify the selected <code>Product</code>'s
     * deletion and a <code>CONFIRMATION</code> dialog if the deletion is successful, multiple dialog
     * boxes are set up to control for the following issues:</p>
     * <p><b>A)</b> The <code>Product</code> has <code>Part</code>s associated with it.</p>
     * <p><b>B)</b> The user does not have a <code>Product</code> selected.</p>
     * <p><b>C)</b> There are no <code>Product</code>s in the user's inventory.</p>
     */
    @FXML
    public void onActMainProdDeleteBtn() {

        Product prodToDelete = mainProductTableView.getSelectionModel().getSelectedItem();

        if (Inventory.getAllProducts().isEmpty()) {
            Alert emptyProducts = new Alert(Alert.AlertType.WARNING, "There are no Products in your inventory.");
            emptyProducts.setTitle("No Products Exist");
            Optional<ButtonType> result2 = emptyProducts.showAndWait();
            if (result2.isPresent() && result2.get() == ButtonType.OK) {
                emptyProducts.close();
            }
        }

        if (prodToDelete == null) {
            Alert noProductSelected = new Alert(Alert.AlertType.ERROR, "Please select a Product you would like to delete first.");
            noProductSelected.setTitle("No Selection Made");
            noProductSelected.setHeaderText("Please Select a Product First");
            Optional<ButtonType> result3 = noProductSelected.showAndWait();
            if (result3.isPresent() && result3.get() == ButtonType.OK) {
                noProductSelected.close();
            }
        } else {
            if (prodToDelete.getAllAssociatedParts().size() == 0) {

                Alert confirmDelete = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this Product?", ButtonType.YES, ButtonType.CANCEL);
                confirmDelete.setTitle("Are You Sure?");
                Optional<ButtonType> yes = confirmDelete.showAndWait();
                Optional<ButtonType> cancel = Optional.of(ButtonType.CANCEL);
                if (yes.isPresent() && yes.get() == ButtonType.YES) {
                    Inventory.deleteProduct(prodToDelete);

                    Alert deleted = new Alert(Alert.AlertType.INFORMATION, "Your Product was successfully deleted from inventory.");
                    deleted.setTitle("Product Deleted");
                    deleted.setHeaderText("Successfully Deleted");
                    Optional<ButtonType> result1 = deleted.showAndWait();

                    if (result1.isPresent() && result1.get() == ButtonType.OK) {
                        deleted.close();
                        return;
                    }
                } else {
                    cancel.get();
                    return;
                }
            } else {
                Alert associatedParts = new Alert(Alert.AlertType.WARNING, "The selected product still has Parts associated with it. Please remove all Parts before deleting the selected Product.");
                associatedParts.setTitle("Remove All Parts");
                associatedParts.setHeaderText("Your Product Still Has Associated Parts");
                Optional<ButtonType> stillParts = associatedParts.showAndWait();
                if (stillParts.isPresent() && stillParts.get() == ButtonType.OK) {
                    associatedParts.close();
                    return;
                }
            }
        }
        if (!(mainProductTableView.getItems() == Inventory.getAllProducts())) {
            mainProductTableView.setItems(Inventory.getAllProducts());
        }
    }


    /**
     * <p><b>RUNTIME ERROR:</b> Caused by: java.lang.NullPointerException: Cannot invoke "javafx.scene.control.TextField.getText()"
     * because "controller.MainScreen.mainPartSearchTxt" is null. I was able to figure out that the "mainPartSearchText" was showing
     * as null because the <code>MainScreen</code>.fxml TextField was not declared under the proper name in this (the <code>MainScreen</code>) file. I
     * updated the name in this file and the problem was solved.</p>
     * <p>Adds search functionality to the <code>MainScreen</code> "mainPartTableView" TableView. Allows for the ability to search by
     * <code>Part</code> name or <code>Part</code> ID. Searching is initiated by pressing the "Enter" key.</p>
     */
    public void onPartSearchEnter() {
        noMatchingPartsLbl.setVisible(false);
        String searchText;
        searchText = mainPartSearchTxt.getText();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        if (mainPartSearchTxt == null) {
            mainPartTableView.setItems(getAllParts());
        }
        else if (!(isInt(searchText))) {
            for (int searchIndex = 0; searchIndex < getAllParts().size(); ++searchIndex) {
                mainPartTableView.setItems(Inventory.lookupPart(mainPartSearchTxt.getText()));
            }
        }
        else if (isInt(searchText)) {
            int searchTextToInt = Integer.parseInt(searchText);
            filteredParts.add(Inventory.lookupPart(searchTextToInt));
            mainPartTableView.setItems(filteredParts);
            if (mainPartTableView.getItems().get(0) == null){
                noMatchingPartsLbl.setVisible(true);
            }
        }
        if (mainPartTableView.getItems().size() == 0){
            noMatchingPartsLbl.setVisible(true);
        }
    }


    /**
     * Adds search functionality to the <code>MainScreen</code> "mainProductTableView" TableView. Allows for the ability to search
     * by <code>Product</code> name or <code>Product</code> ID. Searching is initiated by pressing the "Enter" key.
     */
    public void onProductSearchEnter() {
        noMatchingProductsLbl.setVisible(false);
        String searchText;
        searchText = mainSearchProdTxtField.getText();
        ObservableList<Product> filteredProducts = FXCollections.observableArrayList();

        if (mainSearchProdTxtField == null) {
            mainProductTableView.setItems(getAllProducts());
            mainProductTableView.refresh();
        }
        else if (!(isInt(searchText))) {
            for (int i = 0; i < getAllProducts().size(); ++i) {
                mainProductTableView.setItems(Inventory.lookupProduct(mainSearchProdTxtField.getText()));
            }
        }
        else if (isInt(searchText)) {
            int searchTextToInt = Integer.parseInt(searchText);
            filteredProducts.add(Inventory.lookupProduct(searchTextToInt));
            mainProductTableView.setItems(filteredProducts);
            if (mainProductTableView.getItems().get(0) == null){
                noMatchingProductsLbl.setVisible(true);
            }
        }
        if (mainProductTableView.getItems().size() == 0){
            noMatchingProductsLbl.setVisible(true);
        }
    }
}


