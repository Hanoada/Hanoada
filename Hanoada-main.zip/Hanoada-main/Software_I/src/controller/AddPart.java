package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import static model.Inventory.isDouble;
import static model.Inventory.isInt;


/**
 * @AddPart Establishes the <code>AddPart</code> class. Gives the user the ability to add <code>Part</code>s to the
 * "allParts" ObservableList contained in the <code>Inventory</code> file using the "Save" button found in the scene.
 */
public class AddPart implements Initializable {
    Stage stage;
    Parent scene;
    @FXML
    private TextField partIdTxt;
    @FXML
    private TextField partNameTxt;
    @FXML
    private TextField partStockTxt;
    @FXML
    private TextField partPriceTxt;
    @FXML
    private TextField addPartMaxTxt;
    @FXML
    private TextField addPartMachineIdTxt;
    @FXML
    private TextField addPartMinTxt;
    @FXML
    private RadioButton addPartInHouseBtn;
    @FXML
    private Label compNameOrMachIdLbl;


    /**
     * Event Handler for the "Save" button on the <code>AddPart</code> scene. Adds a new <code>Part</code> to the "allParts" ObservableList
     * when the "Save" button is clicked on the <code>AddPart</code> screen. The "allParts" ObservableList is a <code>Part</code> type
     * ObservableList that is contained in the <code>Inventory</code> controller. Also returns a user to the <code>MainScreen</code>
     * scene if appropriate values were entered to create a <code>Part</code> object. Includes error checking using code in this file
     * (the <code>AddPart</code> controller file) and the <code>Inventory</code> file.
     *
     * @param event Triggered by clicking the "Save" button on the <code>AddPart</code> screen. Used to trigger the program to get
     *              <code>Part</code> information from the <code>AddPart</code> fields and generates a new <code>Part</code>.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    @FXML
    void onActAddPartSaveBtn(ActionEvent event) throws IOException {
        if ((partNameTxt.getText().isEmpty()) ||
                partPriceTxt.getText().isEmpty() ||
                partStockTxt.getText().isEmpty() ||
                addPartMinTxt.getText().isEmpty() ||
                addPartMaxTxt.getText().isEmpty()) {
            Inventory.displayEmptyNameError();
        }
        else if ((!(isDouble(partPriceTxt.getText()))) && (!(isInt(partPriceTxt.getText())))) {
            Inventory.displayPriceNotDoubleError();
        }
        else if (!(isInt(String.valueOf(partStockTxt.getText())))) {
            Inventory.displayStockNotIntError();
        }
        else if (!(isInt(addPartMinTxt.getText()))) {
            Inventory.displayMinNotIntError();
        }
        else if (!(isInt(addPartMaxTxt.getText()))) {
            Inventory.displayMaxNotNumberError();
        }
        else {
            if (addPartInHouseBtn.isSelected()) {
                if (!(isInt(addPartMachineIdTxt.getText()))) {
                    Inventory.displayMachIdNotIntError();
                    return;
                } else {
                    InHouse newInHousePart = new InHouse(
                            Inventory.getPartTracker(),
                            (String.valueOf(partNameTxt.getText())),
                            (Double.parseDouble(partPriceTxt.getText())),
                            (Integer.parseInt(partStockTxt.getText())),
                            (Integer.parseInt(addPartMinTxt.getText())),
                            (Integer.parseInt(addPartMaxTxt.getText())),
                            (Integer.parseInt(addPartMachineIdTxt.getText())));

                    if (Inventory.validatePart(newInHousePart)) {
                        Inventory.addPart(newInHousePart);
                    } else {
                        return;
                    }
                }
            } else {
                if ((!(isDouble(partPriceTxt.getText()))) && (!(isInt(partPriceTxt.getText())))) {
                    Inventory.displayPriceNotDoubleError();
                } else if (!(isInt(String.valueOf(partStockTxt.getText())))) {
                    Inventory.displayStockNotIntError();
                } else if (!(isInt(addPartMinTxt.getText()))) {
                    Inventory.displayMinNotIntError();
                } else if (!(isInt(addPartMaxTxt.getText()))) {
                    Inventory.displayMaxNotNumberError();
                } else {
                    if ((addPartMachineIdTxt.getText().isEmpty())) {
                        Inventory.compNameNotEnteredError();
                        return;
                    }
                    Outsourced newOutsourcedPart = new Outsourced(
                            Inventory.getProductTracker(), (String.valueOf(partNameTxt.getText())),
                            (Double.parseDouble(partPriceTxt.getText())),
                            (Integer.parseInt(partStockTxt.getText())),
                            (Integer.parseInt(addPartMinTxt.getText())),
                            (Integer.parseInt(addPartMaxTxt.getText())),
                            (String.valueOf(addPartMachineIdTxt.getText())));
                    if (Inventory.validatePart(newOutsourcedPart)) {
                        Inventory.addPart(newOutsourcedPart);
                    }
                    else {
                        return;
                    }
                }
            }
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
            stage.setScene(new Scene(scene));
            stage.show();
        }
    }


    /**
     * Makes it possible to use the objects called by the method. Receives whatever object data is necessary to make the
     * object valid and usable. Initializes the <code>AddPart</code> scene, makes the "partIdTxt" TextField uneditable,
     * and sets the text within the "partIdTxt" TextField to "Auto-Generated". This shows that the "partId" for new <code>Part</code>s
     * is auto-generated and is not changeable by users.
     * @param url Used to locate resources. Can be used to locate files or directories.
     * @param resourceBundle Contains locale-specific objects for the program to retrieve when needed.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        partIdTxt.setEditable(false);
        partIdTxt.setText("Auto-Generated");
        partIdTxt.setDisable(true);
    }


    /**
     * Event Handler for the "Cancel" button in the <code>AddPart</code> scene. Returns the user to the <code>MainScreen</code> scene.
     * Discards all entered <code>Part</code> information (after a <code>CONFIRMATION</code> dialog) before returning the user to the <code>MainScreen</code> scene.
     * Triggered by clicking the "Cancel" button on the <code>AddPart</code> scene.
     * @param actionEvent Triggered by clicking the "Cancel" button on the <code>AddPart</code> scene. Used to trigger the program to discard
     *                    any entered <code>Part</code> information and load the <code>MainScreen</code> scene.
     * @throws IOException Thrown when input/output problems exist as a result of the method call.
     */
    @FXML
    private void onActionAddPartCancelBtn(ActionEvent actionEvent) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will clear all text values. Would you like to continue?");
        alert.setTitle("Please Confirm");

        Optional<ButtonType> result = alert.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK) {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 1000, 450);
            stage.setScene(scene);
            stage.show();
        }
    }


    /**
     * Event Handler for the <code>Outsourced</code> Radio Button. Updates the "compNameOrMachIdLbl" TextField.
     * Changes the text found in the "compNameOrMachIdLbl" to "Company Name" in the <code>AddPart</code> scene when the
     * <code>Outsourced</code> Radio Button is selected.
     */
    public void onActionOutSourcedRadio() {
        compNameOrMachIdLbl.setText("Company Name");
    }


    /**
     * Event Handler for the <code>In-House</code> Radio Button. Updates the "compNameOrMachIdLbl" TextField. Changes
     * the text found in the "compNameOrMachIdLbl" to "Machine ID" in the <code>AddPart</code> scene when the <code>In-House</code>
     * Radio Button is selected.
     */
    public void onActionInHouseRadio() {
        compNameOrMachIdLbl.setText("Machine ID");
    }
}
