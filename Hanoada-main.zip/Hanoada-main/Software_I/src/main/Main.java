package main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Product;

import java.util.Objects;


/**
 * <p>@author Adam Hanover - C482: Software I Performance Assessment (Student ID: 001385636)</p>
 * <p><b>FUTURE ENHANCEMENT:</b> A great addition to any inventory management system is the ability to generate a reorder
 * list based on existing item quantities, projected future needs, and supply or production time.</p>
 * <p><b>RUNTIME ERROR:</b> NullPointerException in the "onPartSearchEnter" method of the <code>MainScreen</code> file,
 * and explained in the header of the method. I was able to figure out that the "mainPartSearchText" was showing
 * as null because the "mainPartSearchText" TextField was not declared under the proper name in the (the <code>MainScreen</code>)
 * controller file. Once updated, the search funtion worked as expected, but it took some time to find that small error.</p>
 * <p><b>JAVADOC</b> file can be found in the "AhanoverC482PA" folder included in this submission.</p>
 * <p>@Application Creates the Inventory Management application where the user can interact with various stages and screens
 * to add, remove, and modify "<code>Part</code>s" and "<code>Product</code>s" from a list of inventory items.</p>
 */
public class Main extends Application{


    /**
     * Displays the text "Starting Application..." in the command line for programmers working with the program.
     * @throws Exception This exception checks for general issues that an application would reasonably want to search for.
     * Produces an exception if some common errors are found.
     */
    @Override
    public void init() throws Exception {
        super.init();
        System.out.println("Starting Application...");
    }


    /**
     *  Starts the application and generates the <code>MainStage</code> stage. Generates the <code>MainStage</code> stage and show the
     *  <code>MainScreen</code> scene, which will become the "main" scene for the program. Also assigns the dimensions and title for the <code>MainStage</code> stage.
     * @param MainStage This parameter is the Stage object that will be called to retrieve the <code>MainScreen</code> scene.
     *                  Gives <code>MainStage</code> a title, declares the dimensions, and calls the <code>MainScreen</code> stage.
     * @throws Exception Checks for general issues that an application would reasonably want to search for. Produces an exception if some common errors are found.
     */
    @Override
    public void start(Stage MainStage) throws Exception {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/view/MainScreen.fxml")));
        MainStage.setTitle("Inventory Loader");
        MainStage.setScene(new Scene(root, 1000, 450));
        MainStage.show();
    }


    /**
     * Generates the command line message "Exiting Application..." when a user exits the application. Useful for programmers working on the internal files.
     * @throws Exception Checks for general issues that an application would reasonably want to search for. Produces an exception if some common errors are found.
     */
    @Override
    public void stop() throws Exception {
        super.stop();
        System.out.println("Exiting Application...");
    }


    /**
     * This is the <code>main</code> method. Gets called when the java program executes. Used to create and pre-fill <code>Part</code> and <code>Product</code> data
     * on the <code>MainScreen</code> stage TableViews using the "allParts" and "allProducts" ObservableLists; both of which are found in the <code>Inventory</code> file.
     * The <code>Part</code> and <code>Product</code> information found in this method are added to the ObservableLists and retrieved in the <code>MainScreen</code> scene
     * during the "initialize" method.
     * @param args Gets command line arguments that are passed during the program's execution.
     */
    public static void main(String[] args) {
        InHouse inHouse1 = new InHouse(Inventory.getPartTracker(), "Brakes", 19.99, 17, 4, 200, 1);
        InHouse inHouse2 = new InHouse(Inventory.getPartTracker(), "Caliper", 17.99, 29, 7,200, 2);
        InHouse inHouse3 = new InHouse(Inventory.getPartTracker(), "Tire", 49.99, 11, 8,200, 3);

        Outsourced outsourced1 = new Outsourced(Inventory.getPartTracker(), "Cassette", 19.99, 125, 10, 200, "Trek");
        Outsourced outsourced2 = new Outsourced(Inventory.getPartTracker(), "Chain", 12.99, 54, 10, 200, "Giant");
        Outsourced outsourced3 = new Outsourced(Inventory.getPartTracker(), "Seat", 47.99, 26, 10, 200, "Redline");

        Product product1 = new Product(Inventory.getProductTracker(), "Huffy", 199.99, 6, 1,50);
        Product product2 = new Product(Inventory.getProductTracker(), "All-City", 799.99, 3, 1,20);
        Product product3 = new Product(Inventory.getProductTracker(), "Zip-a-Dee-Doo-Dah", 899.99, 2, 1,15);

        product1.addAssociatedPart(inHouse1);

        product2.addAssociatedPart(inHouse2);

        product3.addAssociatedPart(outsourced1);

        Inventory.addProduct(product1);
        Inventory.addProduct(product2);
        Inventory.addProduct(product3);

        Inventory.addPart(inHouse1);
        Inventory.addPart(inHouse2);
        Inventory.addPart(inHouse3);

        Inventory.addPart(outsourced1);
        Inventory.addPart(outsourced2);
        Inventory.addPart(outsourced3);

        launch(args);
    }
}



